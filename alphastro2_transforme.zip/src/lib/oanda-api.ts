"use client"

import { useState, useEffect, useCallback } from "react"

// OANDA API Types
export interface OandaCandle {
  time: string
  mid: {
    o: string
    h: string
    l: string
    c: string
  }
  volume: number
  complete: boolean
}

export interface OandaPrice {
  instrument: string
  time: string
  tradeable: boolean
  bids: Array<{ price: string; liquidity: number }>
  asks: Array<{ price: string; liquidity: number }>
}

export interface OandaInstrument {
  name: string
  type: string
  displayName: string
  pipLocation: number
  displayPrecision: number
  tradeUnitsPrecision: number
  minimumTradeSize: string
  maximumTrailingStopDistance: string
  minimumTrailingStopDistance: string
  maximumPositionSize: string
  maximumOrderUnits: string
  marginRate: string
}

// Forex Factory News Types
export interface ForexNews {
  id: string
  title: string
  country: string
  date: Date
  time: string
  impact: "high" | "medium" | "low"
  forecast: string
  previous: string
  actual?: string
  currency: string
}

// Myfxbook Signal Types
export interface MyfxbookSignal {
  id: string
  pair: string
  action: "buy" | "sell"
  entry: number
  stopLoss: number
  takeProfit: number
  timestamp: Date
  status: "active" | "closed" | "pending"
  profit?: number
}

// OANDA Forex Pairs - Major, Minor, Exotic
export const OANDA_FOREX_PAIRS = [
  // Majors
  { instrument: "EUR_USD", displayName: "EUR/USD", category: "major" },
  { instrument: "GBP_USD", displayName: "GBP/USD", category: "major" },
  { instrument: "USD_JPY", displayName: "USD/JPY", category: "major" },
  { instrument: "USD_CHF", displayName: "USD/CHF", category: "major" },
  { instrument: "AUD_USD", displayName: "AUD/USD", category: "major" },
  { instrument: "USD_CAD", displayName: "USD/CAD", category: "major" },
  { instrument: "NZD_USD", displayName: "NZD/USD", category: "major" },
  // Minors
  { instrument: "EUR_GBP", displayName: "EUR/GBP", category: "minor" },
  { instrument: "EUR_JPY", displayName: "EUR/JPY", category: "minor" },
  { instrument: "GBP_JPY", displayName: "GBP/JPY", category: "minor" },
  { instrument: "EUR_AUD", displayName: "EUR/AUD", category: "minor" },
  { instrument: "EUR_CAD", displayName: "EUR/CAD", category: "minor" },
  { instrument: "AUD_JPY", displayName: "AUD/JPY", category: "minor" },
  { instrument: "CHF_JPY", displayName: "CHF/JPY", category: "minor" },
  // Commodities
  { instrument: "XAU_USD", displayName: "XAU/USD", category: "commodity" },
  { instrument: "XAG_USD", displayName: "XAG/USD", category: "commodity" },
]

// Timeframe mapping
export const OANDA_TIMEFRAMES = {
  "M1": "M1",
  "M5": "M5",
  "M15": "M15",
  "M30": "M30",
  "H1": "H1",
  "H4": "H4",
  "D": "D",
  "W": "W",
  "M": "M"
}

// Convert OANDA candle to our format
export function convertOandaCandle(oandaCandle: OandaCandle) {
  return {
    time: new Date(oandaCandle.time).getTime(),
    open: parseFloat(oandaCandle.mid.o),
    high: parseFloat(oandaCandle.mid.h),
    low: parseFloat(oandaCandle.mid.l),
    close: parseFloat(oandaCandle.mid.c),
    volume: oandaCandle.volume
  }
}

// Simulated OANDA Data (In production, connect to real OANDA API)
export function generateOandaData(instrument: string, timeframe: string, count: number = 100) {
  const basePrices: Record<string, number> = {
    "EUR_USD": 1.0850,
    "GBP_USD": 1.2650,
    "USD_JPY": 149.50,
    "USD_CHF": 0.8850,
    "AUD_USD": 0.6550,
    "USD_CAD": 1.3650,
    "NZD_USD": 0.5950,
    "EUR_GBP": 0.8580,
    "EUR_JPY": 162.20,
    "GBP_JPY": 189.10,
    "EUR_AUD": 1.6560,
    "EUR_CAD": 1.4820,
    "AUD_JPY": 97.85,
    "CHF_JPY": 168.95,
    "XAU_USD": 4500.00,
    "XAG_USD": 27.50,
  }

  const basePrice = basePrices[instrument] || 1
  const volatility = instrument.includes("XAU") ? 0.003 : instrument.includes("JPY") ? 0.001 : 0.0008

  const candles = []
  let price = basePrice
  const now = Date.now()
  
  // Timeframe in milliseconds
  const tfMs: Record<string, number> = {
    "M1": 60000,
    "M5": 300000,
    "M15": 900000,
    "M30": 1800000,
    "H1": 3600000,
    "H4": 14400000,
    "D": 86400000,
    "W": 604800000,
    "M": 2592000000
  }

  const interval = tfMs[timeframe] || 3600000

  for (let i = count; i > 0; i--) {
    const trend = Math.sin(i * 0.05) * 0.3 // Add trend component
    const change = ((Math.random() - 0.5) * 2 + trend * 0.1) * volatility * price
    const open = price
    const close = price + change
    const high = Math.max(open, close) + Math.random() * volatility * price * 0.5
    const low = Math.min(open, close) - Math.random() * volatility * price * 0.5
    const volume = Math.floor(Math.random() * 10000) + 1000

    candles.push({
      time: now - i * interval,
      open: Math.round(open * 100000) / 100000,
      high: Math.round(high * 100000) / 100000,
      low: Math.round(low * 100000) / 100000,
      close: Math.round(close * 100000) / 100000,
      volume
    })

    price = close
  }

  return candles
}

// Generate Forex Factory News (Simulated high-impact news)
export function generateForexFactoryNews(): ForexNews[] {
  const now = new Date()
  const currencies = ["USD", "EUR", "GBP", "JPY", "AUD", "CAD", "CHF", "NZD"]
  const highImpactEvents = [
    { title: "Non-Farm Payrolls", currency: "USD", impact: "high" as const },
    { title: "Interest Rate Decision", currency: "USD", impact: "high" as const },
    { title: "CPI m/m", currency: "USD", impact: "high" as const },
    { title: "GDP q/q", currency: "USD", impact: "high" as const },
    { title: "ECB Interest Rate Decision", currency: "EUR", impact: "high" as const },
    { title: "German CPI m/m", currency: "EUR", impact: "high" as const },
    { title: "BOE Interest Rate Decision", currency: "GBP", impact: "high" as const },
    { title: "UK CPI y/y", currency: "GBP", impact: "high" as const },
    { title: "BOJ Interest Rate Decision", currency: "JPY", impact: "high" as const },
    { title: "Australia Employment Change", currency: "AUD", impact: "high" as const },
    { title: "Canada Employment Change", currency: "CAD", impact: "high" as const },
    { title: "Swiss CPI m/m", currency: "CHF", impact: "medium" as const },
    { title: "RBNZ Interest Rate Decision", currency: "NZD", impact: "high" as const },
    { title: "Retail Sales m/m", currency: "USD", impact: "medium" as const },
    { title: "PMI Manufacturing", currency: "EUR", impact: "medium" as const },
    { title: "Trade Balance", currency: "GBP", impact: "low" as const },
  ]

  const news: ForexNews[] = []
  
  // Generate news for next 7 days
  for (let day = 0; day < 7; day++) {
    const numEvents = Math.floor(Math.random() * 4) + 2
    for (let i = 0; i < numEvents; i++) {
      const event = highImpactEvents[Math.floor(Math.random() * highImpactEvents.length)]
      const eventDate = new Date(now)
      eventDate.setDate(eventDate.getDate() + day)
      eventDate.setHours(Math.floor(Math.random() * 12) + 8, Math.floor(Math.random() * 4) * 15, 0, 0)

      const forecast = (Math.random() * 2 - 1).toFixed(1) + "%"
      const previous = (Math.random() * 2 - 1).toFixed(1) + "%"
      const actual = day === 0 && Math.random() > 0.5 ? (Math.random() * 2 - 1).toFixed(1) + "%" : undefined

      news.push({
        id: `news_${day}_${i}`,
        title: event.title,
        country: getCurrencyCountry(event.currency),
        date: eventDate,
        time: eventDate.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }),
        impact: event.impact,
        forecast,
        previous,
        actual,
        currency: event.currency
      })
    }
  }

  return news.sort((a, b) => a.date.getTime() - b.date.getTime())
}

function getCurrencyCountry(currency: string): string {
  const countries: Record<string, string> = {
    "USD": "États-Unis",
    "EUR": "Zone Euro",
    "GBP": "Royaume-Uni",
    "JPY": "Japon",
    "AUD": "Australie",
    "CAD": "Canada",
    "CHF": "Suisse",
    "NZD": "Nouvelle-Zélande"
  }
  return countries[currency] || currency
}

// Generate Myfxbook-style signals
export function generateMyfxbookSignals(): MyfxbookSignal[] {
  const pairs = ["EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "EUR/GBP"]
  const basePrices: Record<string, number> = {
    "EUR/USD": 1.0850,
    "GBP/USD": 1.2650,
    "USD/JPY": 149.50,
    "AUD/USD": 0.6550,
    "EUR/GBP": 0.8580
  }

  const signals: MyfxbookSignal[] = []
  const now = Date.now()

  for (let i = 0; i < 8; i++) {
    const pair = pairs[Math.floor(Math.random() * pairs.length)]
    const basePrice = basePrices[pair] || 1
    const action = Math.random() > 0.5 ? "buy" : "sell"
    const pipSize = pair.includes("JPY") ? 0.01 : 0.0001
    const spread = pipSize * (Math.floor(Math.random() * 30) + 10)
    
    const entry = basePrice + (Math.random() - 0.5) * spread
    const stopLoss = action === "buy" ? entry - spread * 2 : entry + spread * 2
    const takeProfit = action === "buy" ? entry + spread * 4 : entry - spread * 4

    signals.push({
      id: `signal_${i}`,
      pair,
      action,
      entry: Math.round(entry * 100000) / 100000,
      stopLoss: Math.round(stopLoss * 100000) / 100000,
      takeProfit: Math.round(takeProfit * 100000) / 100000,
      timestamp: new Date(now - Math.random() * 86400000 * 3),
      status: Math.random() > 0.7 ? "closed" : Math.random() > 0.5 ? "active" : "pending",
      profit: Math.random() > 0.5 ? Math.round((Math.random() * 100 - 30) * 100) / 100 : undefined
    })
  }

  return signals.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
}

// Custom hook for OANDA data
export function useOandaData(instrument: string, timeframe: string) {
  const [candles, setCandles] = useState<ReturnType<typeof generateOandaData>>([])
  const [loading, setLoading] = useState(true)
  const [currentPrice, setCurrentPrice] = useState<{ bid: number; ask: number; spread: number } | null>(null)

  useEffect(() => {
    setLoading(true)
    const data = generateOandaData(instrument, timeframe, 150)
    setCandles(data)
    
    const lastCandle = data[data.length - 1]
    const spread = instrument.includes("JPY") ? 0.02 : 0.00015
    setCurrentPrice({
      bid: lastCandle.close,
      ask: lastCandle.close + spread,
      spread: spread
    })
    
    setLoading(false)

    // Update price every 2 seconds
    const priceInterval = setInterval(() => {
      setCandles(prev => {
        if (prev.length === 0) return prev
        const last = prev[prev.length - 1]
        const volatility = instrument.includes("XAU") ? 0.003 : instrument.includes("JPY") ? 0.001 : 0.0008
        const change = (Math.random() - 0.5) * volatility * last.close
        
        const newCandle = {
          ...last,
          close: last.close + change,
          high: Math.max(last.high, last.close + change),
          low: Math.min(last.low, last.close + change)
        }
        
        setCurrentPrice({
          bid: newCandle.close,
          ask: newCandle.close + spread,
          spread
        })
        
        return [...prev.slice(0, -1), newCandle]
      })
    }, 2000)

    // Add new candle periodically based on timeframe
    const tfMs: Record<string, number> = {
      "M1": 60000,
      "M5": 300000,
      "M15": 900000,
      "H1": 3600000,
      "H4": 14400000,
    }
    
    const interval = tfMs[timeframe] || 60000
    const candleInterval = setInterval(() => {
      setCandles(prev => {
        const last = prev[prev.length - 1]
        const volatility = instrument.includes("XAU") ? 0.003 : instrument.includes("JPY") ? 0.001 : 0.0008
        const change = (Math.random() - 0.5) * volatility * last.close
        
        const newCandle = {
          time: Date.now(),
          open: last.close,
          high: Math.max(last.close, last.close + change),
          low: Math.min(last.close, last.close + change),
          close: last.close + change,
          volume: Math.floor(Math.random() * 10000) + 1000
        }
        
        return [...prev.slice(1), newCandle]
      })
    }, Math.min(interval, 30000)) // Cap at 30s for demo

    return () => {
      clearInterval(priceInterval)
      clearInterval(candleInterval)
    }
  }, [instrument, timeframe])

  return { candles, loading, currentPrice }
}

// Custom hook for Forex news
export function useForexNews() {
  const [news, setNews] = useState<ForexNews[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setNews(generateForexFactoryNews())
    setLoading(false)

    // Refresh news every 5 minutes
    const interval = setInterval(() => {
      setNews(generateForexFactoryNews())
    }, 300000)

    return () => clearInterval(interval)
  }, [])

  return { news, loading }
}

// Custom hook for Myfxbook signals
export function useMyfxbookSignals() {
  const [signals, setSignals] = useState<MyfxbookSignal[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setSignals(generateMyfxbookSignals())
    setLoading(false)

    // Refresh signals every 2 minutes
    const interval = setInterval(() => {
      setSignals(generateMyfxbookSignals())
    }, 120000)

    return () => clearInterval(interval)
  }, [])

  return { signals, loading }
}
