"use client"

import { useEffect, useState } from "react"

export type AlphaNotification = {
  id: string
  title: string
  body: string
  source: string
  ts: number
  read: boolean
  kind: "signal" | "telegram" | "system" | "alert"
  payload?: Record<string, unknown>
}

type Listener = (state: AlphaNotification[]) => void

const STORAGE_KEY = "agt-notifications-v1"
let state: AlphaNotification[] = []
const listeners = new Set<Listener>()

function load() {
  if (typeof window === "undefined") return
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) state = JSON.parse(raw)
  } catch {}
}
function persist() {
  if (typeof window === "undefined") return
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state.slice(0, 200)))
  } catch {}
}
function emit() {
  for (const l of listeners) l(state)
}

let loaded = false
function ensureLoaded() {
  if (!loaded) { load(); loaded = true }
}

export function pushNotification(n: Omit<AlphaNotification, "id" | "ts" | "read">) {
  ensureLoaded()
  const notif: AlphaNotification = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    ts: Date.now(),
    read: false,
    ...n,
  }
  state = [notif, ...state].slice(0, 200)
  persist()
  emit()
  // Haptic vibration (Facebook-style)
  try {
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      navigator.vibrate?.([60, 40, 120])
    }
  } catch {}
  // Sound ping
  try {
    if (typeof window !== "undefined") {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)()
      const o = ctx.createOscillator()
      const g = ctx.createGain()
      o.connect(g); g.connect(ctx.destination)
      o.frequency.value = 880
      g.gain.setValueAtTime(0.0001, ctx.currentTime)
      g.gain.exponentialRampToValueAtTime(0.15, ctx.currentTime + 0.02)
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.35)
      o.start(); o.stop(ctx.currentTime + 0.4)
    }
  } catch {}
  return notif
}

export function markAllRead() {
  ensureLoaded()
  state = state.map(n => ({ ...n, read: true }))
  persist(); emit()
}
export function clearAll() {
  state = []; persist(); emit()
}

export function useNotifications() {
  const [snap, setSnap] = useState<AlphaNotification[]>(() => {
    ensureLoaded(); return state
  })
  useEffect(() => {
    const l: Listener = s => setSnap([...s])
    listeners.add(l)
    return () => { listeners.delete(l) }
  }, [])
  const unread = snap.filter(n => !n.read).length
  return { notifications: snap, unread }
}
