"use client"

import { useState, useEffect, useCallback } from "react"

// Types
export interface MarketData {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
  high: number
  low: number
  volume: number
  timestamp: Date
}

export interface Candle {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export interface TechnicalIndicator {
  type: "CHOCH" | "BOS" | "FVG" | "OB" | "BB" | "RB" | "QML" | "GANN"
  price: number
  direction: "haussier" | "baissier"
  strength: number
  timestamp: Date
}

export interface WyckoffPhase {
  phase: "Accumulation" | "Expansion" | "Distribution" | "Spring" | "UTAD"
  confidence: number
  description: string
}

export interface PlanetPosition {
  planet: string
  longitude: number
  sign: string
  degree: number
  retrograde: boolean
}

export interface Aspect {
  planet1: string
  planet2: string
  type: "conjonction" | "opposition" | "carré" | "trigone" | "sextile"
  orb: number
  exact: boolean
}

export interface TradingSignal {
  id: string
  asset: string
  timeframe: string
  direction: "ACHAT" | "VENTE"
  entryZone: { min: number; max: number }
  stopLoss: number
  takeProfit: number
  riskReward: number
  validations: {
    ict: boolean
    dow: boolean
    qml: boolean
    gann: boolean
    wyckoff: boolean
    dorsan: boolean
  }
  justification: string
  timestamp: Date
  confidence: number
}

// Asset inception dates for sidereal calculations (Jacques Dorsan methodology)
export const ASSET_INCEPTION_DATES: Record<string, Date> = {
  "EUR/USD": new Date(1999, 0, 1), // Euro launch
  "GBP/USD": new Date(1971, 7, 15), // Bretton Woods end
  "USD/JPY": new Date(1971, 7, 15),
  "USD/CHF": new Date(1971, 7, 15),
  "AUD/USD": new Date(1983, 11, 12), // Float date
  "USD/CAD": new Date(1971, 7, 15),
  "NZD/USD": new Date(1985, 2, 4),
  "BTC/USD": new Date(2009, 0, 3), // Genesis block
  "ETH/USD": new Date(2015, 6, 30), // Ethereum launch
  "XAU/USD": new Date(1971, 7, 15), // Gold standard end
  "XAG/USD": new Date(1971, 7, 15),
}

// Lahiri Ayanamsa calculation (Sidereal offset)
export function calculateAyanamsa(date: Date): number {
  const year = date.getFullYear()
  const baseAyanamsa = 23.85 // Base value for 2000
  const annualPrecession = 0.0137 // Degrees per year
  return baseAyanamsa + (year - 2000) * annualPrecession
}

// Calculate sidereal position from tropical
export function tropicalToSidereal(tropicalLongitude: number, ayanamsa: number): number {
  let sidereal = tropicalLongitude - ayanamsa
  if (sidereal < 0) sidereal += 360
  return sidereal
}

// Get zodiac sign from longitude
export function getZodiacSign(longitude: number): string {
  const signs = [
    "Bélier", "Taureau", "Gémeaux", "Cancer",
    "Lion", "Vierge", "Balance", "Scorpion",
    "Sagittaire", "Capricorne", "Verseau", "Poissons"
  ]
  const signIndex = Math.floor(longitude / 30)
  return signs[signIndex]
}

// Generate mock planetary positions (in production, use ephemeris data)
export function calculatePlanetaryPositions(date: Date): PlanetPosition[] {
  const ayanamsa = calculateAyanamsa(date)
  const dayOfYear = Math.floor((date.getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / 86400000)
  
  const planets = [
    { name: "Soleil", speed: 0.9856, basePos: 280 },
    { name: "Lune", speed: 13.176, basePos: 120 },
    { name: "Mercure", speed: 1.383, basePos: 290 },
    { name: "Vénus", speed: 1.2, basePos: 310 },
    { name: "Mars", speed: 0.524, basePos: 45 },
    { name: "Jupiter", speed: 0.083, basePos: 355 },
    { name: "Saturne", speed: 0.033, basePos: 335 },
  ]

  return planets.map(planet => {
    const tropicalLong = (planet.basePos + dayOfYear * planet.speed) % 360
    const siderealLong = tropicalToSidereal(tropicalLong, ayanamsa)
    const sign = getZodiacSign(siderealLong)
    const degree = siderealLong % 30
    
    // Retrograde simulation for outer planets
    const isRetrograde = planet.name === "Mercure" 
      ? Math.sin(dayOfYear * 0.05) > 0.8
      : planet.name === "Mars" || planet.name === "Jupiter" || planet.name === "Saturne"
        ? Math.sin(dayOfYear * 0.02) > 0.7
        : false

    return {
      planet: planet.name,
      longitude: siderealLong,
      sign,
      degree: Math.round(degree * 100) / 100,
      retrograde: isRetrograde
    }
  })
}

// Calculate aspects between planets
export function calculateAspects(positions: PlanetPosition[]): Aspect[] {
  const aspectTypes = [
    { name: "conjonction" as const, angle: 0, orb: 8 },
    { name: "opposition" as const, angle: 180, orb: 8 },
    { name: "carré" as const, angle: 90, orb: 6 },
    { name: "trigone" as const, angle: 120, orb: 6 },
    { name: "sextile" as const, angle: 60, orb: 4 },
  ]

  const aspects: Aspect[] = []

  for (let i = 0; i < positions.length; i++) {
    for (let j = i + 1; j < positions.length; j++) {
      let diff = Math.abs(positions[i].longitude - positions[j].longitude)
      if (diff > 180) diff = 360 - diff

      for (const aspect of aspectTypes) {
        const orb = Math.abs(diff - aspect.angle)
        if (orb <= aspect.orb) {
          aspects.push({
            planet1: positions[i].planet,
            planet2: positions[j].planet,
            type: aspect.name,
            orb: Math.round(orb * 100) / 100,
            exact: orb < 1
          })
        }
      }
    }
  }

  return aspects
}

// Generate mock candle data
export function generateCandleData(basePrice: number, count: number, volatility: number = 0.001): Candle[] {
  const candles: Candle[] = []
  let price = basePrice
  const now = Date.now()

  for (let i = count; i > 0; i--) {
    const change = (Math.random() - 0.5) * 2 * volatility * price
    const open = price
    const close = price + change
    const high = Math.max(open, close) + Math.random() * volatility * price
    const low = Math.min(open, close) - Math.random() * volatility * price
    const volume = Math.floor(Math.random() * 10000000) + 1000000

    candles.push({
      time: now - i * 60000,
      open: Math.round(open * 100000) / 100000,
      high: Math.round(high * 100000) / 100000,
      low: Math.round(low * 100000) / 100000,
      close: Math.round(close * 100000) / 100000,
      volume
    })

    price = close
  }

  return candles
}

// Technical analysis functions
export function detectCHOCH(candles: Candle[]): TechnicalIndicator | null {
  if (candles.length < 10) return null
  
  const recent = candles.slice(-10)
  const highs = recent.map(c => c.high)
  const lows = recent.map(c => c.low)
  
  const prevHigh = Math.max(...highs.slice(0, 5))
  const prevLow = Math.min(...lows.slice(0, 5))
  const currentClose = recent[recent.length - 1].close
  
  if (currentClose > prevHigh) {
    return {
      type: "CHOCH",
      price: prevHigh,
      direction: "haussier",
      strength: 0.8,
      timestamp: new Date()
    }
  } else if (currentClose < prevLow) {
    return {
      type: "CHOCH",
      price: prevLow,
      direction: "baissier",
      strength: 0.8,
      timestamp: new Date()
    }
  }
  return null
}

export function detectBOS(candles: Candle[]): TechnicalIndicator | null {
  if (candles.length < 5) return null
  
  const recent = candles.slice(-5)
  const lastCandle = recent[recent.length - 1]
  const prevCandle = recent[recent.length - 2]
  
  if (lastCandle.close > prevCandle.high && lastCandle.open < lastCandle.close) {
    return {
      type: "BOS",
      price: prevCandle.high,
      direction: "haussier",
      strength: 0.7,
      timestamp: new Date()
    }
  } else if (lastCandle.close < prevCandle.low && lastCandle.open > lastCandle.close) {
    return {
      type: "BOS",
      price: prevCandle.low,
      direction: "baissier",
      strength: 0.7,
      timestamp: new Date()
    }
  }
  return null
}

export function detectFVG(candles: Candle[]): TechnicalIndicator | null {
  if (candles.length < 3) return null
  
  const c1 = candles[candles.length - 3]
  const c2 = candles[candles.length - 2]
  const c3 = candles[candles.length - 1]
  
  // Bullish FVG
  if (c3.low > c1.high) {
    return {
      type: "FVG",
      price: (c3.low + c1.high) / 2,
      direction: "haussier",
      strength: 0.75,
      timestamp: new Date()
    }
  }
  // Bearish FVG
  if (c3.high < c1.low) {
    return {
      type: "FVG",
      price: (c3.high + c1.low) / 2,
      direction: "baissier",
      strength: 0.75,
      timestamp: new Date()
    }
  }
  return null
}

export function detectOrderBlock(candles: Candle[]): TechnicalIndicator | null {
  if (candles.length < 5) return null
  
  const recent = candles.slice(-5)
  const volumes = recent.map(c => c.volume)
  const avgVolume = volumes.reduce((a, b) => a + b, 0) / volumes.length
  const lastCandle = recent[recent.length - 1]
  
  if (lastCandle.volume > avgVolume * 1.5) {
    const direction = lastCandle.close > lastCandle.open ? "haussier" : "baissier"
    return {
      type: "OB",
      price: direction === "haussier" ? lastCandle.low : lastCandle.high,
      direction,
      strength: 0.85,
      timestamp: new Date()
    }
  }
  return null
}

export function detectWyckoffPhase(candles: Candle[]): WyckoffPhase {
  if (candles.length < 50) {
    return { phase: "Accumulation", confidence: 0.5, description: "Données insuffisantes pour analyse Wyckoff" }
  }
  
  const prices = candles.map(c => c.close)
  const volumes = candles.map(c => c.volume)
  
  const avgPrice = prices.reduce((a, b) => a + b, 0) / prices.length
  const recentAvg = prices.slice(-10).reduce((a, b) => a + b, 0) / 10
  const avgVolume = volumes.reduce((a, b) => a + b, 0) / volumes.length
  const recentVolume = volumes.slice(-10).reduce((a, b) => a + b, 0) / 10
  
  const priceChange = (recentAvg - avgPrice) / avgPrice
  const volumeChange = (recentVolume - avgVolume) / avgVolume
  
  if (priceChange < -0.02 && volumeChange > 0.2) {
    return { phase: "Spring", confidence: 0.7, description: "Test du support avec volume élevé - potentiel retournement" }
  } else if (priceChange > 0.02 && volumeChange > 0.1) {
    return { phase: "Expansion", confidence: 0.75, description: "Phase de markup - tendance haussière confirmée" }
  } else if (priceChange > 0.03 && volumeChange < -0.1) {
    return { phase: "Distribution", confidence: 0.65, description: "Phase de distribution - ventes institutionnelles" }
  } else if (priceChange > 0.05 && volumeChange > 0.3) {
    return { phase: "UTAD", confidence: 0.6, description: "Upthrust After Distribution - piège haussier potentiel" }
  } else {
    return { phase: "Accumulation", confidence: 0.6, description: "Phase d'accumulation - construction de position" }
  }
}

// Combined signal validation
export function generateTradingSignal(
  asset: string,
  timeframe: string,
  candles: Candle[],
  planetPositions: PlanetPosition[],
  aspects: Aspect[]
): TradingSignal | null {
  const choch = detectCHOCH(candles)
  const bos = detectBOS(candles)
  const fvg = detectFVG(candles)
  const ob = detectOrderBlock(candles)
  const wyckoff = detectWyckoffPhase(candles)
  
  // Dorsan validation based on planetary aspects
  const hasVolatileAspect = aspects.some(a => 
    a.type === "carré" || a.type === "opposition"
  )
  const hasFavorableAspect = aspects.some(a =>
    a.type === "trigone" || a.type === "sextile"
  )
  const hasRetrograde = planetPositions.some(p => p.retrograde && (p.planet === "Mercure" || p.planet === "Mars"))
  
  // ICT validation
  const ictValid = (choch !== null || bos !== null) && (fvg !== null || ob !== null)
  
  // Dow validation
  const dowValid = wyckoff.confidence > 0.6
  
  // QML validation (simplified)
  const qmlValid = fvg !== null || ob !== null
  
  // Gann validation (simplified - based on time cycles)
  const now = new Date()
  const dayOfMonth = now.getDate()
  const gannCycle = dayOfMonth % 9 === 0 || dayOfMonth % 7 === 0
  const gannValid = gannCycle || ob !== null
  
  // Wyckoff validation
  const wyckoffValid = wyckoff.phase === "Accumulation" || wyckoff.phase === "Spring" || wyckoff.phase === "Expansion"
  
  // Dorsan validation
  const dorsanValid = hasFavorableAspect && !hasRetrograde
  
  // All validations must pass
  const allValid = ictValid && dowValid && qmlValid && gannValid && wyckoffValid && dorsanValid
  
  if (!allValid) return null
  
  const direction = choch?.direction || bos?.direction || "haussier"
  const lastPrice = candles[candles.length - 1].close
  const atr = calculateATR(candles)
  
  const entryMin = direction === "haussier" ? lastPrice - atr * 0.5 : lastPrice - atr * 0.5
  const entryMax = direction === "haussier" ? lastPrice + atr * 0.5 : lastPrice + atr * 0.5
  const stopLoss = direction === "haussier" ? lastPrice - atr * 2 : lastPrice + atr * 2
  const takeProfit = direction === "haussier" ? lastPrice + atr * 6 : lastPrice - atr * 6
  const rr = Math.abs(takeProfit - lastPrice) / Math.abs(lastPrice - stopLoss)
  
  return {
    id: `signal_${Date.now()}`,
    asset,
    timeframe,
    direction: direction === "haussier" ? "ACHAT" : "VENTE",
    entryZone: { min: entryMin, max: entryMax },
    stopLoss,
    takeProfit,
    riskReward: Math.round(rr * 10) / 10,
    validations: {
      ict: ictValid,
      dow: dowValid,
      qml: qmlValid,
      gann: gannValid,
      wyckoff: wyckoffValid,
      dorsan: dorsanValid
    },
    justification: generateJustification(choch, bos, fvg, ob, wyckoff, aspects, direction),
    timestamp: new Date(),
    confidence: calculateConfidence({ ict: ictValid, dow: dowValid, qml: qmlValid, gann: gannValid, wyckoff: wyckoffValid, dorsan: dorsanValid })
  }
}

function calculateATR(candles: Candle[], period: number = 14): number {
  if (candles.length < period) return candles[candles.length - 1].close * 0.001
  
  let atrSum = 0
  for (let i = candles.length - period; i < candles.length; i++) {
    const tr = Math.max(
      candles[i].high - candles[i].low,
      Math.abs(candles[i].high - candles[i - 1]?.close || candles[i].open),
      Math.abs(candles[i].low - candles[i - 1]?.close || candles[i].open)
    )
    atrSum += tr
  }
  return atrSum / period
}

function generateJustification(
  choch: TechnicalIndicator | null,
  bos: TechnicalIndicator | null,
  fvg: TechnicalIndicator | null,
  ob: TechnicalIndicator | null,
  wyckoff: WyckoffPhase,
  aspects: Aspect[],
  direction: string
): string {
  const parts: string[] = []
  
  if (choch) {
    parts.push(`Changement de caractère (CHOCH) ${choch.direction} détecté au niveau ${choch.price.toFixed(5)}`)
  }
  if (bos) {
    parts.push(`Cassure de structure (BOS) ${bos.direction} confirmée`)
  }
  if (fvg) {
    parts.push(`Zone de déséquilibre (FVG) ${fvg.direction} identifiée`)
  }
  if (ob) {
    parts.push(`Bloc d'ordres institutionnel (OB) ${ob.direction} au prix ${ob.price.toFixed(5)}`)
  }
  parts.push(`Phase Wyckoff: ${wyckoff.phase} (${wyckoff.description})`)
  
  const favorableAspects = aspects.filter(a => a.type === "trigone" || a.type === "sextile")
  if (favorableAspects.length > 0) {
    parts.push(`Aspects astrologiques favorables: ${favorableAspects.map(a => `${a.planet1}-${a.planet2} ${a.type}`).join(", ")}`)
  }
  
  return parts.join(". ") + "."
}

function calculateConfidence(validations: Record<string, boolean>): number {
  const weights = { ict: 0.2, dow: 0.15, qml: 0.15, gann: 0.15, wyckoff: 0.15, dorsan: 0.2 }
  let confidence = 0
  for (const [key, valid] of Object.entries(validations)) {
    if (valid) confidence += weights[key as keyof typeof weights]
  }
  return Math.round(confidence * 100)
}

// Custom hook for market data
export function useMarketData(symbols: string[]) {
  const [data, setData] = useState<Record<string, MarketData>>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const baseprices: Record<string, number> = {
      "EUR/USD": 1.0850,
      "GBP/USD": 1.2650,
      "USD/JPY": 149.50,
      "USD/CHF": 0.8850,
      "AUD/USD": 0.6550,
      "USD/CAD": 1.3650,
      "NZD/USD": 0.5950,
      "BTC/USD": 67500,
      "ETH/USD": 3450,
      "XAU/USD": 4500,
    }

    const updateData = () => {
      const newData: Record<string, MarketData> = {}
      symbols.forEach(symbol => {
        const basePrice = baseprices[symbol] || 1
        const change = (Math.random() - 0.5) * 0.002 * basePrice
        const price = basePrice + change
        const changePercent = (change / basePrice) * 100
        
        newData[symbol] = {
          symbol,
          name: symbol,
          price: Math.round(price * 100000) / 100000,
          change: Math.round(change * 100000) / 100000,
          changePercent: Math.round(changePercent * 100) / 100,
          high: price * 1.002,
          low: price * 0.998,
          volume: Math.floor(Math.random() * 1000000000),
          timestamp: new Date()
        }
      })
      setData(newData)
      setLoading(false)
    }

    updateData()
    const interval = setInterval(updateData, 2000)
    return () => clearInterval(interval)
  }, [symbols])

  return { data, loading }
}

// Custom hook for candle data
export function useCandleData(symbol: string, timeframe: string) {
  const [candles, setCandles] = useState<Candle[]>([])
  const [loading, setLoading] = useState(true)

  const baseprices: Record<string, number> = {
    "EUR/USD": 1.0850,
    "GBP/USD": 1.2650,
    "USD/JPY": 149.50,
    "USD/CHF": 0.8850,
    "AUD/USD": 0.6550,
    "USD/CAD": 1.3650,
    "NZD/USD": 0.5950,
    "BTC/USD": 67500,
    "ETH/USD": 3450,
    "XAU/USD": 4500,
  }

  useEffect(() => {
    const basePrice = baseprices[symbol] || 1
    const volatility = symbol.includes("BTC") || symbol.includes("ETH") ? 0.005 : 0.001
    
    setCandles(generateCandleData(basePrice, 100, volatility))
    setLoading(false)

    const interval = setInterval(() => {
      setCandles(prev => {
        const lastCandle = prev[prev.length - 1]
        const change = (Math.random() - 0.5) * 2 * volatility * lastCandle.close
        const newCandle: Candle = {
          time: Date.now(),
          open: lastCandle.close,
          high: Math.max(lastCandle.close, lastCandle.close + change) + Math.random() * volatility * lastCandle.close,
          low: Math.min(lastCandle.close, lastCandle.close + change) - Math.random() * volatility * lastCandle.close,
          close: lastCandle.close + change,
          volume: Math.floor(Math.random() * 10000000) + 1000000
        }
        return [...prev.slice(1), newCandle]
      })
    }, 3000)

    return () => clearInterval(interval)
  }, [symbol, timeframe])

  return { candles, loading }
}

// Custom hook for planetary data
export function usePlanetaryData() {
  const [positions, setPositions] = useState<PlanetPosition[]>([])
  const [aspects, setAspects] = useState<Aspect[]>([])

  useEffect(() => {
    const updatePositions = () => {
      const pos = calculatePlanetaryPositions(new Date())
      setPositions(pos)
      setAspects(calculateAspects(pos))
    }

    updatePositions()
    const interval = setInterval(updatePositions, 60000) // Update every minute
    return () => clearInterval(interval)
  }, [])

  return { positions, aspects }
}
