import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Navigation, type TabId } from "@/components/navigation";
import { Dashboard } from "@/components/dashboard";
import { DualChartModule } from "@/components/dual-chart-module";
import { AstroFinancialChart } from "@/components/astro-financial-chart";
import { SignalEngine } from "@/components/signal-engine";
import { SiderealEngine } from "@/components/sidereal-engine";
import { EducationalSection } from "@/components/educational-section";
import { TradingMiniGames } from "@/components/trading-mini-games";
import { ExtraMiniGames } from "@/components/extra-mini-games";
import { MediaEsotericFeed } from "@/components/media-esoteric-feed";
import { AssetScreener } from "@/components/asset-screener";
import { PredictiveEngine } from "@/components/predictive-engine";
import { EconomicCalendar } from "@/components/economic-calendar";
import { ScripturalChronicles } from "@/components/scriptural-chronicles";
import { InteractiveAcademy } from "@/components/interactive-academy";
import { MasterTraders } from "@/components/master-traders";
import { VirtualWhiteboard } from "@/components/virtual-whiteboard";
import { BiblicalVerses } from "@/components/biblical-verses";
import { SplashScreen } from "@/components/splash-screen";
import { XauLiveTicker } from "@/components/xau-live-ticker";
import { TelegramAggregator } from "@/components/telegram-aggregator";
import { TradingViewClone } from "@/components/tradingview-clone";
import { JustMarketsClone } from "@/components/justmarkets-clone";
import { MetalphaTrader } from "@/components/metatrader-clone";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Alpha Gaetan Trading — Plateforme AlphaMarket OANDA" },
      {
        name: "description",
        content:
          "Plateforme de trading hyper-intelligente alimentée OANDA : signaux multi-méthodes, charting Dorsan, screener, moteur prédictif, académie interactive.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  const [activeTab, setActiveTab] = useState<TabId>("dashboard");
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const stored = (typeof window !== "undefined" && localStorage.getItem("agt-theme")) as
      | "dark" | "light" | null;
    if (stored) setTheme(stored);
    if (typeof window !== "undefined" && sessionStorage.getItem("agt-started") === "1") {
      setStarted(true);
    }
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove("dark", "light");
    root.classList.add(theme);
    localStorage.setItem("agt-theme", theme);
  }, [theme]);

  if (!started) {
    return (
      <SplashScreen
        onStart={() => {
          sessionStorage.setItem("agt-started", "1");
          setStarted(true);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-background">

      <Navigation
        activeTab={activeTab}
        onTabChange={setActiveTab}
        theme={theme}
        onToggleTheme={() => setTheme((t) => (t === "dark" ? "light" : "dark"))}
      />

      <main className="pb-8">
        {activeTab === "dashboard" && (
          <div className="space-y-4 p-4 lg:p-6">
            <XauLiveTicker />
            <BiblicalVerses />
            <VirtualWhiteboard />
            <Dashboard />
          </div>
        )}
        {activeTab === "tvchart" && <TradingViewClone />}
        {activeTab === "justmarkets" && <JustMarketsClone />}
        {activeTab === "metatrader" && <MetalphaTrader />}
        {activeTab === "telegram" && <TelegramAggregator />}
        {activeTab === "feed" && <MediaEsotericFeed />}
        {activeTab === "charts" && <DualChartModule />}
        {activeTab === "astro-chart" && <AstroFinancialChart />}
        {activeTab === "screener" && <AssetScreener />}
        {activeTab === "predictive" && <PredictiveEngine />}
        {activeTab === "signals" && <SignalEngine />}
        {activeTab === "astrology" && <SiderealEngine />}
        {activeTab === "calendar" && <EconomicCalendar />}
        {activeTab === "academy" && <InteractiveAcademy />}
        {activeTab === "scriptures" && <ScripturalChronicles />}
        {activeTab === "masters" && <MasterTraders />}
        {activeTab === "games" && (
          <>
            <TradingMiniGames />
            <ExtraMiniGames />
          </>
        )}
        {activeTab === "education" && <EducationalSection />}
      </main>

      <footer className="border-t border-border/50 bg-darker-surface/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <span className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} Alpha Gaetan Trading — Données OANDA
          </span>
          <div className="text-sm text-muted-foreground">
            Réalisé par <span className="text-accent font-semibold">Alpha Gaetan Rakotomalala</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
