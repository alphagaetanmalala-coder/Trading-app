"use client"

import { useEffect, useMemo, useState } from "react"
import { Sparkles, Play } from "lucide-react"
import { Button } from "@/components/ui/button"

const QUOTES: { text: string; author: string }[] = [
  { text: "Le marché peut rester irrationnel plus longtemps que vous ne pouvez rester solvable.", author: "John Maynard Keynes" },
  { text: "Coupez vos pertes rapidement, laissez courir vos gains.", author: "Jesse Livermore" },
  { text: "Le risque vient de ne pas savoir ce que l'on fait.", author: "Warren Buffett" },
  { text: "La tendance est votre amie jusqu'à la fin où elle se courbe.", author: "Ed Seykota" },
  { text: "Soyez craintif quand les autres sont avides, et avide quand les autres sont craintifs.", author: "Warren Buffett" },
  { text: "Le temps est plus important que le prix; quand le temps est venu, le prix renverse.", author: "W. D. Gann" },
  { text: "Le but n'est pas d'avoir raison, c'est de gagner de l'argent.", author: "George Soros" },
  { text: "Patience, discipline, exécution — le reste est bruit.", author: "Paul Tudor Jones" },
]

function AnalogClock({ size = 240 }: { size?: number }) {
  const [now, setNow] = useState<Date | null>(null)
  useEffect(() => {
    setNow(new Date())
    const id = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(id)
  }, [])
  if (!now) return <div style={{ width: size, height: size }} />

  const s = now.getSeconds()
  const m = now.getMinutes() + s / 60
  const h = (now.getHours() % 12) + m / 60
  const hAng = h * 30
  const mAng = m * 6
  const sAng = s * 6
  const cx = size / 2
  const r = size / 2 - 6

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="drop-shadow-[0_0_30px_hsl(var(--primary)/0.5)]">
      <defs>
        <radialGradient id="face" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="hsl(var(--card))" />
          <stop offset="100%" stopColor="hsl(var(--background))" />
        </radialGradient>
      </defs>
      <circle cx={cx} cy={cx} r={r} fill="url(#face)" stroke="hsl(var(--primary))" strokeWidth="2" />
      {Array.from({ length: 60 }).map((_, i) => {
        const a = (i * 6 * Math.PI) / 180
        const x1 = cx + Math.sin(a) * (r - (i % 5 === 0 ? 14 : 6))
        const y1 = cx - Math.cos(a) * (r - (i % 5 === 0 ? 14 : 6))
        const x2 = cx + Math.sin(a) * (r - 2)
        const y2 = cx - Math.cos(a) * (r - 2)
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={i % 5 === 0 ? "hsl(var(--accent))" : "hsl(var(--muted-foreground))"} strokeWidth={i % 5 === 0 ? 2 : 1} />
      })}
      <g transform={`rotate(${hAng} ${cx} ${cx})`}>
        <line x1={cx} y1={cx + 12} x2={cx} y2={cx - r * 0.5} stroke="hsl(var(--foreground))" strokeWidth="5" strokeLinecap="round" />
      </g>
      <g transform={`rotate(${mAng} ${cx} ${cx})`}>
        <line x1={cx} y1={cx + 16} x2={cx} y2={cx - r * 0.75} stroke="hsl(var(--primary))" strokeWidth="3" strokeLinecap="round" />
      </g>
      <g transform={`rotate(${sAng} ${cx} ${cx})`}>
        <line x1={cx} y1={cx + 20} x2={cx} y2={cx - r * 0.85} stroke="hsl(var(--accent))" strokeWidth="1.5" strokeLinecap="round" />
      </g>
      <circle cx={cx} cy={cx} r={5} fill="hsl(var(--accent))" />
    </svg>
  )
}

function MiniCalendar() {
  const [today, setToday] = useState<Date | null>(null)
  useEffect(() => setToday(new Date()), [])
  const { days, monthLabel, dayNum } = useMemo(() => {
    const d = today ?? new Date(2024, 0, 1)
    const year = d.getFullYear()
    const month = d.getMonth()
    const first = new Date(year, month, 1).getDay()
    const last = new Date(year, month + 1, 0).getDate()
    const arr: (number | null)[] = []
    const offset = (first + 6) % 7
    for (let i = 0; i < offset; i++) arr.push(null)
    for (let i = 1; i <= last; i++) arr.push(i)
    return {
      days: arr,
      monthLabel: d.toLocaleDateString("fr-FR", { month: "long", year: "numeric" }),
      dayNum: d.getDate(),
    }
  }, [today])

  return (
    <div className="bg-card/60 backdrop-blur border border-border/50 rounded-xl p-4 w-[260px] shadow-xl">
      <div className="text-center text-sm font-semibold text-primary capitalize mb-2">{monthLabel}</div>
      <div className="grid grid-cols-7 gap-1 text-[10px] text-muted-foreground mb-1">
        {["L", "M", "M", "J", "V", "S", "D"].map((d, i) => <div key={i} className="text-center">{d}</div>)}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {days.map((n, i) => (
          <div key={i} className={`aspect-square flex items-center justify-center text-xs rounded ${n === null ? "" : n === dayNum ? "bg-accent text-accent-foreground font-bold" : "text-foreground hover:bg-secondary/50"}`}>
            {n ?? ""}
          </div>
        ))}
      </div>
    </div>
  )
}

export function SplashScreen({ onStart }: { onStart: () => void }) {
  const [quoteIdx, setQuoteIdx] = useState(0)
  useEffect(() => {
    const id = setInterval(() => setQuoteIdx((i) => (i + 1) % QUOTES.length), 5 * 60 * 1000)
    return () => clearInterval(id)
  }, [])
  const q = QUOTES[quoteIdx]

  return (
    <div className="min-h-screen relative overflow-hidden bg-background flex flex-col items-center justify-center p-6">
      {/* animated background orbs */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 -left-40 w-[480px] h-[480px] rounded-full bg-primary/20 blur-3xl animate-pulse" />
        <div className="absolute -bottom-40 -right-40 w-[520px] h-[520px] rounded-full bg-accent/20 blur-3xl animate-pulse" style={{ animationDelay: "1s" }} />
        <div className="absolute top-1/3 right-1/4 w-72 h-72 rounded-full bg-primary/10 blur-2xl animate-pulse" style={{ animationDelay: "2s" }} />
      </div>

      {/* ticker */}
      <div className="absolute top-0 left-0 right-0 overflow-hidden border-b border-border/40 bg-darker-surface/60 backdrop-blur">
        <div className="flex gap-8 py-2 whitespace-nowrap animate-[marquee_30s_linear_infinite] text-xs font-mono text-muted-foreground">
          {["EUR/USD 1.0852 ▲", "XAU/USD 4502.10 ▲", "GBP/USD 1.2648 ▼", "USD/JPY 149.55 ▲", "BTC/USD 68 240 ▲", "AUD/USD 0.6551 ▼", "SP500 5 432 ▲"].concat(["EUR/USD 1.0852 ▲", "XAU/USD 4502.10 ▲", "GBP/USD 1.2648 ▼", "USD/JPY 149.55 ▲"]).map((t, i) => (
            <span key={i} className="px-4">{t}</span>
          ))}
        </div>
      </div>

      <div className="relative z-10 max-w-4xl w-full flex flex-col items-center gap-8 animate-fade-in">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.4em] text-accent">
            <Sparkles className="h-3.5 w-3.5" /> Alpha Prototype
          </div>
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
            Alpha Prototype Trader
          </h1>
          <p className="text-muted-foreground text-sm md:text-base">
            Plateforme sidérale hyper-intelligente · Données OANDA temps réel
          </p>
        </div>

        <div className="flex flex-col md:flex-row items-center gap-8">
          <AnalogClock size={240} />
          <MiniCalendar />
        </div>

        <div key={quoteIdx} className="max-w-2xl text-center animate-fade-in">
          <p className="text-lg md:text-xl italic text-foreground leading-relaxed">« {q.text} »</p>
          <p className="mt-2 text-sm text-accent font-semibold">— {q.author}</p>
        </div>

        <Button
          size="lg"
          onClick={onStart}
          className="group relative px-12 py-6 text-lg font-bold tracking-wider bg-gradient-to-r from-primary to-accent text-primary-foreground hover:scale-105 transition-transform shadow-[0_0_40px_hsl(var(--primary)/0.5)] hover:shadow-[0_0_60px_hsl(var(--accent)/0.7)]"
        >
          <Play className="h-5 w-5 mr-2 fill-current" />
          DÉMARRER
        </Button>
        <p className="text-xs text-muted-foreground">Cliquez pour accéder au tableau de bord</p>
      </div>

      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  )
}
