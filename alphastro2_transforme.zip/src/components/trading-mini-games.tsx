"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { 
  Gamepad2,
  Target,
  TrendingUp,
  TrendingDown,
  Timer,
  Trophy,
  Star,
  Zap,
  Brain,
  BarChart3,
  RefreshCw,
  Play,
  Pause,
  RotateCcw
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

// Game Types
interface CandlePattern {
  id: string
  name: string
  type: "bullish" | "bearish"
  candles: Array<{ open: number; close: number; high: number; low: number }>
}

interface TrendGame {
  prices: number[]
  correctAnswer: "up" | "down" | "sideways"
}

// Candlestick Patterns
const CANDLE_PATTERNS: CandlePattern[] = [
  {
    id: "hammer",
    name: "Marteau (Hammer)",
    type: "bullish",
    candles: [{ open: 50, close: 52, high: 53, low: 40 }]
  },
  {
    id: "doji",
    name: "Doji",
    type: "bearish",
    candles: [{ open: 50, close: 50.5, high: 55, low: 45 }]
  },
  {
    id: "engulfing_bull",
    name: "Englobante Haussière",
    type: "bullish",
    candles: [
      { open: 55, close: 50, high: 56, low: 49 },
      { open: 49, close: 58, high: 59, low: 48 }
    ]
  },
  {
    id: "engulfing_bear",
    name: "Englobante Baissière",
    type: "bearish",
    candles: [
      { open: 50, close: 55, high: 56, low: 49 },
      { open: 56, close: 48, high: 57, low: 47 }
    ]
  },
  {
    id: "morning_star",
    name: "Étoile du Matin",
    type: "bullish",
    candles: [
      { open: 55, close: 50, high: 56, low: 49 },
      { open: 50, close: 49, high: 51, low: 48 },
      { open: 49, close: 56, high: 57, low: 48 }
    ]
  },
  {
    id: "evening_star",
    name: "Étoile du Soir",
    type: "bearish",
    candles: [
      { open: 50, close: 55, high: 56, low: 49 },
      { open: 55, close: 56, high: 58, low: 54 },
      { open: 56, close: 49, high: 57, low: 48 }
    ]
  }
]

// Mini-game: Pattern Recognition
function PatternRecognitionGame() {
  const [currentPattern, setCurrentPattern] = useState<CandlePattern | null>(null)
  const [score, setScore] = useState(0)
  const [streak, setStreak] = useState(0)
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null)
  const [totalPlayed, setTotalPlayed] = useState(0)

  const newPattern = useCallback(() => {
    const pattern = CANDLE_PATTERNS[Math.floor(Math.random() * CANDLE_PATTERNS.length)]
    setCurrentPattern(pattern)
    setFeedback(null)
  }, [])

  useEffect(() => {
    newPattern()
  }, [newPattern])

  const handleGuess = (guess: "bullish" | "bearish") => {
    if (!currentPattern) return
    
    const correct = guess === currentPattern.type
    setTotalPlayed(prev => prev + 1)
    
    if (correct) {
      setScore(prev => prev + 10 + streak * 5)
      setStreak(prev => prev + 1)
      setFeedback("correct")
    } else {
      setStreak(0)
      setFeedback("wrong")
    }
    
    setTimeout(() => newPattern(), 1500)
  }

  return (
    <Card className="bg-card/50 border-border/50 backdrop-blur">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-foreground">
            <Target className="h-5 w-5 text-primary" />
            Reconnaissance de Patterns
          </div>
          <div className="flex items-center gap-4 text-sm">
            <span className="text-accent">Score: {score}</span>
            <span className="text-primary">Série: {streak}</span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {currentPattern && (
          <div className="space-y-4">
            {/* Candle Display */}
            <div className="flex items-end justify-center gap-4 h-32 bg-secondary/30 rounded-lg p-4">
              {currentPattern.candles.map((candle, idx) => {
                const isBullish = candle.close > candle.open
                const bodyHeight = Math.abs(candle.close - candle.open)
                const wickTop = candle.high - Math.max(candle.open, candle.close)
                const wickBottom = Math.min(candle.open, candle.close) - candle.low
                
                return (
                  <div key={idx} className="flex flex-col items-center">
                    {/* Upper wick */}
                    <div 
                      className={cn(
                        "w-0.5",
                        isBullish ? "bg-neon-green" : "bg-neon-red"
                      )}
                      style={{ height: `${wickTop}px` }}
                    />
                    {/* Body */}
                    <div 
                      className={cn(
                        "w-8 rounded-sm",
                        isBullish ? "bg-neon-green" : "bg-neon-red"
                      )}
                      style={{ height: `${Math.max(bodyHeight, 4)}px` }}
                    />
                    {/* Lower wick */}
                    <div 
                      className={cn(
                        "w-0.5",
                        isBullish ? "bg-neon-green" : "bg-neon-red"
                      )}
                      style={{ height: `${wickBottom}px` }}
                    />
                  </div>
                )
              })}
            </div>

            {/* Feedback */}
            {feedback && (
              <div className={cn(
                "text-center py-2 rounded-lg font-bold",
                feedback === "correct" 
                  ? "bg-neon-green/20 text-neon-green" 
                  : "bg-neon-red/20 text-neon-red"
              )}>
                {feedback === "correct" ? `Correct! C'est un ${currentPattern.name}` : `Faux! C'était un ${currentPattern.name}`}
              </div>
            )}

            {/* Buttons */}
            <div className="flex gap-4">
              <button
                onClick={() => handleGuess("bullish")}
                disabled={feedback !== null}
                className="flex-1 py-3 rounded-lg bg-neon-green/20 text-neon-green font-bold hover:bg-neon-green/30 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
              >
                <TrendingUp className="h-5 w-5" />
                HAUSSIER
              </button>
              <button
                onClick={() => handleGuess("bearish")}
                disabled={feedback !== null}
                className="flex-1 py-3 rounded-lg bg-neon-red/20 text-neon-red font-bold hover:bg-neon-red/30 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
              >
                <TrendingDown className="h-5 w-5" />
                BAISSIER
              </button>
            </div>

            {/* Stats */}
            <div className="text-center text-sm text-muted-foreground">
              Précision: {totalPlayed > 0 ? Math.round((score / (totalPlayed * 10)) * 100) : 0}%
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

// Mini-game: Speed Trading
function SpeedTradingGame() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [price, setPrice] = useState(100)
  const [position, setPosition] = useState<"long" | "short" | null>(null)
  const [entryPrice, setEntryPrice] = useState(0)
  const [pnl, setPnl] = useState(0)
  const [totalPnl, setTotalPnl] = useState(0)
  const [trades, setTrades] = useState(0)
  const [timeLeft, setTimeLeft] = useState(30)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)

  const startGame = () => {
    setIsPlaying(true)
    setPrice(100)
    setPosition(null)
    setPnl(0)
    setTotalPnl(0)
    setTrades(0)
    setTimeLeft(30)
  }

  const resetGame = () => {
    setIsPlaying(false)
    if (intervalRef.current) clearInterval(intervalRef.current)
    setPrice(100)
    setPosition(null)
    setPnl(0)
    setTotalPnl(0)
    setTrades(0)
    setTimeLeft(30)
  }

  useEffect(() => {
    if (!isPlaying) return

    intervalRef.current = setInterval(() => {
      setPrice(prev => {
        const change = (Math.random() - 0.48) * 2
        return Math.max(50, Math.min(150, prev + change))
      })
      setTimeLeft(prev => {
        if (prev <= 1) {
          setIsPlaying(false)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [isPlaying])

  useEffect(() => {
    if (position && entryPrice) {
      if (position === "long") {
        setPnl(Math.round((price - entryPrice) * 100) / 100)
      } else {
        setPnl(Math.round((entryPrice - price) * 100) / 100)
      }
    }
  }, [price, position, entryPrice])

  const openPosition = (type: "long" | "short") => {
    if (position) return
    setPosition(type)
    setEntryPrice(price)
    setTrades(prev => prev + 1)
  }

  const closePosition = () => {
    if (!position) return
    setTotalPnl(prev => prev + pnl)
    setPosition(null)
    setPnl(0)
    setEntryPrice(0)
  }

  return (
    <Card className="bg-card/50 border-border/50 backdrop-blur">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-foreground">
            <Zap className="h-5 w-5 text-accent" />
            Speed Trading (30s)
          </div>
          {isPlaying && (
            <div className="flex items-center gap-2 text-sm">
              <Timer className="h-4 w-4 text-neon-red" />
              <span className={cn(timeLeft <= 10 ? "text-neon-red" : "text-foreground")}>
                {timeLeft}s
              </span>
            </div>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Price Display */}
          <div className="text-center py-6 bg-secondary/30 rounded-lg">
            <p className="text-4xl font-bold text-foreground font-mono">
              ${price.toFixed(2)}
            </p>
            {position && (
              <p className={cn(
                "text-lg font-bold mt-2",
                pnl >= 0 ? "text-neon-green" : "text-neon-red"
              )}>
                P/L: {pnl >= 0 ? "+" : ""}{pnl.toFixed(2)}
              </p>
            )}
          </div>

          {/* Controls */}
          {!isPlaying ? (
            <div className="space-y-4">
              {timeLeft === 0 && (
                <div className="text-center py-4 bg-primary/20 rounded-lg">
                  <Trophy className="h-8 w-8 text-accent mx-auto mb-2" />
                  <p className="text-lg font-bold text-foreground">Partie terminée!</p>
                  <p className={cn(
                    "text-xl font-bold",
                    totalPnl >= 0 ? "text-neon-green" : "text-neon-red"
                  )}>
                    Total P/L: {totalPnl >= 0 ? "+" : ""}{totalPnl.toFixed(2)}
                  </p>
                  <p className="text-sm text-muted-foreground">Trades: {trades}</p>
                </div>
              )}
              <button
                onClick={startGame}
                className="w-full py-3 rounded-lg bg-primary text-primary-foreground font-bold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
              >
                <Play className="h-5 w-5" />
                {timeLeft === 0 ? "REJOUER" : "COMMENCER"}
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {!position ? (
                <div className="flex gap-4">
                  <button
                    onClick={() => openPosition("long")}
                    className="flex-1 py-3 rounded-lg bg-neon-green/20 text-neon-green font-bold hover:bg-neon-green/30 transition-colors flex items-center justify-center gap-2"
                  >
                    <TrendingUp className="h-5 w-5" />
                    LONG
                  </button>
                  <button
                    onClick={() => openPosition("short")}
                    className="flex-1 py-3 rounded-lg bg-neon-red/20 text-neon-red font-bold hover:bg-neon-red/30 transition-colors flex items-center justify-center gap-2"
                  >
                    <TrendingDown className="h-5 w-5" />
                    SHORT
                  </button>
                </div>
              ) : (
                <button
                  onClick={closePosition}
                  className="w-full py-3 rounded-lg bg-accent text-accent-foreground font-bold hover:bg-accent/90 transition-colors"
                >
                  FERMER POSITION
                </button>
              )}
              
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Trades: {trades}</span>
                <span className={cn(
                  "font-bold",
                  totalPnl >= 0 ? "text-neon-green" : "text-neon-red"
                )}>
                  Total: {totalPnl >= 0 ? "+" : ""}{totalPnl.toFixed(2)}
                </span>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

// Mini-game: Trend Prediction
function TrendPredictionGame() {
  const [prices, setPrices] = useState<number[]>([])
  const [guess, setGuess] = useState<"up" | "down" | null>(null)
  const [result, setResult] = useState<"correct" | "wrong" | null>(null)
  const [score, setScore] = useState(0)
  const [round, setRound] = useState(1)

  const generatePrices = useCallback(() => {
    const trend = Math.random() > 0.5 ? 1 : -1
    const volatility = 2
    let price = 100
    const newPrices = [price]
    
    for (let i = 0; i < 9; i++) {
      price += trend * Math.random() * volatility + (Math.random() - 0.5) * volatility
      newPrices.push(price)
    }
    
    setPrices(newPrices)
    setGuess(null)
    setResult(null)
  }, [])

  useEffect(() => {
    generatePrices()
  }, [generatePrices])

  const handleGuess = (direction: "up" | "down") => {
    setGuess(direction)
    const actualTrend = prices[prices.length - 1] > prices[0] ? "up" : "down"
    const correct = direction === actualTrend
    
    if (correct) {
      setScore(prev => prev + 10)
      setResult("correct")
    } else {
      setResult("wrong")
    }

    setTimeout(() => {
      setRound(prev => prev + 1)
      generatePrices()
    }, 2000)
  }

  const maxPrice = Math.max(...prices)
  const minPrice = Math.min(...prices)
  const range = maxPrice - minPrice || 1

  return (
    <Card className="bg-card/50 border-border/50 backdrop-blur">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-foreground">
            <Brain className="h-5 w-5 text-primary" />
            Prédiction de Tendance
          </div>
          <div className="flex items-center gap-4 text-sm">
            <span className="text-accent">Score: {score}</span>
            <span className="text-muted-foreground">Round: {round}</span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Chart */}
          <div className="h-32 bg-secondary/30 rounded-lg p-4 flex items-end gap-1">
            {prices.map((price, idx) => (
              <div
                key={idx}
                className="flex-1 bg-primary rounded-t transition-all"
                style={{ 
                  height: `${((price - minPrice) / range) * 100}%`,
                  minHeight: "4px"
                }}
              />
            ))}
          </div>

          {/* Result */}
          {result && (
            <div className={cn(
              "text-center py-2 rounded-lg font-bold",
              result === "correct" 
                ? "bg-neon-green/20 text-neon-green" 
                : "bg-neon-red/20 text-neon-red"
            )}>
              {result === "correct" ? "Correct!" : "Mauvaise prédiction!"}
            </div>
          )}

          {/* Question */}
          <p className="text-center text-sm text-muted-foreground">
            Quelle est la tendance dominante?
          </p>

          {/* Buttons */}
          <div className="flex gap-4">
            <button
              onClick={() => handleGuess("up")}
              disabled={guess !== null}
              className="flex-1 py-3 rounded-lg bg-neon-green/20 text-neon-green font-bold hover:bg-neon-green/30 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <TrendingUp className="h-5 w-5" />
              HAUSSIÈRE
            </button>
            <button
              onClick={() => handleGuess("down")}
              disabled={guess !== null}
              className="flex-1 py-3 rounded-lg bg-neon-red/20 text-neon-red font-bold hover:bg-neon-red/30 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <TrendingDown className="h-5 w-5" />
              BAISSIÈRE
            </button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// Mini-game: Support/Resistance
function SupportResistanceGame() {
  const [level, setLevel] = useState(50)
  const [prices, setPrices] = useState<number[]>([])
  const [guess, setGuess] = useState<"support" | "resistance" | null>(null)
  const [result, setResult] = useState<"correct" | "wrong" | null>(null)
  const [score, setScore] = useState(0)

  const generateLevel = useCallback(() => {
    const isSupport = Math.random() > 0.5
    const baseLevel = 50
    let currentPrice = isSupport ? baseLevel + 10 : baseLevel - 10
    const newPrices: number[] = []
    
    for (let i = 0; i < 20; i++) {
      if (isSupport && currentPrice < baseLevel) {
        currentPrice = baseLevel + Math.random() * 5 // Bounce off support
      } else if (!isSupport && currentPrice > baseLevel) {
        currentPrice = baseLevel - Math.random() * 5 // Bounce off resistance
      }
      currentPrice += (Math.random() - 0.5) * 4
      newPrices.push(currentPrice)
    }
    
    setLevel(baseLevel)
    setPrices(newPrices)
    setGuess(null)
    setResult(null)
  }, [])

  useEffect(() => {
    generateLevel()
  }, [generateLevel])

  const handleGuess = (type: "support" | "resistance") => {
    setGuess(type)
    const avgPrice = prices.reduce((a, b) => a + b, 0) / prices.length
    const actualType = avgPrice > level ? "support" : "resistance"
    const correct = type === actualType
    
    if (correct) {
      setScore(prev => prev + 10)
      setResult("correct")
    } else {
      setResult("wrong")
    }

    setTimeout(() => generateLevel(), 2000)
  }

  return (
    <Card className="bg-card/50 border-border/50 backdrop-blur">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-foreground">
            <BarChart3 className="h-5 w-5 text-accent" />
            Support ou Résistance?
          </div>
          <span className="text-sm text-accent">Score: {score}</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Chart */}
          <div className="h-32 bg-secondary/30 rounded-lg p-4 relative flex items-end gap-0.5">
            {/* Level line */}
            <div 
              className="absolute left-4 right-4 h-0.5 bg-accent"
              style={{ bottom: `${((level - 30) / 40) * 100}%` }}
            />
            
            {/* Price bars */}
            {prices.map((price, idx) => (
              <div
                key={idx}
                className="flex-1 bg-primary/70 rounded-t"
                style={{ 
                  height: `${((price - 30) / 40) * 100}%`,
                  minHeight: "2px"
                }}
              />
            ))}
          </div>

          {/* Result */}
          {result && (
            <div className={cn(
              "text-center py-2 rounded-lg font-bold",
              result === "correct" 
                ? "bg-neon-green/20 text-neon-green" 
                : "bg-neon-red/20 text-neon-red"
            )}>
              {result === "correct" ? "Correct!" : "Incorrect!"}
            </div>
          )}

          {/* Question */}
          <p className="text-center text-sm text-muted-foreground">
            La ligne jaune agit comme...
          </p>

          {/* Buttons */}
          <div className="flex gap-4">
            <button
              onClick={() => handleGuess("support")}
              disabled={guess !== null}
              className="flex-1 py-3 rounded-lg bg-neon-green/20 text-neon-green font-bold hover:bg-neon-green/30 transition-colors disabled:opacity-50"
            >
              SUPPORT
            </button>
            <button
              onClick={() => handleGuess("resistance")}
              disabled={guess !== null}
              className="flex-1 py-3 rounded-lg bg-neon-red/20 text-neon-red font-bold hover:bg-neon-red/30 transition-colors disabled:opacity-50"
            >
              RÉSISTANCE
            </button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// Main Trading Games Component
export function TradingMiniGames() {
  return (
    <div className="space-y-6 p-4 lg:p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground text-glow-blue flex items-center gap-2">
            <Gamepad2 className="h-6 w-6 text-primary" />
            Mini-Jeux Trading
          </h2>
          <p className="text-sm text-muted-foreground">
            Entraînez votre psychologie de marché et reconnaissance de patterns
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-accent" />
          <span className="text-sm text-accent font-bold">Mode Gamification</span>
        </div>
      </div>

      {/* Games Grid */}
      <div className="grid lg:grid-cols-2 gap-6">
        <PatternRecognitionGame />
        <SpeedTradingGame />
        <TrendPredictionGame />
        <SupportResistanceGame />
      </div>
    </div>
  )
}
