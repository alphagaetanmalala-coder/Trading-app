"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { 
  Newspaper, 
  Quote, 
  ChevronLeft, 
  ChevronRight,
  TrendingUp,
  Star,
  BookOpen,
  ScrollText
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

// Legendary Trader Quotes
const TRADER_QUOTES = [
  {
    quote: "Le temps est le facteur le plus important. Tout le monde parle de prix, mais c'est le temps qui détermine les changements de tendance.",
    author: "W.D. Gann",
    title: "Maître des Cycles"
  },
  {
    quote: "Les marchés sont constamment dans un état d'incertitude et de flux, et l'argent se fait en actualisant l'évident et en pariant sur l'inattendu.",
    author: "George Soros",
    title: "Le Géant des Hedges"
  },
  {
    quote: "La bourse est remplie d'individus qui connaissent le prix de tout, mais la valeur de rien.",
    author: "Philip Fisher",
    title: "Père de l'Investissement Value"
  },
  {
    quote: "Le marché boursier est un appareil de transfert d'argent des impatients vers les patients.",
    author: "Warren Buffett",
    title: "Oracle d'Omaha"
  },
  {
    quote: "Il y a un temps pour aller long, un temps pour aller short, et un temps pour aller pêcher.",
    author: "Jesse Livermore",
    title: "Le Grand Spéculateur"
  },
  {
    quote: "Le trading exige une discipline de fer. Les émotions sont l'ennemi du trader.",
    author: "Paul Tudor Jones",
    title: "Légende du Macro Trading"
  },
  {
    quote: "Coupez vos pertes rapidement et laissez courir vos profits.",
    author: "Richard Dennis",
    title: "Créateur des Turtle Traders"
  },
  {
    quote: "L'astrologie était pratiquée par les plus grands banquiers. J.P. Morgan ne prenait jamais une décision importante sans consulter les étoiles.",
    author: "W.D. Gann",
    title: "Maître des Cycles"
  },
  {
    quote: "Les cycles planétaires gouvernent tout ce qui vit. Les marchés ne font pas exception.",
    author: "W.D. Gann",
    title: "Maître des Cycles"
  },
  {
    quote: "La géométrie des prix révèle l'ordre caché des marchés.",
    author: "W.D. Gann",
    title: "Maître des Cycles"
  }
]

// Biblical verses on commerce and wealth
const BIBLICAL_VERSES = [
  {
    verse: "Un homme habile dans son travail se tiendra devant les rois.",
    reference: "Proverbes 22:29",
    theme: "Excellence"
  },
  {
    verse: "L'âme généreuse sera rassasiée, et celui qui arrose sera lui-même arrosé.",
    reference: "Proverbes 11:25",
    theme: "Générosité"
  },
  {
    verse: "Les projets de l'homme diligent ne mènent qu'à l'abondance.",
    reference: "Proverbes 21:5",
    theme: "Diligence"
  },
  {
    verse: "Ne te fatigue pas pour acquérir la richesse; cesse d'y appliquer ta sagesse.",
    reference: "Proverbes 23:4",
    theme: "Sagesse"
  },
  {
    verse: "Celui qui garde l'instruction est dans le chemin de la vie.",
    reference: "Proverbes 10:17",
    theme: "Discipline"
  },
  {
    verse: "La richesse acquise à la hâte diminue, mais celui qui amasse peu à peu l'augmente.",
    reference: "Proverbes 13:11",
    theme: "Patience"
  },
  {
    verse: "Le commencement de la sagesse, c'est la crainte de l'Éternel.",
    reference: "Proverbes 9:10",
    theme: "Humilité"
  },
  {
    verse: "Va vers la fourmi, paresseux; considère ses voies, et deviens sage.",
    reference: "Proverbes 6:6",
    theme: "Travail"
  }
]

// Ancient Sidereal Systems Micro-Lessons
const SIDEREAL_LESSONS = [
  {
    system: "Chaldéen",
    title: "Les Babyloniens et l'Origine de l'Astrologie Financière",
    content: "Les Chaldéens de Babylone (1000-500 av. J.-C.) ont créé le premier système zodiacal. Ils observaient que les mouvements de Jupiter et Saturne coïncidaient avec les cycles économiques. Leur ayanamsa original différait du tropical de 23° environ.",
    keyPrinciple: "Jupiter = Expansion économique | Saturne = Contraction et prudence"
  },
  {
    system: "Mésopotamien",
    title: "Les Tablettes de Mul.Apin et les Cycles Célestes",
    content: "Les tablettes Mul.Apin (1000 av. J.-C.) cataloguaient les étoiles fixes et leurs influences sur les récoltes et le commerce. Les prêtres-astrologues conseillaient les rois sur les périodes propices aux échanges commerciaux.",
    keyPrinciple: "Les étoiles fixes marquent les points de retournement majeurs"
  },
  {
    system: "Égyptien",
    title: "Le Zodiaque de Dendérah et les Décans",
    content: "Les Égyptiens utilisaient 36 décans (divisions de 10°) pour leur astrologie. Le lever héliaque de Sirius marquait le début de l'année et la crue du Nil - un événement économique crucial. Leur système était purement sidéral.",
    keyPrinciple: "Sirius = Renouveau et abondance | Décans = Timing précis"
  },
  {
    system: "Indien (Jyotish)",
    title: "Le Système Lahiri et les Nakshatras",
    content: "L'astrologie védique utilise l'ayanamsa Lahiri (environ 24°) et 27 nakshatras (demeures lunaires). Chaque nakshatra a un maître planétaire influençant différemment le commerce et la richesse.",
    keyPrinciple: "Pushya nakshatra = Meilleur pour la croissance | Ashlesha = Prudence requise"
  },
  {
    system: "Grec Ancien",
    title: "L'Héritage Ptolémaïque et le Zodiaque Sidéral",
    content: "Avant Ptolémée, les Grecs utilisaient le zodiaque sidéral. Hipparchos a découvert la précession mais les astrologues sidéraux ont maintenu le système originel aligné sur les étoiles fixes pour une plus grande précision prédictive.",
    keyPrinciple: "Regulus (étoile royale) = Pouvoir et succès | Algol = Volatilité extrême"
  }
]

// Financial News Feed
const FINANCIAL_NEWS = [
  { title: "Fed maintient les taux - Impact sur USD", impact: "high", time: "Il y a 2h" },
  { title: "BCE annonce QT accéléré - EUR en hausse", impact: "high", time: "Il y a 4h" },
  { title: "Chine: PMI manufacturier dépasse les attentes", impact: "medium", time: "Il y a 6h" },
  { title: "Or atteint un nouveau record historique", impact: "high", time: "Il y a 8h" },
  { title: "BOJ intervient sur le marché des changes", impact: "high", time: "Il y a 10h" },
  { title: "Pétrole: OPEC+ envisage réduction de production", impact: "medium", time: "Il y a 12h" },
  { title: "Données emploi US meilleures qu'attendu", impact: "high", time: "Hier" },
  { title: "Sterling sous pression après données inflation", impact: "medium", time: "Hier" },
]

// Image carousel URLs (placeholder descriptions)
const CAROUSEL_IMAGES = [
  {
    id: 1,
    description: "Trading floor with multiple screens",
    gradient: "from-blue-900 via-indigo-800 to-purple-900"
  },
  {
    id: 2,
    description: "Wall Street aerial view",
    gradient: "from-amber-900 via-orange-800 to-red-900"
  },
  {
    id: 3,
    description: "Global financial markets",
    gradient: "from-emerald-900 via-teal-800 to-cyan-900"
  },
  {
    id: 4,
    description: "Market charts and analysis",
    gradient: "from-violet-900 via-purple-800 to-fuchsia-900"
  },
  {
    id: 5,
    description: "Economic leadership and markets",
    gradient: "from-rose-900 via-pink-800 to-red-900"
  }
]

export function MediaEsotericFeed() {
  const [currentQuote, setCurrentQuote] = useState(0)
  const [currentImage, setCurrentImage] = useState(0)
  const [currentVerse, setCurrentVerse] = useState(0)
  const [currentLesson, setCurrentLesson] = useState(0)
  const imageTimerRef = useRef<NodeJS.Timeout | null>(null)

  // Rotate quotes every 10 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentQuote(prev => (prev + 1) % TRADER_QUOTES.length)
    }, 10000)
    return () => clearInterval(timer)
  }, [])

  // Rotate verses every 15 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentVerse(prev => (prev + 1) % BIBLICAL_VERSES.length)
    }, 15000)
    return () => clearInterval(timer)
  }, [])

  // Rotate images every 60 seconds
  useEffect(() => {
    imageTimerRef.current = setInterval(() => {
      setCurrentImage(prev => (prev + 1) % CAROUSEL_IMAGES.length)
    }, 60000)
    return () => {
      if (imageTimerRef.current) clearInterval(imageTimerRef.current)
    }
  }, [])

  const nextImage = useCallback(() => {
    setCurrentImage(prev => (prev + 1) % CAROUSEL_IMAGES.length)
    if (imageTimerRef.current) {
      clearInterval(imageTimerRef.current)
      imageTimerRef.current = setInterval(() => {
        setCurrentImage(prev => (prev + 1) % CAROUSEL_IMAGES.length)
      }, 60000)
    }
  }, [])

  const prevImage = useCallback(() => {
    setCurrentImage(prev => (prev - 1 + CAROUSEL_IMAGES.length) % CAROUSEL_IMAGES.length)
    if (imageTimerRef.current) {
      clearInterval(imageTimerRef.current)
      imageTimerRef.current = setInterval(() => {
        setCurrentImage(prev => (prev + 1) % CAROUSEL_IMAGES.length)
      }, 60000)
    }
  }, [])

  const quote = TRADER_QUOTES[currentQuote]
  const verse = BIBLICAL_VERSES[currentVerse]
  const lesson = SIDEREAL_LESSONS[currentLesson]
  const image = CAROUSEL_IMAGES[currentImage]

  return (
    <div className="space-y-6 p-4 lg:p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground text-glow-blue">
            Flux Médias & Ésotérisme
          </h2>
          <p className="text-sm text-muted-foreground">
            Actualités financières, sagesse ancestrale et systèmes sidéraux
          </p>
        </div>
      </div>

      {/* Top Section: Image Carousel + News Feed */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Image Carousel */}
        <Card className="bg-card/50 border-border/50 backdrop-blur overflow-hidden">
          <div className="relative aspect-video">
            <div className={cn(
              "absolute inset-0 bg-gradient-to-br transition-all duration-1000",
              image.gradient
            )}>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center p-8">
                  <TrendingUp className="h-16 w-16 text-white/50 mx-auto mb-4" />
                  <p className="text-white/70 text-lg font-medium">{image.description}</p>
                  <p className="text-white/40 text-sm mt-2">Image {currentImage + 1} / {CAROUSEL_IMAGES.length}</p>
                </div>
              </div>
            </div>
            
            {/* Navigation Arrows */}
            <button 
              onClick={prevImage}
              className="absolute left-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
            >
              <ChevronLeft className="h-6 w-6 text-white" />
            </button>
            <button 
              onClick={nextImage}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
            >
              <ChevronRight className="h-6 w-6 text-white" />
            </button>

            {/* Dots */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
              {CAROUSEL_IMAGES.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentImage(idx)}
                  className={cn(
                    "w-2 h-2 rounded-full transition-all",
                    idx === currentImage ? "bg-white w-6" : "bg-white/50"
                  )}
                />
              ))}
            </div>

            {/* Auto-rotate indicator */}
            <div className="absolute top-4 right-4 px-2 py-1 rounded bg-black/50 text-white/70 text-xs">
              Auto: 60s
            </div>
          </div>
        </Card>

        {/* Financial News Stream */}
        <Card className="bg-card/50 border-border/50 backdrop-blur">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Newspaper className="h-5 w-5 text-primary" />
              Actualités Financières en Direct
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-[280px] overflow-y-auto">
              {FINANCIAL_NEWS.map((news, idx) => (
                <div 
                  key={idx}
                  className={cn(
                    "flex items-start justify-between p-3 rounded-lg transition-all hover:scale-[1.02]",
                    news.impact === "high" 
                      ? "bg-neon-red/10 border border-neon-red/20" 
                      : "bg-secondary/30 border border-border/30"
                  )}
                >
                  <div className="flex items-start gap-3">
                    <div className={cn(
                      "w-2 h-2 rounded-full mt-2 flex-shrink-0",
                      news.impact === "high" ? "bg-neon-red animate-pulse" : "bg-primary"
                    )} />
                    <div>
                      <p className="text-sm font-medium text-foreground">{news.title}</p>
                      <p className="text-xs text-muted-foreground">{news.time}</p>
                    </div>
                  </div>
                  <span className={cn(
                    "text-[10px] px-2 py-1 rounded flex-shrink-0",
                    news.impact === "high" 
                      ? "bg-neon-red/20 text-neon-red" 
                      : "bg-primary/20 text-primary"
                  )}>
                    {news.impact === "high" ? "MAJEUR" : "MOYEN"}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Legendary Trader Quote */}
      <Card className="bg-gradient-to-r from-primary/10 via-accent/5 to-primary/10 border-primary/30">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <Quote className="h-10 w-10 text-accent flex-shrink-0" />
            <div className="flex-grow">
              <p className="text-lg italic text-foreground leading-relaxed">
                &ldquo;{quote.quote}&rdquo;
              </p>
              <div className="mt-4 flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-accent/20 flex items-center justify-center">
                  <Star className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="font-bold text-foreground">{quote.author}</p>
                  <p className="text-sm text-accent">{quote.title}</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Biblical Verse */}
      <Card className="bg-gradient-to-r from-amber-500/10 via-orange-500/5 to-amber-500/10 border-amber-500/30">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <ScrollText className="h-10 w-10 text-amber-500 flex-shrink-0" />
            <div className="flex-grow">
              <p className="text-lg italic text-foreground leading-relaxed">
                &ldquo;{verse.verse}&rdquo;
              </p>
              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-500 text-sm font-medium">
                    {verse.theme}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {verse.reference}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sidereal Systems Micro-Lessons */}
      <Card className="bg-card/50 border-border/50 backdrop-blur">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-foreground">
            <BookOpen className="h-5 w-5 text-primary" />
            Micro-Leçons: Systèmes Sidéraux Anciens
            <span className="ml-2 text-xs px-2 py-1 rounded bg-neon-red/20 text-neon-red">
              INTERDIT: Astrologie Tropicale/Occidentale
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Lesson Navigation */}
          <div className="flex flex-wrap gap-2 mb-4">
            {SIDEREAL_LESSONS.map((l, idx) => (
              <button
                key={l.system}
                onClick={() => setCurrentLesson(idx)}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-sm font-medium transition-all",
                  currentLesson === idx
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary/50 text-muted-foreground hover:bg-secondary"
                )}
              >
                {l.system}
              </button>
            ))}
          </div>

          {/* Current Lesson */}
          <div className="p-4 rounded-lg bg-secondary/30 border border-border/30">
            <h4 className="text-lg font-bold text-foreground mb-2">
              {lesson.title}
            </h4>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              {lesson.content}
            </p>
            <div className="p-3 rounded bg-primary/10 border border-primary/20">
              <p className="text-sm font-medium text-primary">
                Principe Clé: {lesson.keyPrinciple}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
