"use client"

import { useState, useEffect, useRef } from "react"
import { Clock, Volume2, VolumeX } from "lucide-react"
import { cn } from "@/lib/utils"

interface MadagascarClockProps {
  showSeconds?: boolean
  showDate?: boolean
  size?: "sm" | "md" | "lg"
  enableSound?: boolean
}

export function MadagascarClock({ 
  showSeconds = true, 
  showDate = true,
  size = "md",
  enableSound = true
}: MadagascarClockProps) {
  const [time, setTime] = useState<Date | null>(null)
  const [soundEnabled, setSoundEnabled] = useState(false)
  const [tick, setTick] = useState(false)
  const audioContextRef = useRef<AudioContext | null>(null)

  // Initialize audio context on user interaction
  const initAudio = () => {
    if (!audioContextRef.current && typeof window !== "undefined") {
      audioContextRef.current = new (window.AudioContext || (window as typeof window & { webkitAudioContext: typeof AudioContext }).webkitAudioContext)()
    }
  }

  // Play tick-tock sound
  const playTick = (isTock: boolean) => {
    if (!soundEnabled || !audioContextRef.current) return

    const ctx = audioContextRef.current
    const oscillator = ctx.createOscillator()
    const gainNode = ctx.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(ctx.destination)

    // Different frequencies for tick and tock
    oscillator.frequency.value = isTock ? 800 : 1200
    oscillator.type = "sine"

    gainNode.gain.setValueAtTime(0.1, ctx.currentTime)
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.05)

    oscillator.start(ctx.currentTime)
    oscillator.stop(ctx.currentTime + 0.05)
  }

  useEffect(() => {
    // Madagascar is UTC+3 (East Africa Time)
    const getMadagascarTime = () => {
      const now = new Date()
      const utc = now.getTime() + now.getTimezoneOffset() * 60000
      return new Date(utc + 3 * 3600000) // UTC+3 for Madagascar
    }

    setTime(getMadagascarTime())

    const timer = setInterval(() => {
      const newTime = getMadagascarTime()
      setTime(newTime)
      setTick(prev => !prev)
      playTick(newTime.getSeconds() % 2 === 0)
    }, 1000)

    return () => clearInterval(timer)
  }, [soundEnabled])

  const toggleSound = () => {
    initAudio()
    setSoundEnabled(prev => !prev)
  }

  if (!time) {
    return (
      <div className={cn(
        "flex items-center gap-2",
        size === "sm" && "text-sm",
        size === "lg" && "text-2xl"
      )}>
        <Clock className="h-4 w-4 animate-pulse" />
        <span className="font-mono">--:--:--</span>
      </div>
    )
  }

  const hours = time.getHours().toString().padStart(2, "0")
  const minutes = time.getMinutes().toString().padStart(2, "0")
  const seconds = time.getSeconds().toString().padStart(2, "0")

  const sizeClasses = {
    sm: "text-sm gap-1",
    md: "text-base gap-2",
    lg: "text-2xl gap-3"
  }

  const iconSizes = {
    sm: "h-3 w-3",
    md: "h-4 w-4",
    lg: "h-6 w-6"
  }

  return (
    <div className="flex flex-col items-end gap-1">
      <div className={cn(
        "flex items-center font-mono",
        sizeClasses[size]
      )}>
        {/* Clock icon with pulse animation */}
        <Clock className={cn(
          iconSizes[size],
          "text-primary",
          tick && "animate-pulse"
        )} />
        
        {/* Time display */}
        <div className="flex items-center">
          <span className={cn(
            "transition-all duration-100",
            tick ? "text-foreground" : "text-foreground/80"
          )}>
            {hours}
          </span>
          <span className={cn(
            "mx-0.5 transition-opacity duration-500",
            tick ? "opacity-100 text-primary" : "opacity-30"
          )}>
            :
          </span>
          <span className={cn(
            "transition-all duration-100",
            !tick ? "text-foreground" : "text-foreground/80"
          )}>
            {minutes}
          </span>
          {showSeconds && (
            <>
              <span className={cn(
                "mx-0.5 transition-opacity duration-500",
                !tick ? "opacity-100 text-primary" : "opacity-30"
              )}>
                :
              </span>
              <span className={cn(
                "transition-all duration-100 text-accent",
                tick && "scale-110"
              )}>
                {seconds}
              </span>
            </>
          )}
        </div>

        {/* Sound toggle */}
        {enableSound && (
          <button
            onClick={toggleSound}
            className="ml-2 p-1 rounded hover:bg-secondary/50 transition-colors"
            title={soundEnabled ? "Couper le son" : "Activer le son"}
          >
            {soundEnabled ? (
              <Volume2 className={cn(iconSizes[size], "text-neon-green")} />
            ) : (
              <VolumeX className={cn(iconSizes[size], "text-muted-foreground")} />
            )}
          </button>
        )}
      </div>

      {/* Date and timezone */}
      {showDate && (
        <div className="text-[10px] text-muted-foreground">
          {time.toLocaleDateString("fr-FR", { 
            weekday: "short", 
            day: "numeric", 
            month: "short" 
          })} - Madagascar (UTC+3)
        </div>
      )}
    </div>
  )
}

// Large display version for dashboard
export function MadagascarClockLarge() {
  const [time, setTime] = useState<Date | null>(null)
  const [tick, setTick] = useState(false)
  const [soundEnabled, setSoundEnabled] = useState(false)
  const audioContextRef = useRef<AudioContext | null>(null)

  const initAudio = () => {
    if (!audioContextRef.current && typeof window !== "undefined") {
      audioContextRef.current = new (window.AudioContext || (window as typeof window & { webkitAudioContext: typeof AudioContext }).webkitAudioContext)()
    }
  }

  const playTick = (isTock: boolean) => {
    if (!soundEnabled || !audioContextRef.current) return

    const ctx = audioContextRef.current
    const oscillator = ctx.createOscillator()
    const gainNode = ctx.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(ctx.destination)

    oscillator.frequency.value = isTock ? 600 : 900
    oscillator.type = "sine"

    gainNode.gain.setValueAtTime(0.08, ctx.currentTime)
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.06)

    oscillator.start(ctx.currentTime)
    oscillator.stop(ctx.currentTime + 0.06)
  }

  useEffect(() => {
    const getMadagascarTime = () => {
      const now = new Date()
      const utc = now.getTime() + now.getTimezoneOffset() * 60000
      return new Date(utc + 3 * 3600000)
    }

    setTime(getMadagascarTime())

    const timer = setInterval(() => {
      const newTime = getMadagascarTime()
      setTime(newTime)
      setTick(prev => !prev)
      playTick(newTime.getSeconds() % 2 === 0)
    }, 1000)

    return () => clearInterval(timer)
  }, [soundEnabled])

  const toggleSound = () => {
    initAudio()
    setSoundEnabled(prev => !prev)
  }

  if (!time) {
    return <div className="text-4xl font-mono">--:--:--</div>
  }

  const hours = time.getHours().toString().padStart(2, "0")
  const minutes = time.getMinutes().toString().padStart(2, "0")
  const seconds = time.getSeconds().toString().padStart(2, "0")

  return (
    <div className="flex flex-col items-center gap-2 p-6 rounded-xl bg-gradient-to-br from-primary/10 via-transparent to-accent/10 border border-primary/20">
      {/* Analog-style visual indicator */}
      <div className="relative w-16 h-16 mb-2">
        <div className="absolute inset-0 rounded-full border-2 border-primary/30" />
        <div className="absolute inset-2 rounded-full border border-primary/20" />
        <div 
          className="absolute top-1/2 left-1/2 w-1 h-6 bg-primary origin-bottom rounded-full transition-transform duration-1000"
          style={{ 
            transform: `translate(-50%, -100%) rotate(${(time.getSeconds() / 60) * 360}deg)` 
          }}
        />
        <div 
          className="absolute top-1/2 left-1/2 w-1.5 h-4 bg-accent origin-bottom rounded-full"
          style={{ 
            transform: `translate(-50%, -100%) rotate(${(time.getMinutes() / 60) * 360}deg)` 
          }}
        />
        <div 
          className="absolute top-1/2 left-1/2 w-2 h-3 bg-foreground origin-bottom rounded-full"
          style={{ 
            transform: `translate(-50%, -100%) rotate(${((time.getHours() % 12) / 12) * 360}deg)` 
          }}
        />
        <div className="absolute top-1/2 left-1/2 w-2 h-2 rounded-full bg-primary -translate-x-1/2 -translate-y-1/2" />
      </div>

      {/* Digital display */}
      <div className="flex items-center font-mono text-4xl lg:text-5xl">
        <span className={cn(
          "transition-all duration-100",
          tick ? "text-foreground" : "text-foreground/70"
        )}>
          {hours}
        </span>
        <span className={cn(
          "mx-1 transition-all duration-300",
          tick ? "opacity-100 text-primary scale-125" : "opacity-40 scale-100"
        )}>
          :
        </span>
        <span className={cn(
          "transition-all duration-100",
          !tick ? "text-foreground" : "text-foreground/70"
        )}>
          {minutes}
        </span>
        <span className={cn(
          "mx-1 transition-all duration-300",
          !tick ? "opacity-100 text-primary scale-125" : "opacity-40 scale-100"
        )}>
          :
        </span>
        <span className={cn(
          "text-accent transition-transform duration-100",
          tick && "scale-110"
        )}>
          {seconds}
        </span>
      </div>

      {/* Label */}
      <div className="text-sm text-muted-foreground flex items-center gap-2">
        <span className="px-2 py-0.5 rounded bg-primary/20 text-primary text-xs font-medium">
          MADAGASCAR
        </span>
        <span>UTC+3</span>
      </div>

      {/* Date */}
      <div className="text-sm text-foreground/80">
        {time.toLocaleDateString("fr-FR", { 
          weekday: "long", 
          day: "numeric", 
          month: "long",
          year: "numeric"
        })}
      </div>

      {/* Sound toggle */}
      <button
        onClick={toggleSound}
        className={cn(
          "flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-colors",
          soundEnabled 
            ? "bg-neon-green/20 text-neon-green" 
            : "bg-secondary/50 text-muted-foreground hover:bg-secondary"
        )}
      >
        {soundEnabled ? (
          <>
            <Volume2 className="h-4 w-4" />
            Son: ON
          </>
        ) : (
          <>
            <VolumeX className="h-4 w-4" />
            Son: OFF
          </>
        )}
      </button>
    </div>
  )
}
