"use client"

import { useState } from "react"
import { 
  BookOpen, 
  ChevronDown,
  ChevronRight,
  TrendingUp,
  Sparkles,
  BarChart3,
  Target,
  Layers,
  Clock
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface Section {
  id: string
  title: string
  icon: React.ElementType
  content: ContentItem[]
}

interface ContentItem {
  title: string
  description: string
  details?: string[]
}

const educationalContent: Section[] = [
  {
    id: "ict-smc",
    title: "ICT / SMC (Smart Money Concepts)",
    icon: Target,
    content: [
      {
        title: "CHOCH (Change of Character)",
        description: "Un CHOCH se produit lorsque le prix casse une structure précédente dans la direction opposée, signalant un potentiel changement de tendance.",
        details: [
          "Identifiez le dernier plus haut (pour une tendance haussière) ou plus bas (pour une tendance baissière)",
          "Attendez que le prix casse ce niveau avec conviction",
          "Le CHOCH est confirmé à la clôture de la bougie",
          "Utilisez comme signal de retournement potentiel"
        ]
      },
      {
        title: "BOS (Break of Structure)",
        description: "Le BOS représente la continuation de la tendance actuelle par la cassure d'un niveau structurel clé.",
        details: [
          "En tendance haussière: cassure du dernier plus haut",
          "En tendance baissière: cassure du dernier plus bas",
          "Confirme la direction du mouvement institutionnel",
          "Utilisez pour les entrées en continuation de tendance"
        ]
      },
      {
        title: "FVG (Fair Value Gap)",
        description: "Zone de déséquilibre créée par un mouvement impulsif rapide, laissant un gap entre les mèches des bougies.",
        details: [
          "Se forme quand le corps d'une bougie ne chevauche pas la mèche de la bougie précédente",
          "Représente une zone où le prix n'a pas été efficacement négocié",
          "Le prix revient souvent combler ces gaps",
          "Utilisez comme zones d'entrée potentielles"
        ]
      },
      {
        title: "OB (Order Block)",
        description: "Dernière bougie opposée avant un mouvement impulsif majeur, représentant l'accumulation institutionnelle.",
        details: [
          "Identifiez la dernière bougie baissière avant une impulsion haussière (et vice versa)",
          "Marquez la zone du corps de cette bougie",
          "Les institutions reviennent souvent à ces niveaux pour accumuler",
          "Combiné avec FVG = zone d'entrée haute probabilité"
        ]
      },
      {
        title: "BB (Breaker Block)",
        description: "Un Order Block qui a échoué et a été cassé, devenant maintenant une zone de résistance/support.",
        details: [
          "Ancien OB qui n'a pas tenu",
          "Agit maintenant dans la direction opposée",
          "Confirme l'invalidation de la structure précédente",
          "Zone de retournement potentiel"
        ]
      },
      {
        title: "RB (Rejection Block)",
        description: "Zone de rejet marquée par de longues mèches, indiquant une forte présence institutionnelle.",
        details: [
          "Identifiez les bougies avec de longues mèches de rejet",
          "La mèche représente l'absorption de liquidité",
          "Indique où les institutions ont défendu un niveau",
          "Zone de support/résistance forte"
        ]
      }
    ]
  },
  {
    id: "dow-theory",
    title: "Théorie de Dow",
    icon: TrendingUp,
    content: [
      {
        title: "Les Six Principes de Dow",
        description: "La théorie de Dow est la base de l'analyse technique moderne, établissant les fondements de l'analyse des tendances.",
        details: [
          "1. Le marché actualise tout: tous les facteurs sont déjà reflétés dans le prix",
          "2. Trois types de tendances: primaire, secondaire, mineure",
          "3. Tendance primaire en trois phases: accumulation, participation, distribution",
          "4. Les indices doivent se confirmer mutuellement",
          "5. Le volume confirme la tendance",
          "6. La tendance continue jusqu'à preuve du contraire"
        ]
      },
      {
        title: "Structure Haussière",
        description: "Une tendance haussière est définie par des plus hauts et des plus bas successivement plus hauts.",
        details: [
          "Higher Highs (HH): chaque sommet dépasse le précédent",
          "Higher Lows (HL): chaque creux est plus haut que le précédent",
          "La tendance reste intacte tant que cette structure est respectée",
          "Un HL qui casse signale un potentiel retournement"
        ]
      },
      {
        title: "Structure Baissière",
        description: "Une tendance baissière est définie par des plus hauts et des plus bas successivement plus bas.",
        details: [
          "Lower Highs (LH): chaque sommet est plus bas que le précédent",
          "Lower Lows (LL): chaque creux est plus bas que le précédent",
          "La tendance reste intacte tant que cette structure est respectée",
          "Un LH qui casse signale un potentiel retournement"
        ]
      }
    ]
  },
  {
    id: "wyckoff",
    title: "Méthode Wyckoff",
    icon: Layers,
    content: [
      {
        title: "Phases d'Accumulation",
        description: "L'accumulation est le processus par lequel les institutions construisent leurs positions avant une hausse.",
        details: [
          "PS (Preliminary Support): premier support après une baisse",
          "SC (Selling Climax): vente panique, volume élevé",
          "AR (Automatic Rally): rebond automatique après SC",
          "ST (Secondary Test): test du niveau SC",
          "Spring: fausse cassure sous le support (piège baissier)",
          "SOS (Sign of Strength): cassure avec volume de la résistance",
          "LPS (Last Point of Support): dernier test avant le markup"
        ]
      },
      {
        title: "Phases de Distribution",
        description: "La distribution est le processus inverse où les institutions liquident leurs positions.",
        details: [
          "PSY (Preliminary Supply): première résistance après une hausse",
          "BC (Buying Climax): achat panique, volume élevé",
          "AR (Automatic Reaction): correction automatique après BC",
          "ST (Secondary Test): test du niveau BC",
          "UTAD (Upthrust After Distribution): fausse cassure au-dessus (piège haussier)",
          "SOW (Sign of Weakness): cassure avec volume du support",
          "LPSY (Last Point of Supply): dernier test avant le markdown"
        ]
      },
      {
        title: "Les Trois Lois de Wyckoff",
        description: "Principes fondamentaux qui gouvernent les mouvements de marché.",
        details: [
          "Loi de l'Offre et de la Demande: le prix se déplace vers l'équilibre",
          "Loi de Cause et Effet: l'accumulation/distribution crée le mouvement",
          "Loi de l'Effort vs Résultat: le volume doit confirmer le prix"
        ]
      }
    ]
  },
  {
    id: "qml-gann",
    title: "QML & Théorie de Gann",
    icon: BarChart3,
    content: [
      {
        title: "Quasimodo Level (QML)",
        description: "Pattern de retournement puissant basé sur une structure de prix spécifique.",
        details: [
          "Formation: HH - LL - LH (pour retournement baissier)",
          "Formation: LL - HH - HL (pour retournement haussier)",
          "Le niveau QML est le point de retournement initial",
          "Offre des entrées à haute probabilité avec SL serré",
          "Souvent combiné avec les Order Blocks ICT"
        ]
      },
      {
        title: "Angles de Gann",
        description: "W.D. Gann a développé des techniques basées sur les relations géométriques temps-prix.",
        details: [
          "1x1 (45°): équilibre parfait entre temps et prix",
          "2x1: le prix monte 2 fois plus vite que le temps",
          "1x2: le temps avance 2 fois plus vite que le prix",
          "Les cassures d'angles signalent des changements de tendance",
          "Utilisez avec les carrés de Gann pour les cibles"
        ]
      },
      {
        title: "Carrés de Gann",
        description: "Outils pour identifier les niveaux de support/résistance et les cycles temporels.",
        details: [
          "Carré de 9: spirale numérique pour les niveaux clés",
          "Les angles cardinaux (0°, 90°, 180°, 270°) sont critiques",
          "Les angles fixes (45°, 135°, 225°, 315°) sont secondaires",
          "Combinaison temps-prix pour les points de retournement"
        ]
      }
    ]
  },
  {
    id: "dorsan",
    title: "Astrologie Financière Sidérale (Jacques Dorsan)",
    icon: Sparkles,
    content: [
      {
        title: "Principes du Zodiaque Sidéral",
        description: "Contrairement au zodiaque tropical, le sidéral est aligné sur les constellations réelles.",
        details: [
          "Utilise l'ayanamsa Lahiri pour la correction (~24°)",
          "Plus précis pour les prédictions financières selon Dorsan",
          "Chaque planète a une influence spécifique sur les marchés",
          "Les aspects planétaires créent des périodes de volatilité"
        ]
      },
      {
        title: "Thèmes Natals des Actifs Financiers",
        description: "Chaque paire de devises ou actif a un thème natal basé sur sa date de création.",
        details: [
          "EUR/USD: 1er janvier 1999 (lancement de l'Euro)",
          "BTC/USD: 3 janvier 2009 (bloc Genesis)",
          "XAU/USD: 15 août 1971 (fin de l'étalon-or)",
          "Les transits sur ces positions indiquent les tendances"
        ]
      },
      {
        title: "Aspects Planétaires et Marchés",
        description: "Les aspects entre planètes créent des influences spécifiques sur les marchés.",
        details: [
          "Conjonction (0°): concentration d'énergie, nouveau cycle",
          "Sextile (60°): harmonie, opportunités",
          "Carré (90°): tension, volatilité, défis",
          "Trigone (120°): flux facile, tendances fortes",
          "Opposition (180°): polarité, points de retournement"
        ]
      },
      {
        title: "Planètes et Leur Influence",
        description: "Chaque planète gouverne des aspects spécifiques de l'activité financière.",
        details: [
          "Soleil: tendance générale, leadership du marché",
          "Lune: émotions, volatilité à court terme",
          "Mercure: communication, transactions (attention aux rétrogrades!)",
          "Vénus: valeur, argent, relations financières",
          "Mars: action, agressivité, mouvements brusques",
          "Jupiter: expansion, croissance, optimisme",
          "Saturne: restrictions, prudence, contractions"
        ]
      },
      {
        title: "Rétrogrades et Trading",
        description: "Les périodes rétrogrades affectent différemment les marchés selon la planète.",
        details: [
          "Mercure rétrograde: évitez les nouvelles positions, erreurs de communication",
          "Vénus rétrograde: révision des valeurs, corrections de marché",
          "Mars rétrograde: diminution de l'activité, consolidation",
          "Jupiter/Saturne rétrogrades: révision des tendances à long terme"
        ]
      }
    ]
  },
  {
    id: "integration",
    title: "Intégration des Méthodes",
    icon: Clock,
    content: [
      {
        title: "Confluence Multi-Méthodes",
        description: "La puissance de notre système réside dans l'exigence de confluence de TOUTES les méthodes.",
        details: [
          "ICT/SMC: Identifie les zones institutionnelles",
          "Dow: Confirme la direction de la tendance",
          "Wyckoff: Détermine la phase du marché",
          "QML/Gann: Précise les niveaux d'entrée",
          "Dorsan: Valide le timing astrologique"
        ]
      },
      {
        title: "Processus de Validation",
        description: "Un signal n'est généré que si TOUTES les conditions sont réunies.",
        details: [
          "1. Structure ICT/SMC alignée (CHOCH/BOS + FVG/OB)",
          "2. Tendance Dow confirmée",
          "3. Phase Wyckoff favorable (Accumulation/Spring)",
          "4. Niveau QML ou angle Gann présent",
          "5. Aspects sidéraux favorables (pas de rétrogrades majeurs)"
        ]
      },
      {
        title: "Gestion du Risque",
        description: "Même avec une confluence parfaite, la gestion du risque reste primordiale.",
        details: [
          "Risque maximum par trade: 1-2% du capital",
          "Ratio Risque/Récompense minimum: 1:3",
          "Stop-Loss basé sur la structure technique",
          "Take-Profit basé sur les niveaux de Gann",
          "Ne jamais augmenter une position perdante"
        ]
      }
    ]
  }
]

export function EducationalSection() {
  const [expandedSections, setExpandedSections] = useState<string[]>(["ict-smc"])
  const [expandedItems, setExpandedItems] = useState<string[]>([])

  const toggleSection = (id: string) => {
    setExpandedSections(prev => 
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    )
  }

  const toggleItem = (id: string) => {
    setExpandedItems(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    )
  }

  return (
    <div className="space-y-6 p-4 lg:p-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-foreground text-glow-blue flex items-center gap-2">
          <BookOpen className="h-6 w-6 text-primary" />
          Section Éducative
        </h2>
        <p className="text-sm text-muted-foreground">
          Comprenez les méthodes utilisées par notre moteur d&apos;analyse
        </p>
      </div>

      {/* Content */}
      <div className="space-y-4">
        {educationalContent.map((section) => (
          <Card 
            key={section.id}
            className="bg-card/50 border-border/50 backdrop-blur overflow-hidden"
          >
            <CardHeader 
              className="cursor-pointer hover:bg-secondary/30 transition-colors"
              onClick={() => toggleSection(section.id)}
            >
              <CardTitle className="flex items-center justify-between text-foreground">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <section.icon className="h-5 w-5 text-primary" />
                  </div>
                  {section.title}
                </div>
                {expandedSections.includes(section.id) ? (
                  <ChevronDown className="h-5 w-5 text-muted-foreground" />
                ) : (
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                )}
              </CardTitle>
            </CardHeader>

            {expandedSections.includes(section.id) && (
              <CardContent className="space-y-4 pt-0">
                {section.content.map((item, index) => {
                  const itemId = `${section.id}-${index}`
                  const isExpanded = expandedItems.includes(itemId)

                  return (
                    <div 
                      key={index}
                      className="border border-border/50 rounded-lg overflow-hidden"
                    >
                      <div 
                        className="p-4 cursor-pointer hover:bg-secondary/30 transition-colors"
                        onClick={() => toggleItem(itemId)}
                      >
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold text-foreground">{item.title}</h4>
                          {isExpanded ? (
                            <ChevronDown className="h-4 w-4 text-muted-foreground" />
                          ) : (
                            <ChevronRight className="h-4 w-4 text-muted-foreground" />
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          {item.description}
                        </p>
                      </div>

                      {isExpanded && item.details && (
                        <div className="px-4 pb-4">
                          <ul className="space-y-2 pt-2 border-t border-border/50">
                            {item.details.map((detail, i) => (
                              <li 
                                key={i}
                                className="flex items-start gap-2 text-sm text-muted-foreground"
                              >
                                <span className="text-primary mt-1">•</span>
                                {detail}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )
                })}
              </CardContent>
            )}
          </Card>
        ))}
      </div>

      {/* Disclaimer */}
      <Card className="bg-accent/5 border-accent/30 backdrop-blur">
        <CardContent className="p-4">
          <p className="text-sm text-muted-foreground leading-relaxed">
            <strong className="text-accent">Avertissement:</strong> Les informations présentées dans cette section sont à but éducatif uniquement. 
            Le trading comporte des risques significatifs de perte en capital. Les performances passées ne garantissent pas les résultats futurs. 
            Consultez toujours un conseiller financier qualifié avant de prendre des décisions d&apos;investissement.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
