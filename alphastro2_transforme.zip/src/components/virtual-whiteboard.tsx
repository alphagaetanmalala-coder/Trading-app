"use client"

import { Lightbulb, BookOpen } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const LESSONS = [
  {
    title: "La liquidité est le carburant",
    body: "Les marchés ne montent pas pour vous récompenser. Ils se déplacent pour atteindre la liquidité. Identifiez où sont les stops (au-dessus des plus hauts, sous les plus bas) — c'est là que le prix va.",
  },
  {
    title: "Le temps est aussi important que le prix",
    body: "W.D. Gann disait : 'le temps gouverne tout'. Un niveau cassé à la mauvaise heure n'est pas valide. Combinez toujours analyse de prix ET de timing (sessions, fixings, news).",
  },
  {
    title: "Votre stop loss est sacré",
    body: "Déplacer un stop loss en cours de trade, c'est mentir à son plan. Le marché ne vous doit rien. Honorez votre risque comme un commerçant honore sa balance.",
  },
  {
    title: "Le R:R structure tout",
    body: "Un trader peut perdre 60% de ses trades et rester profitable s'il maintient un R:R minimum de 3:1. Cherchez d'abord la qualité du ratio, pas la fréquence.",
  },
  {
    title: "Patience institutionnelle",
    body: "Les meilleurs gestionnaires attendent des semaines pour un setup A+. La sur-activité est l'ennemi du capital. Moins, mais mieux.",
  },
  {
    title: "Lire le sentiment, agir contre lui aux extrêmes",
    body: "Quand tout le monde est euphorique, vendez. Quand la peur sature, achetez. C'est inconfortable — donc c'est rentable.",
  },
  {
    title: "Astrologie sidérale & marchés",
    body: "Les aspects carrés/oppositions augmentent la volatilité. Trigones et sextiles favorisent les tendances fluides. Ne tradez jamais une rétrogradation de Mercure sans plan ultra-strict.",
  },
]

export function VirtualWhiteboard() {
  const idx = Math.floor((Date.now() / 86_400_000)) % LESSONS.length
  const lesson = LESSONS[idx]

  return (
    <Card className="bg-gradient-to-br from-accent/10 via-card/50 to-primary/10 border-accent/30 backdrop-blur">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-foreground">
          <Lightbulb className="h-5 w-5 text-accent" />
          Tableau Blanc Virtuel — Micro-leçon du jour
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-start gap-3">
          <BookOpen className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-foreground mb-1">{lesson.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{lesson.body}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
