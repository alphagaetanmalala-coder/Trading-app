"use client"

import { useState, useEffect, useCallback } from "react"
import { 
  Bell, 
  CheckCircle2, 
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Target,
  Shield,
  Award,
  RefreshCw,
  Filter,
  Calendar,
  Newspaper,
  Globe
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { 
  usePlanetaryData,
  generateTradingSignal,
  type TradingSignal
} from "@/lib/trading-engine"
import {
  OANDA_FOREX_PAIRS,
  generateOandaData,
  useForexNews,
  type ForexNews
} from "@/lib/oanda-api"

const OANDA_ASSETS = OANDA_FOREX_PAIRS.map(p => p.displayName)
const TIMEFRAMES = ["M15", "H1", "H4", "D"]

export function SignalEngine() {
  const [signals, setSignals] = useState<TradingSignal[]>([])
  const [scanning, setScanning] = useState(false)
  const [selectedTimeframes, setSelectedTimeframes] = useState<string[]>(["H1", "H4"])
  const [lastScan, setLastScan] = useState<Date | null>(null)

  const { positions, aspects } = usePlanetaryData()

  const { news } = useForexNews()

  const scanForSignals = useCallback(async () => {
    setScanning(true)
    const newSignals: TradingSignal[] = []

    // Scan OANDA Forex pairs
    for (const pair of OANDA_FOREX_PAIRS) {
      for (const tf of selectedTimeframes) {
        // Generate OANDA data for analysis
        const candles = generateOandaData(pair.instrument, tf, 100)

        // Try to generate signal (will only return if ALL validations pass)
        const signal = generateTradingSignal(pair.displayName, tf, candles, positions, aspects)
        if (signal) {
          // Check for conflicting high-impact news
          const relevantNews = news.filter(n => 
            pair.displayName.includes(n.currency) && 
            n.impact === "high" &&
            Math.abs(n.date.getTime() - Date.now()) < 4 * 60 * 60 * 1000 // Within 4 hours
          )
          
          // Add fundamental analysis context
          if (relevantNews.length > 0) {
            signal.justification += ` ATTENTION: News haute impact imminentes pour ${relevantNews.map(n => n.currency).join(", ")} - Prudence recommandée.`
          }
          
          newSignals.push(signal)
        }
      }
    }

    setSignals(newSignals)
    setLastScan(new Date())
    setScanning(false)
  }, [positions, aspects, selectedTimeframes, news])

  useEffect(() => {
    // Initial scan
    if (positions.length > 0) {
      scanForSignals()
    }

    // Auto-scan every 5 minutes
    const interval = setInterval(scanForSignals, 300000)
    return () => clearInterval(interval)
  }, [positions.length, scanForSignals])

  const toggleTimeframe = (tf: string) => {
    setSelectedTimeframes(prev => 
      prev.includes(tf) 
        ? prev.filter(t => t !== tf)
        : [...prev, tf]
    )
  }

  return (
    <div className="space-y-6 p-4 lg:p-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground text-glow-blue">
            Moteur de Signaux Multi-Méthodes
          </h2>
          <p className="text-sm text-muted-foreground">
            Signaux générés uniquement avec 100% de validation croisée
          </p>
        </div>

        <div className="flex items-center gap-4">
          {/* Timeframe Filter */}
          <div className="flex items-center gap-1 bg-secondary/30 rounded-lg p-1">
            {TIMEFRAMES.map((tf) => (
              <button
                key={tf}
                onClick={() => toggleTimeframe(tf)}
                className={cn(
                  "px-3 py-1.5 text-xs font-medium rounded-md transition-all",
                  selectedTimeframes.includes(tf)
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                )}
              >
                {tf}
              </button>
            ))}
          </div>

          {/* Scan Button */}
          <button
            onClick={scanForSignals}
            disabled={scanning}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all",
              scanning
                ? "bg-secondary/50 text-muted-foreground cursor-not-allowed"
                : "bg-primary text-primary-foreground hover:bg-primary/90 glow-blue"
            )}
          >
            <RefreshCw className={cn("h-4 w-4", scanning && "animate-spin")} />
            {scanning ? "Analyse en cours..." : "Scanner les marchés"}
          </button>
        </div>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatusCard
          title="Paires OANDA Analysées"
          value={OANDA_FOREX_PAIRS.length * selectedTimeframes.length}
          icon={Globe}
          color="blue"
        />
        <StatusCard
          title="Signaux Haute Probabilité"
          value={signals.length}
          icon={Bell}
          color={signals.length > 0 ? "gold" : "blue"}
        />
        <StatusCard
          title="Taux de Validation"
          value="100%"
          subtitle="Requis"
          icon={CheckCircle2}
          color="gold"
        />
        <StatusCard
          title="Dernier Scan"
          value={lastScan ? lastScan.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }) : "--:--"}
          icon={RefreshCw}
          color="blue"
        />
      </div>

      {/* Signals or No Signal Message */}
      {signals.length === 0 ? (
        <Card className="bg-card/50 border-border/50 backdrop-blur">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="p-4 rounded-full bg-secondary/50 mb-4">
              <AlertTriangle className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Aucune opportunité à haute probabilité détectée
            </h3>
            <p className="text-sm text-muted-foreground text-center max-w-md">
              Le moteur de signaux attend une confluence parfaite de tous les systèmes 
              (ICT, Dow, QML, Gann, Wyckoff, Dorsan) avant de générer un signal.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {signals.map((signal) => (
            <SignalCard key={signal.id} signal={signal} />
          ))}
        </div>
      )}

      {/* Validation Methods Legend */}
      <Card className="bg-card/50 border-border/50 backdrop-blur">
        <CardHeader className="pb-3">
          <CardTitle className="text-foreground">Méthodes de Validation</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 lg:grid-cols-6 gap-3">
            <ValidationMethod
              name="ICT/SMC"
              description="CHOCH, BOS, FVG, OB"
            />
            <ValidationMethod
              name="Dow Theory"
              description="Phases de marché"
            />
            <ValidationMethod
              name="QML"
              description="Quasimodo Levels"
            />
            <ValidationMethod
              name="Gann"
              description="Angles & Cycles"
            />
            <ValidationMethod
              name="Wyckoff"
              description="Accumulation/Distribution"
            />
            <ValidationMethod
              name="Dorsan Sidéral"
              description="Aspects planétaires"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function StatusCard({ 
  title, 
  value, 
  subtitle,
  icon: Icon, 
  color 
}: { 
  title: string
  value: string | number
  subtitle?: string
  icon: React.ElementType
  color: "blue" | "gold"
}) {
  return (
    <Card className={cn(
      "bg-card/50 border-border/50 backdrop-blur",
      color === "gold" && "border-accent/30"
    )}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs text-muted-foreground mb-1">{title}</p>
            <p className={cn(
              "text-2xl font-bold",
              color === "blue" ? "text-primary" : "text-accent text-glow-gold"
            )}>
              {value}
            </p>
            {subtitle && (
              <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
            )}
          </div>
          <div className={cn(
            "p-2 rounded-lg",
            color === "blue" ? "bg-primary/10" : "bg-accent/10"
          )}>
            <Icon className={cn(
              "h-5 w-5",
              color === "blue" ? "text-primary" : "text-accent"
            )} />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function SignalCard({ signal }: { signal: TradingSignal }) {
  const isLong = signal.direction === "ACHAT"

  return (
    <Card className={cn(
      "bg-card/50 border-border/50 backdrop-blur overflow-hidden",
      isLong ? "border-l-4 border-l-neon-green" : "border-l-4 border-l-neon-red"
    )}>
      <CardContent className="p-0">
        <div className="flex flex-col lg:flex-row">
          {/* Signal Header */}
          <div className={cn(
            "p-4 lg:p-6 lg:w-64 flex-shrink-0",
            isLong ? "bg-neon-green/5" : "bg-neon-red/5"
          )}>
            <div className="flex items-center gap-3 mb-3">
              <div className={cn(
                "p-2 rounded-lg",
                isLong ? "bg-neon-green/20" : "bg-neon-red/20"
              )}>
                {isLong ? (
                  <TrendingUp className="h-6 w-6 text-neon-green" />
                ) : (
                  <TrendingDown className="h-6 w-6 text-neon-red" />
                )}
              </div>
              <div>
                <h3 className="text-lg font-bold text-foreground">{signal.asset}</h3>
                <p className="text-sm text-muted-foreground">{signal.timeframe}</p>
              </div>
            </div>

            <div className={cn(
              "inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-semibold",
              isLong 
                ? "bg-neon-green/20 text-neon-green" 
                : "bg-neon-red/20 text-neon-red"
            )}>
              {signal.direction}
            </div>

            <div className="mt-4 flex items-center gap-2">
              <Award className="h-4 w-4 text-accent" />
              <span className="text-sm text-foreground">
                Confiance: <span className="font-bold text-accent">{signal.confidence}%</span>
              </span>
            </div>
          </div>

          {/* Signal Details */}
          <div className="p-4 lg:p-6 flex-grow space-y-4">
            {/* Entry, SL, TP */}
            <div className="grid grid-cols-3 gap-4">
              <div className="p-3 rounded-lg bg-secondary/30">
                <div className="flex items-center gap-2 mb-1">
                  <Target className="h-4 w-4 text-primary" />
                  <span className="text-xs text-muted-foreground">Zone d&apos;entrée</span>
                </div>
                <p className="text-sm font-mono font-semibold text-foreground">
                  {signal.entryZone.min.toFixed(5)} - {signal.entryZone.max.toFixed(5)}
                </p>
              </div>

              <div className="p-3 rounded-lg bg-neon-red/10">
                <div className="flex items-center gap-2 mb-1">
                  <Shield className="h-4 w-4 text-neon-red" />
                  <span className="text-xs text-muted-foreground">Stop-Loss</span>
                </div>
                <p className="text-sm font-mono font-semibold text-neon-red">
                  {signal.stopLoss.toFixed(5)}
                </p>
              </div>

              <div className="p-3 rounded-lg bg-neon-green/10">
                <div className="flex items-center gap-2 mb-1">
                  <Target className="h-4 w-4 text-neon-green" />
                  <span className="text-xs text-muted-foreground">Take-Profit</span>
                </div>
                <p className="text-sm font-mono font-semibold text-neon-green">
                  {signal.takeProfit.toFixed(5)}
                </p>
              </div>
            </div>

            {/* Risk/Reward */}
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">Ratio Risque/Récompense:</span>
              <span className="px-3 py-1 rounded-full bg-accent/20 text-accent font-bold">
                1:{signal.riskReward}
              </span>
            </div>

            {/* Validation Status */}
            <div className="flex flex-wrap gap-2">
              {Object.entries(signal.validations).map(([key, valid]) => (
                <span
                  key={key}
                  className={cn(
                    "px-2 py-1 rounded text-xs font-medium",
                    valid
                      ? "bg-neon-green/20 text-neon-green"
                      : "bg-neon-red/20 text-neon-red"
                  )}
                >
                  {key.toUpperCase()}: {valid ? "VALIDÉ" : "NON"}
                </span>
              ))}
            </div>

            {/* Justification */}
            <div className="p-3 rounded-lg bg-secondary/20 border border-border/50">
              <h4 className="text-xs font-semibold text-muted-foreground mb-2 uppercase">
                Justification Technique
              </h4>
              <p className="text-sm text-foreground leading-relaxed">
                {signal.justification}
              </p>
            </div>

            {/* Timestamp */}
            <p className="text-xs text-muted-foreground">
              Signal généré le {signal.timestamp.toLocaleString("fr-FR")}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function ValidationMethod({ name, description }: { name: string; description: string }) {
  return (
    <div className="p-3 rounded-lg bg-secondary/30">
      <div className="flex items-center gap-2 mb-1">
        <CheckCircle2 className="h-4 w-4 text-primary" />
        <span className="text-sm font-medium text-foreground">{name}</span>
      </div>
      <p className="text-xs text-muted-foreground">{description}</p>
    </div>
  )
}
