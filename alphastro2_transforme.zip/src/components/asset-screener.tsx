"use client"

import { useEffect, useMemo, useState } from "react"
import { TrendingUp, TrendingDown, Minus, Radar } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { OANDA_FOREX_PAIRS, generateOandaData } from "@/lib/oanda-api"

const TIMEFRAMES = ["M1", "M5", "M15", "H1", "H4", "D", "W", "M"] as const
type TF = typeof TIMEFRAMES[number]

type Direction = "Haussier" | "Baissier" | "Range"

function ema(values: number[], period: number): number {
  const k = 2 / (period + 1)
  let e = values[0]
  for (let i = 1; i < values.length; i++) e = values[i] * k + e * (1 - k)
  return e
}

function detectDirection(instr: string, tf: TF): Direction {
  const candles = generateOandaData(instr, tf, 60)
  const closes = candles.map((c) => c.close)
  const e20 = ema(closes.slice(-20), 20)
  const e50 = ema(closes, 50)
  const last = closes[closes.length - 1]
  const range = Math.max(...closes.slice(-20)) - Math.min(...closes.slice(-20))
  const atr = range / 20
  const diff = Math.abs(e20 - e50)
  if (diff < atr * 0.6) return "Range"
  if (last > e50 && e20 > e50) return "Haussier"
  if (last < e50 && e20 < e50) return "Baissier"
  return "Range"
}

export function AssetScreener() {
  const [selected, setSelected] = useState<string[]>(
    OANDA_FOREX_PAIRS.slice(0, 10).map((p) => p.instrument),
  )
  const [tick, setTick] = useState(0)
  useEffect(() => {
    const t = setInterval(() => setTick((x) => x + 1), 1000)
    return () => clearInterval(t)
  }, [])

  const rows = useMemo(
    () =>
      selected.map((instr) => ({
        instr,
        display: OANDA_FOREX_PAIRS.find((p) => p.instrument === instr)?.displayName ?? instr,
        cells: TIMEFRAMES.map((tf) => detectDirection(instr, tf)),
      })),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [selected, tick],
  )

  const toggle = (i: string) =>
    setSelected((s) => (s.includes(i) ? s.filter((x) => x !== i) : [...s, i]))

  return (
    <div className="p-4 lg:p-6 space-y-4">
      <Card className="bg-card/50 border-border/50 backdrop-blur">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Radar className="h-5 w-5 text-primary" />
            Screener d'Actifs OANDA — Direction Temps Réel
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {OANDA_FOREX_PAIRS.map((p) => (
              <button
                key={p.instrument}
                onClick={() => toggle(p.instrument)}
                className={cn(
                  "text-xs px-2 py-1 rounded border",
                  selected.includes(p.instrument)
                    ? "bg-primary/20 border-primary text-primary"
                    : "bg-secondary/30 border-border/50 text-muted-foreground",
                )}
              >
                {p.displayName}
              </button>
            ))}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-muted-foreground border-b border-border/50">
                  <th className="py-2 px-2">Paire</th>
                  {TIMEFRAMES.map((tf) => (
                    <th key={tf} className="py-2 px-2 text-center">{tf}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.instr} className="border-b border-border/20">
                    <td className="py-2 px-2 font-semibold text-foreground">{r.display}</td>
                    {r.cells.map((d, i) => (
                      <td key={i} className="py-2 px-2 text-center">
                        <span
                          className={cn(
                            "inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-semibold",
                            d === "Haussier" && "bg-neon-green/15 text-neon-green",
                            d === "Baissier" && "bg-neon-red/15 text-neon-red",
                            d === "Range" && "bg-muted/40 text-muted-foreground",
                          )}
                        >
                          {d === "Haussier" && <TrendingUp className="h-3 w-3" />}
                          {d === "Baissier" && <TrendingDown className="h-3 w-3" />}
                          {d === "Range" && <Minus className="h-3 w-3" />}
                          {d}
                        </span>
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-muted-foreground">
            Mise à jour automatique à la seconde · EMA20/EMA50 + ATR breakout sur données OANDA.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
