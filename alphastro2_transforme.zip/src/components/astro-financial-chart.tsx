"use client"

import { useState, useEffect, useRef } from "react"
import { 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle,
  Bell,
  Calendar,
  Globe,
  Clock,
  Activity,
  Zap,
  Filter,
  RefreshCw
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { 
  useOandaData, 
  useForexNews,
  useMyfxbookSignals,
  OANDA_FOREX_PAIRS,
  type ForexNews,
  type MyfxbookSignal
} from "@/lib/oanda-api"
import {
  usePlanetaryData,
  calculatePlanetaryPositions,
  type PlanetPosition,
  type Aspect
} from "@/lib/trading-engine"

const TIMEFRAMES = ["M1", "M5", "M15", "H1", "H4", "D"]

// Planetary calculation for astro-curve alignment
function calculateAstroCurveValue(positions: PlanetPosition[], aspects: Aspect[], timeOffset: number): number {
  // Base value from planetary positions
  let value = 50
  
  // Sun position influence (main trend)
  const sun = positions.find(p => p.planet === "Soleil")
  if (sun) {
    value += Math.sin((sun.longitude + timeOffset) * Math.PI / 180) * 15
  }
  
  // Moon influence (short-term volatility)
  const moon = positions.find(p => p.planet === "Lune")
  if (moon) {
    value += Math.sin((moon.longitude + timeOffset * 12) * Math.PI / 180) * 10
  }
  
  // Mars influence (energy/momentum)
  const mars = positions.find(p => p.planet === "Mars")
  if (mars) {
    value += Math.sin((mars.longitude + timeOffset * 2) * Math.PI / 180) * 8
  }
  
  // Aspect influences
  aspects.forEach(aspect => {
    if (aspect.type === "trigone" || aspect.type === "sextile") {
      value += (1 - aspect.orb / 10) * 5
    } else if (aspect.type === "carré" || aspect.type === "opposition") {
      value -= (1 - aspect.orb / 10) * 5
    }
  })
  
  // Normalize to 0-100 range
  return Math.max(0, Math.min(100, value))
}

export function AstroFinancialChart() {
  const [selectedPair, setSelectedPair] = useState(OANDA_FOREX_PAIRS[0])
  const [selectedTimeframe, setSelectedTimeframe] = useState("H1")
  const [impactFilter, setImpactFilter] = useState<"all" | "high" | "medium">("all")
  const [showNews, setShowNews] = useState(true)
  
  const { candles, loading, currentPrice } = useOandaData(selectedPair.instrument, selectedTimeframe)
  const { news } = useForexNews()
  const { signals } = useMyfxbookSignals()
  const { positions, aspects } = usePlanetaryData()

  // Filter news based on impact and currency
  const filteredNews = news.filter(n => {
    const currencyMatch = selectedPair.displayName.includes(n.currency)
    const impactMatch = impactFilter === "all" || n.impact === impactFilter || (impactFilter === "medium" && n.impact === "high")
    return currencyMatch && impactMatch
  })

  // Upcoming high-impact news alerts
  const upcomingHighImpact = news.filter(n => {
    const isHighImpact = n.impact === "high"
    const isUpcoming = n.date.getTime() > Date.now() && n.date.getTime() < Date.now() + 24 * 60 * 60 * 1000
    return isHighImpact && isUpcoming
  })

  return (
    <div className="space-y-4 p-4 lg:p-6">
      {/* Header with Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground text-glow-blue flex items-center gap-2">
            <Activity className="h-6 w-6 text-primary" />
            Astro-Graphique TradingView Style
          </h2>
          <p className="text-sm text-muted-foreground">
            Données OANDA + Courbe Sidérale Dorsan alignée temporellement
          </p>
        </div>

        {/* Current Price */}
        {currentPrice && (
          <div className="flex items-center gap-4 p-3 rounded-lg bg-card/50 border border-border/50">
            <div>
              <p className="text-xs text-muted-foreground">Prix Actuel</p>
              <p className="text-xl font-mono font-bold text-foreground">
                {currentPrice.bid.toFixed(selectedPair.instrument.includes("JPY") ? 3 : 5)}
              </p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Spread</p>
              <p className="text-sm font-mono text-accent">
                {(currentPrice.spread * (selectedPair.instrument.includes("JPY") ? 100 : 10000)).toFixed(1)} pips
              </p>
            </div>
          </div>
        )}
      </div>

      {/* High Impact News Alerts */}
      {upcomingHighImpact.length > 0 && (
        <div className="flex items-center gap-3 p-4 rounded-lg bg-neon-red/10 border border-neon-red/30 animate-pulse">
          <AlertTriangle className="h-5 w-5 text-neon-red flex-shrink-0" />
          <div className="flex-grow">
            <p className="text-sm font-semibold text-neon-red">
              Alertes News Haute Impact - Prochaines 24h
            </p>
            <p className="text-xs text-muted-foreground">
              {upcomingHighImpact.map(n => `${n.currency}: ${n.title} (${n.time})`).join(" | ")}
            </p>
          </div>
          <Bell className="h-5 w-5 text-neon-red" />
        </div>
      )}

      {/* Controls */}
      <div className="flex flex-wrap items-center gap-4">
        {/* Pair Selector */}
        <div className="flex items-center gap-2">
          <Globe className="h-4 w-4 text-muted-foreground" />
          <select
            value={selectedPair.instrument}
            onChange={(e) => setSelectedPair(OANDA_FOREX_PAIRS.find(p => p.instrument === e.target.value) || OANDA_FOREX_PAIRS[0])}
            className="bg-secondary/50 border border-border/50 rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <optgroup label="Majeurs">
              {OANDA_FOREX_PAIRS.filter(p => p.category === "major").map(pair => (
                <option key={pair.instrument} value={pair.instrument}>{pair.displayName}</option>
              ))}
            </optgroup>
            <optgroup label="Mineurs">
              {OANDA_FOREX_PAIRS.filter(p => p.category === "minor").map(pair => (
                <option key={pair.instrument} value={pair.instrument}>{pair.displayName}</option>
              ))}
            </optgroup>
            <optgroup label="Matières Premières">
              {OANDA_FOREX_PAIRS.filter(p => p.category === "commodity").map(pair => (
                <option key={pair.instrument} value={pair.instrument}>{pair.displayName}</option>
              ))}
            </optgroup>
          </select>
        </div>

        {/* Timeframe Selector */}
        <div className="flex items-center gap-1 bg-secondary/30 rounded-lg p-1">
          {TIMEFRAMES.map((tf) => (
            <button
              key={tf}
              onClick={() => setSelectedTimeframe(tf)}
              className={cn(
                "px-3 py-1.5 text-xs font-medium rounded-md transition-all",
                selectedTimeframe === tf
                  ? "bg-primary text-primary-foreground glow-blue"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
              )}
            >
              {tf}
            </button>
          ))}
        </div>

        {/* Impact Filter */}
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <select
            value={impactFilter}
            onChange={(e) => setImpactFilter(e.target.value as "all" | "high" | "medium")}
            className="bg-secondary/50 border border-border/50 rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <option value="all">Toutes les news</option>
            <option value="high">Haute impact</option>
            <option value="medium">Impact moyen+</option>
          </select>
        </div>

        {/* News Toggle */}
        <button
          onClick={() => setShowNews(!showNews)}
          className={cn(
            "flex items-center gap-2 px-3 py-2 text-sm rounded-lg transition-all",
            showNews
              ? "bg-accent/20 text-accent"
              : "bg-secondary/50 text-muted-foreground"
          )}
        >
          <Calendar className="h-4 w-4" />
          News Forex Factory
        </button>
      </div>

      {/* Main Chart Area */}
      <div className="grid lg:grid-cols-4 gap-4">
        {/* Synchronized Charts */}
        <div className="lg:col-span-3 space-y-4">
          {/* Financial Chart with Astro Overlay */}
          <Card className="bg-card/50 border-border/50 backdrop-blur">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-foreground">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  {selectedPair.displayName} - Données OANDA
                </CardTitle>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-0.5 bg-neon-green" />
                    <span>Haussier</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-0.5 bg-neon-red" />
                    <span>Baissier</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <SynchronizedFinancialChart 
                candles={candles}
                loading={loading}
                news={showNews ? filteredNews : []}
                isJPY={selectedPair.instrument.includes("JPY")}
              />
            </CardContent>
          </Card>

          {/* Astro Curve Chart - Perfectly Aligned */}
          <Card className="bg-card/50 border-border/50 backdrop-blur">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-foreground">
                  <Zap className="h-5 w-5 text-accent" />
                  Courbe Sidérale Dorsan - Synchronisée
                </CardTitle>
                <div className="text-xs text-muted-foreground">
                  Même axe temporel que le graphique financier
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <SynchronizedAstroChart 
                candles={candles}
                positions={positions}
                aspects={aspects}
              />
            </CardContent>
          </Card>
        </div>

        {/* Side Panel - News & Signals */}
        <div className="space-y-4">
          {/* Forex Factory News */}
          <Card className="bg-card/50 border-border/50 backdrop-blur">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-foreground text-sm">
                <Calendar className="h-4 w-4 text-accent" />
                Calendrier Forex Factory
              </CardTitle>
            </CardHeader>
            <CardContent className="max-h-[300px] overflow-y-auto">
              <div className="space-y-2">
                {filteredNews.slice(0, 10).map((n) => (
                  <NewsItem key={n.id} news={n} />
                ))}
                {filteredNews.length === 0 && (
                  <p className="text-xs text-muted-foreground text-center py-4">
                    Aucune news pour cette paire
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Myfxbook Signals */}
          <Card className="bg-card/50 border-border/50 backdrop-blur">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-foreground text-sm">
                <Bell className="h-4 w-4 text-primary" />
                Signaux Myfxbook
              </CardTitle>
            </CardHeader>
            <CardContent className="max-h-[300px] overflow-y-auto">
              <div className="space-y-2">
                {signals.filter(s => s.pair === selectedPair.displayName || s.pair.replace("/", "_") === selectedPair.instrument).length > 0 ? (
                  signals.filter(s => s.pair === selectedPair.displayName).map((s) => (
                    <SignalItem key={s.id} signal={s} />
                  ))
                ) : (
                  signals.slice(0, 5).map((s) => (
                    <SignalItem key={s.id} signal={s} />
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Astro Summary */}
          <Card className="bg-card/50 border-border/50 backdrop-blur">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-foreground text-sm">
                <Activity className="h-4 w-4 text-accent" />
                Résumé Astrologique
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AstroSummary positions={positions} aspects={aspects} />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function SynchronizedFinancialChart({ 
  candles, 
  loading,
  news,
  isJPY
}: { 
  candles: Array<{ time: number; open: number; high: number; low: number; close: number; volume: number }>
  loading: boolean
  news: ForexNews[]
  isJPY: boolean
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current || candles.length === 0) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const dpr = window.devicePixelRatio || 1
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    ctx.scale(dpr, dpr)

    const width = rect.width
    const height = rect.height
    const padding = { top: 20, right: 80, bottom: 40, left: 10 }

    // Clear canvas with gradient background
    const bgGradient = ctx.createLinearGradient(0, 0, 0, height)
    bgGradient.addColorStop(0, "rgba(15, 17, 25, 0.95)")
    bgGradient.addColorStop(1, "rgba(10, 12, 18, 0.95)")
    ctx.fillStyle = bgGradient
    ctx.fillRect(0, 0, width, height)

    // Calculate price range
    const prices = candles.flatMap(c => [c.high, c.low])
    const minPrice = Math.min(...prices)
    const maxPrice = Math.max(...prices)
    const priceRange = maxPrice - minPrice
    const paddedMin = minPrice - priceRange * 0.05
    const paddedMax = maxPrice + priceRange * 0.05
    const paddedRange = paddedMax - paddedMin

    // Price scale
    const priceToY = (price: number) => 
      padding.top + ((paddedMax - price) / paddedRange) * (height - padding.top - padding.bottom)
    
    const timeToX = (index: number, total: number) =>
      padding.left + (index / (total - 1)) * (width - padding.left - padding.right)

    // Draw grid
    ctx.strokeStyle = "rgba(100, 116, 139, 0.1)"
    ctx.lineWidth = 1
    for (let i = 0; i <= 6; i++) {
      const y = padding.top + (i / 6) * (height - padding.top - padding.bottom)
      ctx.beginPath()
      ctx.moveTo(padding.left, y)
      ctx.lineTo(width - padding.right, y)
      ctx.stroke()

      const price = paddedMax - (i / 6) * paddedRange
      ctx.fillStyle = "rgba(148, 163, 184, 0.7)"
      ctx.font = "10px monospace"
      ctx.textAlign = "left"
      ctx.fillText(price.toFixed(isJPY ? 3 : 5), width - padding.right + 5, y + 3)
    }

    // Draw time labels
    const displayCandles = candles.slice(-100)
    for (let i = 0; i < displayCandles.length; i += Math.floor(displayCandles.length / 6)) {
      const x = timeToX(i, displayCandles.length)
      const time = new Date(displayCandles[i].time)
      ctx.fillStyle = "rgba(148, 163, 184, 0.5)"
      ctx.font = "9px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(time.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }), x, height - 10)
    }

    // Draw candles
    const candleWidth = (width - padding.left - padding.right) / displayCandles.length
    const bodyWidth = candleWidth * 0.7

    displayCandles.forEach((candle, i) => {
      const x = timeToX(i, displayCandles.length)
      const isGreen = candle.close >= candle.open
      
      // Wick
      ctx.strokeStyle = isGreen ? "rgb(34, 197, 94)" : "rgb(239, 68, 68)"
      ctx.lineWidth = 1
      ctx.beginPath()
      ctx.moveTo(x, priceToY(candle.high))
      ctx.lineTo(x, priceToY(candle.low))
      ctx.stroke()

      // Body
      const bodyTop = priceToY(Math.max(candle.open, candle.close))
      const bodyBottom = priceToY(Math.min(candle.open, candle.close))
      const bodyHeight = Math.max(bodyBottom - bodyTop, 1)

      ctx.fillStyle = isGreen ? "rgb(34, 197, 94)" : "rgb(239, 68, 68)"
      ctx.fillRect(x - bodyWidth / 2, bodyTop, bodyWidth, bodyHeight)
    })

    // Draw news markers
    news.forEach(n => {
      const newsTime = n.date.getTime()
      const candleIndex = displayCandles.findIndex(c => Math.abs(c.time - newsTime) < 3600000)
      if (candleIndex >= 0) {
        const x = timeToX(candleIndex, displayCandles.length)
        
        ctx.beginPath()
        ctx.setLineDash([3, 3])
        ctx.strokeStyle = n.impact === "high" ? "rgba(239, 68, 68, 0.5)" : 
                         n.impact === "medium" ? "rgba(255, 193, 7, 0.5)" : "rgba(100, 180, 255, 0.3)"
        ctx.moveTo(x, padding.top)
        ctx.lineTo(x, height - padding.bottom)
        ctx.stroke()
        ctx.setLineDash([])
        
        // News marker
        ctx.fillStyle = n.impact === "high" ? "#EF4444" : 
                       n.impact === "medium" ? "#FFC107" : "#64B5F6"
        ctx.beginPath()
        ctx.arc(x, padding.top + 10, 4, 0, Math.PI * 2)
        ctx.fill()
      }
    })

    // Draw current price line
    const currentPrice = displayCandles[displayCandles.length - 1].close
    const currentY = priceToY(currentPrice)
    ctx.strokeStyle = "rgba(100, 180, 255, 0.8)"
    ctx.lineWidth = 1
    ctx.setLineDash([5, 3])
    ctx.beginPath()
    ctx.moveTo(padding.left, currentY)
    ctx.lineTo(width - padding.right, currentY)
    ctx.stroke()
    ctx.setLineDash([])

    // Price label
    ctx.fillStyle = "rgba(100, 180, 255, 0.9)"
    ctx.fillRect(width - padding.right + 2, currentY - 8, padding.right - 4, 16)
    ctx.fillStyle = "#0F1119"
    ctx.font = "bold 10px monospace"
    ctx.textAlign = "left"
    ctx.fillText(currentPrice.toFixed(isJPY ? 3 : 5), width - padding.right + 5, currentY + 3)

  }, [candles, news, isJPY])

  if (loading) {
    return (
      <div className="h-[350px] flex items-center justify-center bg-secondary/20 rounded-lg">
        <RefreshCw className="h-8 w-8 text-primary animate-spin" />
      </div>
    )
  }

  return (
    <canvas 
      ref={canvasRef}
      className="w-full h-[350px] rounded-lg"
      style={{ imageRendering: "crisp-edges" }}
    />
  )
}

function SynchronizedAstroChart({ 
  candles,
  positions,
  aspects
}: { 
  candles: Array<{ time: number; open: number; high: number; low: number; close: number; volume: number }>
  positions: PlanetPosition[]
  aspects: Aspect[]
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current || candles.length === 0) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const dpr = window.devicePixelRatio || 1
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    ctx.scale(dpr, dpr)

    const width = rect.width
    const height = rect.height
    const padding = { top: 20, right: 80, bottom: 40, left: 10 }

    // Clear canvas
    const bgGradient = ctx.createLinearGradient(0, 0, 0, height)
    bgGradient.addColorStop(0, "rgba(15, 17, 25, 0.95)")
    bgGradient.addColorStop(1, "rgba(10, 12, 18, 0.95)")
    ctx.fillStyle = bgGradient
    ctx.fillRect(0, 0, width, height)

    const displayCandles = candles.slice(-100)
    const timeToX = (index: number, total: number) =>
      padding.left + (index / (total - 1)) * (width - padding.left - padding.right)
    
    const valueToY = (value: number) =>
      padding.top + ((100 - value) / 100) * (height - padding.top - padding.bottom)

    // Draw grid
    ctx.strokeStyle = "rgba(100, 116, 139, 0.1)"
    ctx.lineWidth = 1
    for (let i = 0; i <= 4; i++) {
      const y = padding.top + (i / 4) * (height - padding.top - padding.bottom)
      ctx.beginPath()
      ctx.moveTo(padding.left, y)
      ctx.lineTo(width - padding.right, y)
      ctx.stroke()

      const value = 100 - (i / 4) * 100
      ctx.fillStyle = "rgba(148, 163, 184, 0.7)"
      ctx.font = "10px monospace"
      ctx.textAlign = "left"
      ctx.fillText(value.toFixed(0), width - padding.right + 5, y + 3)
    }

    // Draw reference lines
    ctx.strokeStyle = "rgba(34, 197, 94, 0.3)"
    ctx.setLineDash([5, 5])
    ctx.beginPath()
    ctx.moveTo(padding.left, valueToY(70))
    ctx.lineTo(width - padding.right, valueToY(70))
    ctx.stroke()

    ctx.strokeStyle = "rgba(239, 68, 68, 0.3)"
    ctx.beginPath()
    ctx.moveTo(padding.left, valueToY(30))
    ctx.lineTo(width - padding.right, valueToY(30))
    ctx.stroke()
    ctx.setLineDash([])

    // Draw time labels (same as financial chart)
    for (let i = 0; i < displayCandles.length; i += Math.floor(displayCandles.length / 6)) {
      const x = timeToX(i, displayCandles.length)
      const time = new Date(displayCandles[i].time)
      ctx.fillStyle = "rgba(148, 163, 184, 0.5)"
      ctx.font = "9px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(time.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }), x, height - 10)
    }

    // Calculate and draw astro curve
    const astroPoints: Array<{ x: number; y: number; value: number }> = []
    
    displayCandles.forEach((candle, i) => {
      const timeOffset = i * 0.5 // Simulate time progression for astro curve
      const value = calculateAstroCurveValue(positions, aspects, timeOffset)
      const x = timeToX(i, displayCandles.length)
      const y = valueToY(value)
      astroPoints.push({ x, y, value })
    })

    // Draw filled area under curve
    ctx.beginPath()
    ctx.moveTo(astroPoints[0].x, height - padding.bottom)
    astroPoints.forEach(point => {
      ctx.lineTo(point.x, point.y)
    })
    ctx.lineTo(astroPoints[astroPoints.length - 1].x, height - padding.bottom)
    ctx.closePath()
    
    const fillGradient = ctx.createLinearGradient(0, padding.top, 0, height - padding.bottom)
    fillGradient.addColorStop(0, "rgba(255, 193, 7, 0.2)")
    fillGradient.addColorStop(0.5, "rgba(255, 193, 7, 0.1)")
    fillGradient.addColorStop(1, "rgba(255, 193, 7, 0)")
    ctx.fillStyle = fillGradient
    ctx.fill()

    // Draw main curve
    ctx.beginPath()
    ctx.moveTo(astroPoints[0].x, astroPoints[0].y)
    for (let i = 1; i < astroPoints.length - 1; i++) {
      const xc = (astroPoints[i].x + astroPoints[i + 1].x) / 2
      const yc = (astroPoints[i].y + astroPoints[i + 1].y) / 2
      ctx.quadraticCurveTo(astroPoints[i].x, astroPoints[i].y, xc, yc)
    }
    ctx.lineTo(astroPoints[astroPoints.length - 1].x, astroPoints[astroPoints.length - 1].y)
    
    ctx.strokeStyle = "rgb(255, 193, 7)"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw glow effect
    ctx.shadowColor = "rgb(255, 193, 7)"
    ctx.shadowBlur = 10
    ctx.stroke()
    ctx.shadowBlur = 0

    // Draw current value marker
    const currentValue = astroPoints[astroPoints.length - 1]
    ctx.fillStyle = "rgb(255, 193, 7)"
    ctx.beginPath()
    ctx.arc(currentValue.x, currentValue.y, 6, 0, Math.PI * 2)
    ctx.fill()

    // Value label
    ctx.fillStyle = "rgba(255, 193, 7, 0.9)"
    ctx.fillRect(width - padding.right + 2, currentValue.y - 8, padding.right - 4, 16)
    ctx.fillStyle = "#0F1119"
    ctx.font = "bold 10px monospace"
    ctx.textAlign = "left"
    ctx.fillText(currentValue.value.toFixed(1), width - padding.right + 5, currentValue.y + 3)

    // Labels
    ctx.fillStyle = "rgba(34, 197, 94, 0.7)"
    ctx.font = "9px sans-serif"
    ctx.textAlign = "right"
    ctx.fillText("Zone Haussière", width - padding.right - 5, valueToY(85))
    
    ctx.fillStyle = "rgba(239, 68, 68, 0.7)"
    ctx.fillText("Zone Baissière", width - padding.right - 5, valueToY(15))

  }, [candles, positions, aspects])

  return (
    <canvas 
      ref={canvasRef}
      className="w-full h-[200px] rounded-lg"
      style={{ imageRendering: "crisp-edges" }}
    />
  )
}

function NewsItem({ news }: { news: ForexNews }) {
  const isPast = news.date.getTime() < Date.now()
  
  return (
    <div className={cn(
      "p-2 rounded-lg text-xs border",
      news.impact === "high" 
        ? "bg-neon-red/10 border-neon-red/30" 
        : news.impact === "medium"
          ? "bg-accent/10 border-accent/30"
          : "bg-secondary/30 border-border/50",
      isPast && "opacity-60"
    )}>
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-1">
          <span className={cn(
            "w-2 h-2 rounded-full",
            news.impact === "high" ? "bg-neon-red" : 
            news.impact === "medium" ? "bg-accent" : "bg-primary"
          )} />
          <span className="font-semibold text-foreground">{news.currency}</span>
        </div>
        <span className="text-muted-foreground">{news.time}</span>
      </div>
      <p className="text-foreground mb-1">{news.title}</p>
      <div className="flex gap-3 text-muted-foreground">
        <span>Prévu: {news.forecast}</span>
        <span>Précédent: {news.previous}</span>
        {news.actual && <span className="text-primary">Actuel: {news.actual}</span>}
      </div>
    </div>
  )
}

function SignalItem({ signal }: { signal: MyfxbookSignal }) {
  const isBuy = signal.action === "buy"
  
  return (
    <div className={cn(
      "p-2 rounded-lg text-xs border",
      isBuy ? "bg-neon-green/10 border-neon-green/30" : "bg-neon-red/10 border-neon-red/30"
    )}>
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-2">
          {isBuy ? (
            <TrendingUp className="h-3 w-3 text-neon-green" />
          ) : (
            <TrendingDown className="h-3 w-3 text-neon-red" />
          )}
          <span className="font-semibold text-foreground">{signal.pair}</span>
        </div>
        <span className={cn(
          "px-1.5 py-0.5 rounded text-[10px]",
          signal.status === "active" ? "bg-primary/20 text-primary" :
          signal.status === "closed" ? "bg-secondary/50 text-muted-foreground" :
          "bg-accent/20 text-accent"
        )}>
          {signal.status === "active" ? "Actif" : signal.status === "closed" ? "Fermé" : "En attente"}
        </span>
      </div>
      <div className="grid grid-cols-3 gap-1 text-muted-foreground">
        <span>E: {signal.entry.toFixed(5)}</span>
        <span className="text-neon-red">SL: {signal.stopLoss.toFixed(5)}</span>
        <span className="text-neon-green">TP: {signal.takeProfit.toFixed(5)}</span>
      </div>
      {signal.profit !== undefined && (
        <p className={cn(
          "mt-1 font-medium",
          signal.profit >= 0 ? "text-neon-green" : "text-neon-red"
        )}>
          P/L: {signal.profit >= 0 ? "+" : ""}{signal.profit} pips
        </p>
      )}
    </div>
  )
}

function AstroSummary({ positions, aspects }: { positions: PlanetPosition[]; aspects: Aspect[] }) {
  const favorableAspects = aspects.filter(a => a.type === "trigone" || a.type === "sextile")
  const challengingAspects = aspects.filter(a => a.type === "carré" || a.type === "opposition")
  const retrogrades = positions.filter(p => p.retrograde)
  
  const sentiment = favorableAspects.length > challengingAspects.length ? "positif" : 
                   favorableAspects.length < challengingAspects.length ? "négatif" : "neutre"

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">Sentiment Sidéral</span>
        <span className={cn(
          "text-xs font-semibold px-2 py-0.5 rounded",
          sentiment === "positif" ? "bg-neon-green/20 text-neon-green" :
          sentiment === "négatif" ? "bg-neon-red/20 text-neon-red" :
          "bg-secondary/50 text-muted-foreground"
        )}>
          {sentiment.toUpperCase()}
        </span>
      </div>
      
      <div className="grid grid-cols-2 gap-2">
        <div className="p-2 rounded bg-neon-green/10 text-center">
          <p className="text-lg font-bold text-neon-green">{favorableAspects.length}</p>
          <p className="text-[10px] text-muted-foreground">Aspects favorables</p>
        </div>
        <div className="p-2 rounded bg-neon-red/10 text-center">
          <p className="text-lg font-bold text-neon-red">{challengingAspects.length}</p>
          <p className="text-[10px] text-muted-foreground">Aspects tendus</p>
        </div>
      </div>

      {retrogrades.length > 0 && (
        <div className="p-2 rounded bg-accent/10 border border-accent/30">
          <p className="text-xs text-accent font-medium">Rétrogrades actives:</p>
          <p className="text-xs text-muted-foreground">
            {retrogrades.map(r => r.planet).join(", ")}
          </p>
        </div>
      )}
    </div>
  )
}
