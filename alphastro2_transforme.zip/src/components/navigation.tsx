"use client"

import { useState, useEffect } from "react"
import {
  LayoutDashboard, LineChart, Bell, Sparkles, BookOpen, Menu, X, Activity,
  Newspaper, Gamepad2, Sun, Moon, Radar, Zap, Calendar, BookMarked,
  GraduationCap, Users, CandlestickChart, Briefcase, Monitor,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { NotificationBell } from "@/components/notification-bell"

export type TabId =
  | "dashboard" | "feed" | "charts" | "astro-chart" | "signals"
  | "screener" | "predictive" | "astrology" | "academy" | "games"
  | "calendar" | "scriptures" | "masters" | "education" | "telegram"
  | "tvchart" | "justmarkets" | "metatrader"

interface NavigationProps {
  activeTab: TabId
  onTabChange: (tab: TabId) => void
  theme?: "dark" | "light"
  onToggleTheme?: () => void
}

const tabs: { id: TabId; label: string; icon: React.ElementType }[] = [
  { id: "dashboard", label: "Tableau de bord", icon: LayoutDashboard },
  { id: "tvchart", label: "Chart", icon: CandlestickChart },
  { id: "justmarkets", label: "AlphaMarketbroker", icon: Briefcase },
  { id: "metatrader", label: "Metalphatrader", icon: Monitor },
  { id: "feed", label: "Feed Médias & Ésotérique", icon: Newspaper },
  { id: "charts", label: "Graphique Jacques Dorsan", icon: LineChart },
  { id: "astro-chart", label: "Astro-Chart OANDA", icon: Activity },
  { id: "screener", label: "Screener d'Actifs", icon: Radar },
  { id: "predictive", label: "Moteur Prédictif", icon: Zap },
  { id: "signals", label: "Signaux Multi-Méthodes", icon: Bell },
  { id: "telegram", label: "Telegram Alpha Feed", icon: Bell },
  { id: "astrology", label: "Moteur Sidéral", icon: Sparkles },
  { id: "calendar", label: "Calendrier Économique", icon: Calendar },
  { id: "academy", label: "Académie Interactive", icon: GraduationCap },
  { id: "scriptures", label: "Chroniques Scripturales", icon: BookMarked },
  { id: "masters", label: "Les traders", icon: Users },
  { id: "games", label: "Mini-Jeux", icon: Gamepad2 },
  { id: "education", label: "Éducation Concepts", icon: BookOpen },
]

export function Navigation({ activeTab, onTabChange, theme = "dark", onToggleTheme }: NavigationProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [stamp, setStamp] = useState<{ time: string; date: string } | null>(null)

  useEffect(() => {
    const fmt = () => {
      const d = new Date()
      return {
        time: d.toLocaleTimeString("fr-FR", { timeZone: "Indian/Antananarivo", hour12: false }),
        date: d.toLocaleDateString("fr-FR", {
          timeZone: "Indian/Antananarivo",
          weekday: "long", day: "2-digit", month: "long", year: "numeric",
        }),
      }
    }
    setStamp(fmt())
    const t = setInterval(() => setStamp(fmt()), 1000)
    return () => clearInterval(t)
  }, [])

  return (
    <header className="sticky top-0 z-50 border-b border-border/50 bg-darker-surface/85 backdrop-blur-xl">
      <div className="flex items-center justify-between px-4 py-3 lg:px-6 gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 glow-blue flex-shrink-0">
            <Sparkles className="h-5 w-5 text-primary" />
          </div>
          <div className="min-w-0">
            <h1 className="text-lg font-bold text-foreground text-glow-blue truncate">
              Alpha Gaetan Trading
            </h1>
            <p className="text-[11px] text-muted-foreground truncate">
              Plateforme Sidérale OANDA · Analyse Algorithmique Avancée
            </p>
          </div>
        </div>

        {/* Global clock + calendar (Madagascar) */}
        <div className="hidden md:flex items-center gap-4 flex-shrink-0">
          <div className="text-right leading-tight">
            <div className="font-mono text-base text-foreground tracking-wider">
              {stamp?.time ?? "--:--:--"}
            </div>
            <div className="text-[10px] text-muted-foreground capitalize">
              MG · {stamp?.date ?? "—"}
            </div>
          </div>
          <div className="flex items-center gap-2 px-2 py-1 rounded bg-secondary/40">
            <div className="h-2 w-2 rounded-full bg-neon-green animate-pulse glow-green" />
            <span className="text-[10px] text-muted-foreground">Marchés Ouverts</span>
          </div>
          <NotificationBell />
          {onToggleTheme && (
            <button onClick={onToggleTheme}
              className="p-2 rounded-lg hover:bg-secondary/50 text-foreground" title="Thème">
              {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
          )}
        </div>

        {/* Mobile: bell stays visible next to menu button */}
        <div className="md:hidden flex-shrink-0">
          <NotificationBell />
        </div>

        <button className="lg:hidden p-2 rounded-lg hover:bg-secondary/50 flex-shrink-0"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X className="h-6 w-6 text-foreground" /> : <Menu className="h-6 w-6 text-foreground" />}
        </button>
      </div>

      {/* Desktop tabs row */}
      <nav className="hidden lg:flex items-center gap-1 px-4 lg:px-6 pb-2 overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              "flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium whitespace-nowrap transition-all",
              activeTab === tab.id
                ? "bg-primary/20 text-primary glow-blue"
                : "text-muted-foreground hover:text-foreground hover:bg-secondary/50",
            )}
            title={tab.label}
          >
            <tab.icon className="h-3.5 w-3.5" />
            {tab.label}
          </button>
        ))}
      </nav>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <nav className="lg:hidden border-t border-border/50 bg-darker-surface/95 backdrop-blur-xl max-h-[70vh] overflow-y-auto">
          <div className="px-4 py-3 border-b border-border/40">
            <div className="font-mono text-foreground">{stamp?.time ?? "--:--:--"}</div>
            <div className="text-xs text-muted-foreground capitalize">MG · {stamp?.date ?? "—"}</div>
          </div>
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => { onTabChange(tab.id); setMobileMenuOpen(false) }}
              className={cn(
                "flex items-center gap-3 w-full px-4 py-3 text-sm font-medium transition-all",
                activeTab === tab.id
                  ? "bg-primary/20 text-primary border-l-2 border-primary"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary/50",
              )}
            >
              <tab.icon className="h-5 w-5" />
              {tab.label}
            </button>
          ))}
          {onToggleTheme && (
            <button onClick={onToggleTheme}
              className="flex items-center gap-3 w-full px-4 py-3 text-sm text-foreground hover:bg-secondary/50">
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              Basculer le thème ({theme})
            </button>
          )}
        </nav>
      )}
    </header>
  )
}
