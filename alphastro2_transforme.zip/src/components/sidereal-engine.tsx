"use client"

import { useState, useEffect, useRef } from "react"
import { 
  Sparkles, 
  Moon,
  Sun,
  Clock,
  Calendar,
  Star,
  Activity,
  Info,
  ChevronDown,
  ChevronUp
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { 
  usePlanetaryData,
  ASSET_INCEPTION_DATES,
  calculatePlanetaryPositions,
  calculateAspects,
  getZodiacSign,
  type PlanetPosition,
  type Aspect
} from "@/lib/trading-engine"

const PLANET_SYMBOLS: Record<string, string> = {
  "Soleil": "☉",
  "Lune": "☽",
  "Mercure": "☿",
  "Vénus": "♀",
  "Mars": "♂",
  "Jupiter": "♃",
  "Saturne": "♄",
}

const PLANET_DESCRIPTIONS: Record<string, string> = {
  "Soleil": "Représente l'énergie vitale, la volonté et la tendance générale du marché",
  "Lune": "Influence les émotions collectives et la volatilité à court terme",
  "Mercure": "Gouverne la communication et les transactions commerciales",
  "Vénus": "Associée à la valeur, l'argent et les relations financières",
  "Mars": "Représente l'action, l'agressivité et les mouvements brusques",
  "Jupiter": "Symbole d'expansion, de croissance et d'optimisme",
  "Saturne": "Représente les restrictions, les contractions et la prudence",
}

export function SiderealEngine() {
  const { positions, aspects } = usePlanetaryData()
  const [selectedAsset, setSelectedAsset] = useState("EUR/USD")
  const [showDetails, setShowDetails] = useState<string | null>(null)
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  // Calculate transit aspects to asset natal chart
  const assetInception = ASSET_INCEPTION_DATES[selectedAsset]
  const natalPositions = assetInception ? calculatePlanetaryPositions(assetInception) : []

  // Calculate volatility index based on aspects
  const volatilityIndex = calculateVolatilityIndex(aspects, positions)

  return (
    <div className="space-y-6 p-4 lg:p-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground text-glow-blue flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-accent" />
            Moteur Astrologique Sidéral
          </h2>
          <p className="text-sm text-muted-foreground">
            Méthode Jacques Dorsan - Zodiaque Sidéral (Ayanamsa Lahiri)
          </p>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Temps Universel</p>
            <p className="text-lg font-mono text-foreground">
              {currentTime.toLocaleTimeString("fr-FR")}
            </p>
          </div>
          <div className="p-3 rounded-lg bg-accent/10 glow-gold">
            <Calendar className="h-5 w-5 text-accent" />
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Zodiac Wheel */}
        <Card className="lg:col-span-2 bg-card/50 border-border/50 backdrop-blur">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Star className="h-5 w-5 text-primary" />
              Roue Zodiacale Sidérale Temps Réel
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ZodiacWheel positions={positions} aspects={aspects} />
          </CardContent>
        </Card>

        {/* Volatility Index */}
        <div className="space-y-6">
          <Card className="bg-card/50 border-border/50 backdrop-blur">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-foreground">
                <Activity className="h-5 w-5 text-accent" />
                Indice de Volatilité Sidérale
              </CardTitle>
            </CardHeader>
            <CardContent>
              <VolatilityGauge value={volatilityIndex} />
              <p className="text-sm text-muted-foreground mt-4 text-center">
                {volatilityIndex > 70 
                  ? "Période de haute volatilité attendue"
                  : volatilityIndex > 40
                    ? "Volatilité modérée - Prudence conseillée"
                    : "Période calme - Conditions favorables"}
              </p>
            </CardContent>
          </Card>

          {/* Asset Selection */}
          <Card className="bg-card/50 border-border/50 backdrop-blur">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-foreground">
                <Clock className="h-5 w-5 text-primary" />
                Thème Natal de l&apos;Actif
              </CardTitle>
            </CardHeader>
            <CardContent>
              <select
                value={selectedAsset}
                onChange={(e) => setSelectedAsset(e.target.value)}
                className="w-full bg-secondary/50 border border-border/50 rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 mb-4"
              >
                {Object.keys(ASSET_INCEPTION_DATES).map((asset) => (
                  <option key={asset} value={asset}>
                    {asset}
                  </option>
                ))}
              </select>

              {assetInception && (
                <div className="space-y-2">
                  <p className="text-xs text-muted-foreground">
                    Date de création: {assetInception.toLocaleDateString("fr-FR", { 
                      day: "numeric", 
                      month: "long", 
                      year: "numeric" 
                    })}
                  </p>
                  <div className="p-3 rounded-lg bg-secondary/30">
                    <p className="text-xs text-muted-foreground mb-2">Positions Natales:</p>
                    <div className="space-y-1">
                      {natalPositions.slice(0, 4).map((pos) => (
                        <div key={pos.planet} className="flex items-center justify-between text-xs">
                          <span className="text-foreground">{PLANET_SYMBOLS[pos.planet]} {pos.planet}</span>
                          <span className="text-muted-foreground">{pos.sign} {pos.degree.toFixed(1)}°</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Planetary Positions Table */}
      <Card className="bg-card/50 border-border/50 backdrop-blur">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Sun className="h-5 w-5 text-accent" />
            Positions Planétaires Sidérales en Temps Réel
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {positions.map((pos) => (
              <PlanetCard 
                key={pos.planet} 
                position={pos}
                expanded={showDetails === pos.planet}
                onToggle={() => setShowDetails(showDetails === pos.planet ? null : pos.planet)}
              />
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Aspects Table */}
      <Card className="bg-card/50 border-border/50 backdrop-blur">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Moon className="h-5 w-5 text-primary" />
            Aspects Planétaires Actifs
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border/50">
                  <th className="text-left text-xs text-muted-foreground py-2 px-3">Aspect</th>
                  <th className="text-left text-xs text-muted-foreground py-2 px-3">Type</th>
                  <th className="text-left text-xs text-muted-foreground py-2 px-3">Orbe</th>
                  <th className="text-left text-xs text-muted-foreground py-2 px-3">Influence</th>
                  <th className="text-left text-xs text-muted-foreground py-2 px-3">Impact Marché</th>
                </tr>
              </thead>
              <tbody>
                {aspects.map((aspect, i) => (
                  <AspectRow key={i} aspect={aspect} />
                ))}
                {aspects.length === 0 && (
                  <tr>
                    <td colSpan={5} className="text-center py-8 text-muted-foreground">
                      Aucun aspect majeur actif actuellement
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Dorsan Method Explanation */}
      <Card className="bg-card/50 border-border/50 backdrop-blur">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Info className="h-5 w-5 text-accent" />
            Méthode Jacques Dorsan - Principes Fondamentaux
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h4 className="font-semibold text-foreground">Zodiaque Sidéral vs Tropical</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Contrairement au zodiaque tropical utilisé en astrologie occidentale moderne, 
                le zodiaque sidéral (utilisé par Jacques Dorsan) est aligné sur les 
                constellations réelles. L&apos;ayanamsa Lahiri compense la précession des équinoxes 
                (actuellement ~24°).
              </p>
            </div>
            <div className="space-y-3">
              <h4 className="font-semibold text-foreground">Thèmes Natals des Actifs</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Chaque paire de devises ou actif financier possède un &quot;thème natal&quot; basé sur 
                sa date de création officielle. Les transits planétaires actuels sur ces 
                positions natales indiquent les périodes de volatilité et de changement de tendance.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function ZodiacWheel({ positions, aspects }: { positions: PlanetPosition[]; aspects: Aspect[] }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const dpr = window.devicePixelRatio || 1
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    ctx.scale(dpr, dpr)

    const width = rect.width
    const height = rect.height
    const centerX = width / 2
    const centerY = height / 2
    const radius = Math.min(width, height) / 2 - 50

    // Clear canvas
    ctx.fillStyle = "rgba(15, 17, 25, 0.9)"
    ctx.fillRect(0, 0, width, height)

    // Draw outer glow
    const glowGradient = ctx.createRadialGradient(centerX, centerY, radius * 0.8, centerX, centerY, radius * 1.2)
    glowGradient.addColorStop(0, "transparent")
    glowGradient.addColorStop(0.5, "rgba(100, 180, 255, 0.1)")
    glowGradient.addColorStop(1, "transparent")
    ctx.fillStyle = glowGradient
    ctx.fillRect(0, 0, width, height)

    // Draw zodiac ring
    const signs = ["♈", "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐", "♑", "♒", "♓"]
    const signNames = ["Bélier", "Taureau", "Gémeaux", "Cancer", "Lion", "Vierge", "Balance", "Scorpion", "Sagittaire", "Capricorne", "Verseau", "Poissons"]

    for (let i = 0; i < 12; i++) {
      const startAngle = (i * 30 - 90) * (Math.PI / 180)
      const endAngle = ((i + 1) * 30 - 90) * (Math.PI / 180)
      
      // Sign segment
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius, startAngle, endAngle)
      ctx.arc(centerX, centerY, radius * 0.85, endAngle, startAngle, true)
      ctx.closePath()
      ctx.fillStyle = i % 2 === 0 ? "rgba(100, 180, 255, 0.1)" : "rgba(100, 180, 255, 0.05)"
      ctx.fill()
      ctx.strokeStyle = "rgba(100, 180, 255, 0.3)"
      ctx.lineWidth = 1
      ctx.stroke()

      // Sign symbols
      const symbolAngle = (i * 30 + 15 - 90) * (Math.PI / 180)
      const symbolX = centerX + Math.cos(symbolAngle) * (radius * 0.92)
      const symbolY = centerY + Math.sin(symbolAngle) * (radius * 0.92)
      
      ctx.fillStyle = "rgba(100, 180, 255, 0.8)"
      ctx.font = "16px serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(signs[i], symbolX, symbolY)
    }

    // Draw degree marks
    for (let i = 0; i < 360; i += 5) {
      const angle = (i - 90) * (Math.PI / 180)
      const innerR = i % 30 === 0 ? radius * 0.8 : i % 10 === 0 ? radius * 0.82 : radius * 0.84
      
      ctx.beginPath()
      ctx.moveTo(
        centerX + Math.cos(angle) * innerR,
        centerY + Math.sin(angle) * innerR
      )
      ctx.lineTo(
        centerX + Math.cos(angle) * radius * 0.85,
        centerY + Math.sin(angle) * radius * 0.85
      )
      ctx.strokeStyle = i % 30 === 0 ? "rgba(100, 180, 255, 0.5)" : "rgba(100, 180, 255, 0.2)"
      ctx.lineWidth = i % 30 === 0 ? 2 : 1
      ctx.stroke()
    }

    // Draw inner circles
    [0.7, 0.5, 0.3].forEach(scale => {
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius * scale, 0, Math.PI * 2)
      ctx.strokeStyle = "rgba(100, 180, 255, 0.1)"
      ctx.lineWidth = 1
      ctx.stroke()
    })

    // Draw aspect lines first (behind planets)
    aspects.forEach(aspect => {
      const pos1 = positions.find(p => p.planet === aspect.planet1)
      const pos2 = positions.find(p => p.planet === aspect.planet2)
      if (!pos1 || !pos2) return

      const angle1 = (pos1.longitude - 90) * (Math.PI / 180)
      const angle2 = (pos2.longitude - 90) * (Math.PI / 180)
      
      const r = radius * 0.65

      const x1 = centerX + Math.cos(angle1) * r
      const y1 = centerY + Math.sin(angle1) * r
      const x2 = centerX + Math.cos(angle2) * r
      const y2 = centerY + Math.sin(angle2) * r

      ctx.beginPath()
      ctx.moveTo(x1, y1)
      ctx.lineTo(x2, y2)
      
      if (aspect.type === "trigone" || aspect.type === "sextile") {
        ctx.strokeStyle = "rgba(34, 197, 94, 0.4)"
      } else if (aspect.type === "carré" || aspect.type === "opposition") {
        ctx.strokeStyle = "rgba(239, 68, 68, 0.4)"
      } else {
        ctx.strokeStyle = "rgba(100, 180, 255, 0.4)"
      }
      
      ctx.lineWidth = aspect.exact ? 3 : 2
      ctx.setLineDash(aspect.exact ? [] : [5, 3])
      ctx.stroke()
      ctx.setLineDash([])
    })

    // Draw planets
    const planetColors: Record<string, string> = {
      "Soleil": "#FFD700",
      "Lune": "#E8E8E8",
      "Mercure": "#87CEEB",
      "Vénus": "#FFB6C1",
      "Mars": "#FF6B6B",
      "Jupiter": "#DEB887",
      "Saturne": "#DAA520"
    }

    positions.forEach((pos) => {
      const angle = (pos.longitude - 90) * (Math.PI / 180)
      const planetRadius = radius * 0.65
      const x = centerX + Math.cos(angle) * planetRadius
      const y = centerY + Math.sin(angle) * planetRadius

      // Planet glow
      const gradient = ctx.createRadialGradient(x, y, 0, x, y, 25)
      gradient.addColorStop(0, planetColors[pos.planet] || "#FFFFFF")
      gradient.addColorStop(0.3, `${planetColors[pos.planet]}80` || "#FFFFFF80")
      gradient.addColorStop(1, "transparent")
      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.arc(x, y, 25, 0, Math.PI * 2)
      ctx.fill()

      // Planet symbol
      ctx.fillStyle = "#FFFFFF"
      ctx.font = "bold 16px serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(PLANET_SYMBOLS[pos.planet] || "?", x, y)

      // Retrograde indicator
      if (pos.retrograde) {
        ctx.fillStyle = "#FF6B6B"
        ctx.font = "bold 10px sans-serif"
        ctx.fillText("R", x + 12, y - 12)
      }

      // Position line to edge
      ctx.beginPath()
      ctx.moveTo(x, y)
      ctx.lineTo(
        centerX + Math.cos(angle) * radius * 0.85,
        centerY + Math.sin(angle) * radius * 0.85
      )
      ctx.strokeStyle = `${planetColors[pos.planet]}40` || "#FFFFFF40"
      ctx.lineWidth = 1
      ctx.stroke()
    })

  }, [positions, aspects])

  return (
    <canvas 
      ref={canvasRef}
      className="w-full h-[400px] rounded-lg"
    />
  )
}

function VolatilityGauge({ value }: { value: number }) {
  return (
    <div className="relative">
      <div className="h-4 bg-secondary/50 rounded-full overflow-hidden">
        <div 
          className={cn(
            "h-full transition-all duration-500 rounded-full",
            value > 70 ? "bg-neon-red glow-red" :
            value > 40 ? "bg-accent glow-gold" :
            "bg-neon-green glow-green"
          )}
          style={{ width: `${value}%` }}
        />
      </div>
      <div className="flex justify-between mt-2 text-xs text-muted-foreground">
        <span>Calme</span>
        <span className={cn(
          "font-bold text-lg",
          value > 70 ? "text-neon-red" :
          value > 40 ? "text-accent" :
          "text-neon-green"
        )}>
          {value}%
        </span>
        <span>Volatile</span>
      </div>
    </div>
  )
}

function PlanetCard({ 
  position, 
  expanded,
  onToggle 
}: { 
  position: PlanetPosition
  expanded: boolean
  onToggle: () => void
}) {
  return (
    <div 
      className={cn(
        "p-4 rounded-lg bg-secondary/30 border border-border/50 cursor-pointer transition-all hover:bg-secondary/50",
        expanded && "ring-1 ring-primary/50"
      )}
      onClick={onToggle}
    >
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="text-2xl">{PLANET_SYMBOLS[position.planet]}</span>
          <span className="font-medium text-foreground">{position.planet}</span>
          {position.retrograde && (
            <span className="text-xs px-1.5 py-0.5 rounded bg-neon-red/20 text-neon-red">R</span>
          )}
        </div>
        {expanded ? (
          <ChevronUp className="h-4 w-4 text-muted-foreground" />
        ) : (
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        )}
      </div>

      <div className="text-sm">
        <p className="text-foreground font-mono">
          {position.sign} {position.degree.toFixed(2)}°
        </p>
        <p className="text-xs text-muted-foreground">
          {position.longitude.toFixed(2)}° absolu
        </p>
      </div>

      {expanded && (
        <div className="mt-3 pt-3 border-t border-border/50">
          <p className="text-xs text-muted-foreground leading-relaxed">
            {PLANET_DESCRIPTIONS[position.planet]}
          </p>
        </div>
      )}
    </div>
  )
}

function AspectRow({ aspect }: { aspect: Aspect }) {
  const aspectSymbols: Record<string, string> = {
    "conjonction": "☌",
    "opposition": "☍",
    "carré": "□",
    "trigone": "△",
    "sextile": "⚹"
  }

  const getInfluence = (type: string) => {
    if (type === "trigone" || type === "sextile") return "Harmonieux"
    if (type === "carré" || type === "opposition") return "Tendu"
    return "Neutre"
  }

  const getMarketImpact = (type: string, planets: string[]) => {
    const hasMars = planets.includes("Mars")
    const hasJupiter = planets.includes("Jupiter")
    const hasSaturne = planets.includes("Saturne")
    
    if (type === "carré" || type === "opposition") {
      if (hasMars) return "Volatilité élevée - Mouvements brusques"
      if (hasSaturne) return "Restrictions - Tendance baissière"
      return "Tensions - Prudence recommandée"
    }
    
    if (type === "trigone" || type === "sextile") {
      if (hasJupiter) return "Expansion - Opportunités haussières"
      return "Harmonie - Conditions favorables"
    }
    
    return "Concentration d'énergie - Point d'inflexion"
  }

  return (
    <tr className="border-b border-border/30 hover:bg-secondary/20">
      <td className="py-3 px-3">
        <span className="font-medium text-foreground">
          {PLANET_SYMBOLS[aspect.planet1]} {aspect.planet1} {aspectSymbols[aspect.type]} {PLANET_SYMBOLS[aspect.planet2]} {aspect.planet2}
        </span>
      </td>
      <td className="py-3 px-3">
        <span className={cn(
          "px-2 py-1 rounded text-xs font-medium",
          aspect.type === "trigone" || aspect.type === "sextile"
            ? "bg-neon-green/20 text-neon-green"
            : aspect.type === "carré" || aspect.type === "opposition"
              ? "bg-neon-red/20 text-neon-red"
              : "bg-primary/20 text-primary"
        )}>
          {aspect.type.charAt(0).toUpperCase() + aspect.type.slice(1)}
        </span>
      </td>
      <td className="py-3 px-3 font-mono text-sm text-muted-foreground">
        {aspect.orb.toFixed(2)}°
        {aspect.exact && (
          <span className="ml-2 text-xs text-accent">Exact</span>
        )}
      </td>
      <td className="py-3 px-3 text-sm text-muted-foreground">
        {getInfluence(aspect.type)}
      </td>
      <td className="py-3 px-3 text-sm text-muted-foreground">
        {getMarketImpact(aspect.type, [aspect.planet1, aspect.planet2])}
      </td>
    </tr>
  )
}

function calculateVolatilityIndex(aspects: Aspect[], positions: PlanetPosition[]): number {
  let index = 30 // Base volatility

  // Add volatility for tense aspects
  aspects.forEach(aspect => {
    if (aspect.type === "carré") index += 10
    if (aspect.type === "opposition") index += 15
    if (aspect.exact) index += 5
  })

  // Add volatility for retrogrades
  positions.forEach(pos => {
    if (pos.retrograde) {
      if (pos.planet === "Mercure") index += 10
      if (pos.planet === "Mars") index += 8
    }
  })

  // Check for multiple planet conjunctions
  const conjunctions = aspects.filter(a => a.type === "conjonction")
  index += conjunctions.length * 5

  return Math.min(100, Math.max(0, index))
}
