"use client"

import { useEffect, useState } from "react"
import { 
  TrendingUp, 
  TrendingDown, 
  Activity,
  Clock,
  Zap,
  BarChart3,
  Globe,
  Sparkles,
  AlertTriangle,
  Bell,
  Calendar
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { 
  useMarketData, 
  usePlanetaryData,
  type MarketData,
  type PlanetPosition
} from "@/lib/trading-engine"
import {
  useForexNews,
  OANDA_FOREX_PAIRS
} from "@/lib/oanda-api"

const FOREX_SYMBOLS = OANDA_FOREX_PAIRS.filter(p => p.category === "major").map(p => p.displayName)
const MINOR_SYMBOLS = OANDA_FOREX_PAIRS.filter(p => p.category === "minor").slice(0, 4).map(p => p.displayName)
const COMMODITY_SYMBOLS = OANDA_FOREX_PAIRS.filter(p => p.category === "commodity").map(p => p.displayName)

export function Dashboard() {
  const { data: forexData, loading: forexLoading } = useMarketData(FOREX_SYMBOLS)
  const { data: minorData, loading: minorLoading } = useMarketData(MINOR_SYMBOLS)
  const { data: commodityData, loading: commodityLoading } = useMarketData(COMMODITY_SYMBOLS)
  const { positions, aspects } = usePlanetaryData()
  const { news } = useForexNews()
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  const allData = { ...forexData, ...minorData, ...commodityData }

  // High impact news in next 24 hours
  const upcomingHighImpact = news.filter(n => 
    n.impact === "high" && 
    n.date.getTime() > Date.now() && 
    n.date.getTime() < Date.now() + 24 * 60 * 60 * 1000
  )

  return (
    <div className="space-y-6 p-4 lg:p-6">
      {/* High Impact News Alert */}
      {upcomingHighImpact.length > 0 && (
        <div className="flex items-center gap-3 p-4 rounded-lg bg-neon-red/10 border border-neon-red/30">
          <AlertTriangle className="h-5 w-5 text-neon-red flex-shrink-0" />
          <div className="flex-grow">
            <p className="text-sm font-semibold text-neon-red flex items-center gap-2">
              <Bell className="h-4 w-4" />
              Alertes Forex Factory - News Haute Impact (24h)
            </p>
            <div className="flex flex-wrap gap-2 mt-2">
              {upcomingHighImpact.slice(0, 4).map(n => (
                <span key={n.id} className="text-xs px-2 py-1 rounded bg-neon-red/20 text-foreground">
                  {n.currency}: {n.title} ({n.time})
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Header Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Paires OANDA"
          value={OANDA_FOREX_PAIRS.length.toString()}
          subtitle="Forex + Commodités"
          icon={Globe}
          color="blue"
        />
        <StatCard
          title="News Haute Impact"
          value={upcomingHighImpact.length.toString()}
          subtitle="Prochaines 24h"
          icon={Calendar}
          color={upcomingHighImpact.length > 0 ? "gold" : "blue"}
        />
        <StatCard
          title="Aspects Actifs"
          value={aspects.length.toString()}
          subtitle="Sidéraux"
          icon={Sparkles}
          color="blue"
        />
        <StatCard
          title="Heure Serveur"
          value={currentTime.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
          subtitle={currentTime.toLocaleDateString("fr-FR")}
          icon={Clock}
          color="gold"
        />
      </div>

      {/* Main Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Forex Majors Section */}
        <Card className="lg:col-span-2 bg-card/50 border-border/50 backdrop-blur">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-foreground">
              <BarChart3 className="h-5 w-5 text-primary" />
              Paires Majeures OANDA
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {FOREX_SYMBOLS.map((symbol) => (
                <MarketRow 
                  key={symbol} 
                  data={allData[symbol]} 
                  loading={forexLoading} 
                />
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Planetary Overview */}
        <Card className="bg-card/50 border-border/50 backdrop-blur">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Sparkles className="h-5 w-5 text-accent" />
              Positions Sidérales
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {positions.slice(0, 5).map((pos) => (
                <PlanetRow key={pos.planet} position={pos} />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Grid */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Minor Pairs Section */}
        <Card className="bg-card/50 border-border/50 backdrop-blur">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Activity className="h-5 w-5 text-primary" />
              Paires Mineures OANDA
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {MINOR_SYMBOLS.map((symbol) => (
                <MarketRow 
                  key={symbol} 
                  data={allData[symbol]} 
                  loading={minorLoading}
                  large
                />
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Commodities & News */}
        <div className="space-y-6">
          <Card className="bg-card/50 border-border/50 backdrop-blur">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-foreground">
                <TrendingUp className="h-5 w-5 text-accent" />
                Or & Argent (OANDA)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {COMMODITY_SYMBOLS.map((symbol) => (
                <MarketRow 
                  key={symbol} 
                  data={allData[symbol]} 
                  loading={commodityLoading}
                  large
                />
              ))}
            </CardContent>
          </Card>

          {/* Upcoming News */}
          <Card className="bg-card/50 border-border/50 backdrop-blur">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-foreground">
                <Calendar className="h-5 w-5 text-primary" />
                Calendrier Économique
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {news.slice(0, 5).map((n) => (
                  <div 
                    key={n.id}
                    className={cn(
                      "flex items-center justify-between p-2 rounded-lg",
                      n.impact === "high" ? "bg-neon-red/10 border border-neon-red/20" :
                      n.impact === "medium" ? "bg-accent/10 border border-accent/20" :
                      "bg-secondary/30"
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <span className={cn(
                        "w-2 h-2 rounded-full",
                        n.impact === "high" ? "bg-neon-red" :
                        n.impact === "medium" ? "bg-accent" : "bg-primary"
                      )} />
                      <div>
                        <p className="text-xs font-medium text-foreground">{n.currency}: {n.title}</p>
                        <p className="text-[10px] text-muted-foreground">{n.date.toLocaleDateString("fr-FR")} - {n.time}</p>
                      </div>
                    </div>
                    <span className={cn(
                      "text-[10px] px-1.5 py-0.5 rounded",
                      n.impact === "high" ? "bg-neon-red/20 text-neon-red" :
                      n.impact === "medium" ? "bg-accent/20 text-accent" :
                      "bg-primary/20 text-primary"
                    )}>
                      {n.impact === "high" ? "HAUTE" : n.impact === "medium" ? "MOY" : "BASSE"}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function StatCard({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  color 
}: { 
  title: string
  value: string
  subtitle?: string
  icon: React.ElementType
  color: "blue" | "gold"
}) {
  return (
    <Card className={cn(
      "bg-card/50 border-border/50 backdrop-blur transition-all hover:scale-[1.02]",
      color === "blue" ? "hover:border-primary/50" : "hover:border-accent/50"
    )}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs text-muted-foreground mb-1">{title}</p>
            <p className={cn(
              "text-2xl font-bold",
              color === "blue" ? "text-primary text-glow-blue" : "text-accent text-glow-gold"
            )}>
              {value}
            </p>
            {subtitle && (
              <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
            )}
          </div>
          <div className={cn(
            "p-2 rounded-lg",
            color === "blue" ? "bg-primary/10" : "bg-accent/10"
          )}>
            <Icon className={cn(
              "h-5 w-5",
              color === "blue" ? "text-primary" : "text-accent"
            )} />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function MarketRow({ 
  data, 
  loading,
  large = false 
}: { 
  data?: MarketData
  loading: boolean
  large?: boolean
}) {
  if (loading || !data) {
    return (
      <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/30 animate-pulse">
        <div className="h-4 w-20 bg-muted rounded" />
        <div className="h-4 w-24 bg-muted rounded" />
      </div>
    )
  }

  const isPositive = data.changePercent >= 0

  return (
    <div className={cn(
      "flex items-center justify-between p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors",
      large && "p-4"
    )}>
      <div className="flex items-center gap-3">
        <div className={cn(
          "p-2 rounded-lg",
          isPositive ? "bg-neon-green/10" : "bg-neon-red/10"
        )}>
          {isPositive ? (
            <TrendingUp className={cn("text-neon-green", large ? "h-5 w-5" : "h-4 w-4")} />
          ) : (
            <TrendingDown className={cn("text-neon-red", large ? "h-5 w-5" : "h-4 w-4")} />
          )}
        </div>
        <div>
          <p className={cn("font-semibold text-foreground", large && "text-lg")}>
            {data.symbol}
          </p>
          {large && (
            <p className="text-xs text-muted-foreground">
              H: {data.high.toFixed(5)} | B: {data.low.toFixed(5)}
            </p>
          )}
        </div>
      </div>
      <div className="text-right">
        <p className={cn("font-mono font-semibold", large ? "text-lg" : "text-sm")}>
          {data.price.toFixed(data.symbol.includes("JPY") ? 3 : 5)}
        </p>
        <p className={cn(
          "text-xs font-mono",
          isPositive ? "text-neon-green" : "text-neon-red"
        )}>
          {isPositive ? "+" : ""}{data.changePercent.toFixed(2)}%
        </p>
      </div>
    </div>
  )
}

function PlanetRow({ position }: { position: PlanetPosition }) {
  return (
    <div className="flex items-center justify-between p-2 rounded-lg bg-secondary/30">
      <div className="flex items-center gap-2">
        <div className="h-2 w-2 rounded-full bg-accent" />
        <span className="text-sm font-medium text-foreground">{position.planet}</span>
        {position.retrograde && (
          <span className="text-xs px-1.5 py-0.5 rounded bg-neon-red/20 text-neon-red">R</span>
        )}
      </div>
      <div className="text-right">
        <p className="text-sm font-mono text-foreground">{position.sign}</p>
        <p className="text-xs text-muted-foreground">{position.degree.toFixed(1)}°</p>
      </div>
    </div>
  )
}
