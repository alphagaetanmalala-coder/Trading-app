"use client"

import { useMemo, useState } from "react"
import { Calendar, Filter } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { useForexNews } from "@/lib/oanda-api"

export function EconomicCalendar() {
  const { news } = useForexNews()
  const [impact, setImpact] = useState<"all" | "high" | "medium" | "low">("all")
  const [ccy, setCcy] = useState<string>("ALL")

  const currencies = useMemo(
    () => Array.from(new Set(news.map((n) => n.currency))).sort(),
    [news],
  )

  const filtered = news.filter(
    (n) => (impact === "all" || n.impact === impact) && (ccy === "ALL" || n.currency === ccy),
  )

  return (
    <div className="p-4 lg:p-6 space-y-4">
      <Card className="bg-card/50 border-border/50 backdrop-blur">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Calendar className="h-5 w-5 text-primary" />
            Calendrier Économique Live — 7 jours
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <select value={impact} onChange={(e) => setImpact(e.target.value as never)}
              className="bg-secondary/40 border border-border/50 rounded px-2 py-1 text-sm text-foreground">
              <option value="all">Tous impacts</option>
              <option value="high">Haute</option>
              <option value="medium">Moyenne</option>
              <option value="low">Basse</option>
            </select>
            <select value={ccy} onChange={(e) => setCcy(e.target.value)}
              className="bg-secondary/40 border border-border/50 rounded px-2 py-1 text-sm text-foreground">
              <option value="ALL">Toutes devises</option>
              {currencies.map((c) => <option key={c}>{c}</option>)}
            </select>
            <span className="text-xs text-muted-foreground">{filtered.length} événements</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground border-b border-border/50">
                <tr>
                  <th className="py-2 px-2">Date</th>
                  <th className="py-2 px-2">Heure</th>
                  <th className="py-2 px-2">Devise</th>
                  <th className="py-2 px-2">Événement</th>
                  <th className="py-2 px-2">Impact</th>
                  <th className="py-2 px-2 text-right">Prév.</th>
                  <th className="py-2 px-2 text-right">Préc.</th>
                  <th className="py-2 px-2 text-right">Actuel</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((n) => (
                  <tr key={n.id} className="border-b border-border/20">
                    <td className="py-2 px-2 text-foreground">{n.date.toLocaleDateString("fr-FR")}</td>
                    <td className="py-2 px-2 text-muted-foreground">{n.time}</td>
                    <td className="py-2 px-2 font-semibold text-foreground">{n.currency}</td>
                    <td className="py-2 px-2 text-foreground">{n.title}</td>
                    <td className="py-2 px-2">
                      <span className={cn(
                        "text-xs px-2 py-0.5 rounded",
                        n.impact === "high" && "bg-neon-red/20 text-neon-red",
                        n.impact === "medium" && "bg-accent/20 text-accent",
                        n.impact === "low" && "bg-primary/20 text-primary",
                      )}>
                        {n.impact === "high" ? "Haute" : n.impact === "medium" ? "Moyenne" : "Basse"}
                      </span>
                    </td>
                    <td className="py-2 px-2 text-right font-mono text-muted-foreground">{n.forecast}</td>
                    <td className="py-2 px-2 text-right font-mono text-muted-foreground">{n.previous}</td>
                    <td className="py-2 px-2 text-right font-mono text-foreground">{n.actual ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
