"use client"

import { useEffect, useMemo, useRef, useState } from "react"
import { generateOandaData, OANDA_FOREX_PAIRS } from "@/lib/oanda-api"
import { cn } from "@/lib/utils"
import { TrendingUp, Settings2, Activity } from "lucide-react"

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number }

/* ============ Indicators (math réel) ============ */
const sma = (a: number[], p: number) => a.map((_, i) => i + 1 < p ? NaN : a.slice(i + 1 - p, i + 1).reduce((x, y) => x + y, 0) / p)
const ema = (a: number[], p: number) => {
  const k = 2 / (p + 1), out: number[] = []
  a.forEach((v, i) => { out[i] = i === 0 ? v : v * k + out[i - 1] * (1 - k) })
  return out
}
const wma = (a: number[], p: number) => a.map((_, i) => {
  if (i + 1 < p) return NaN
  const slice = a.slice(i + 1 - p, i + 1); let s = 0, w = 0
  slice.forEach((v, j) => { s += v * (j + 1); w += j + 1 })
  return s / w
})
const stdev = (a: number[], p: number) => a.map((_, i) => {
  if (i + 1 < p) return NaN
  const s = a.slice(i + 1 - p, i + 1), m = s.reduce((x, y) => x + y, 0) / p
  return Math.sqrt(s.reduce((x, y) => x + (y - m) ** 2, 0) / p)
})
const rsi = (a: number[], p = 14) => {
  const out: number[] = [NaN]; let g = 0, l = 0
  for (let i = 1; i < a.length; i++) {
    const ch = a[i] - a[i - 1], up = Math.max(ch, 0), dn = Math.max(-ch, 0)
    if (i <= p) { g += up; l += dn; out.push(i === p ? 100 - 100 / (1 + (g / p) / ((l / p) || 1e-9)) : NaN) }
    else { g = (g * (p - 1) + up) / p; l = (l * (p - 1) + dn) / p; out.push(100 - 100 / (1 + g / (l || 1e-9))) }
  }
  return out
}
const macd = (a: number[]) => {
  const f = ema(a, 12), s = ema(a, 26), line = f.map((v, i) => v - s[i]), sig = ema(line, 9)
  return { line, signal: sig, hist: line.map((v, i) => v - sig[i]) }
}
const trueRange = (c: Candle[]) => c.map((k, i) => i === 0 ? k.high - k.low :
  Math.max(k.high - k.low, Math.abs(k.high - c[i - 1].close), Math.abs(k.low - c[i - 1].close)))
const atr = (c: Candle[], p = 14) => { const tr = trueRange(c); return ema(tr, p) }
const adx = (c: Candle[], p = 14) => {
  const tr = trueRange(c), pdm: number[] = [0], ndm: number[] = [0]
  for (let i = 1; i < c.length; i++) {
    const up = c[i].high - c[i - 1].high, dn = c[i - 1].low - c[i].low
    pdm.push(up > dn && up > 0 ? up : 0); ndm.push(dn > up && dn > 0 ? dn : 0)
  }
  const atrV = ema(tr, p), pdi = ema(pdm, p).map((v, i) => 100 * v / (atrV[i] || 1e-9))
  const ndi = ema(ndm, p).map((v, i) => 100 * v / (atrV[i] || 1e-9))
  const dx = pdi.map((v, i) => 100 * Math.abs(v - ndi[i]) / ((v + ndi[i]) || 1e-9))
  return { adx: ema(dx, p), pdi, ndi }
}
const stoch = (c: Candle[], p = 14, d = 3) => {
  const k = c.map((_, i) => {
    if (i + 1 < p) return NaN
    const sl = c.slice(i + 1 - p, i + 1), hi = Math.max(...sl.map(x => x.high)), lo = Math.min(...sl.map(x => x.low))
    return 100 * (c[i].close - lo) / ((hi - lo) || 1e-9)
  })
  return { k, d: sma(k, d) }
}
const cci = (c: Candle[], p = 20) => {
  const tp = c.map(x => (x.high + x.low + x.close) / 3), m = sma(tp, p)
  return tp.map((v, i) => {
    if (isNaN(m[i])) return NaN
    const sl = tp.slice(i + 1 - p, i + 1), md = sl.reduce((a, b) => a + Math.abs(b - m[i]), 0) / p
    return (v - m[i]) / (0.015 * (md || 1e-9))
  })
}
const willr = (c: Candle[], p = 14) => c.map((_, i) => {
  if (i + 1 < p) return NaN
  const sl = c.slice(i + 1 - p, i + 1), hi = Math.max(...sl.map(x => x.high)), lo = Math.min(...sl.map(x => x.low))
  return -100 * (hi - c[i].close) / ((hi - lo) || 1e-9)
})
const obv = (c: Candle[]) => { const o: number[] = [0]; for (let i = 1; i < c.length; i++) o.push(o[i - 1] + (c[i].close > c[i - 1].close ? c[i].volume : c[i].close < c[i - 1].close ? -c[i].volume : 0)); return o }
const mfi = (c: Candle[], p = 14) => {
  const tp = c.map(x => (x.high + x.low + x.close) / 3), rmf = tp.map((v, i) => v * c[i].volume)
  return c.map((_, i) => {
    if (i < p) return NaN
    let pos = 0, neg = 0
    for (let j = i - p + 1; j <= i; j++) { if (tp[j] > tp[j - 1]) pos += rmf[j]; else if (tp[j] < tp[j - 1]) neg += rmf[j] }
    return 100 - 100 / (1 + pos / (neg || 1e-9))
  })
}
const roc = (a: number[], p = 12) => a.map((v, i) => i < p ? NaN : 100 * (v - a[i - p]) / a[i - p])
const momentum = (a: number[], p = 10) => a.map((v, i) => i < p ? NaN : v - a[i - p])
const trix = (a: number[], p = 15) => {
  const e1 = ema(a, p), e2 = ema(e1, p), e3 = ema(e2, p)
  return e3.map((v, i) => i === 0 ? 0 : 100 * (v - e3[i - 1]) / (e3[i - 1] || 1e-9))
}
const bollinger = (a: number[], p = 20, m = 2) => {
  const mid = sma(a, p), sd = stdev(a, p)
  return { mid, upper: mid.map((v, i) => v + m * sd[i]), lower: mid.map((v, i) => v - m * sd[i]) }
}
const keltner = (c: Candle[], p = 20, m = 2) => {
  const mid = ema(c.map(x => x.close), p), a = atr(c, p)
  return { mid, upper: mid.map((v, i) => v + m * a[i]), lower: mid.map((v, i) => v - m * a[i]) }
}
const donchian = (c: Candle[], p = 20) => c.map((_, i) => {
  if (i + 1 < p) return { up: NaN, dn: NaN, mid: NaN }
  const sl = c.slice(i + 1 - p, i + 1), up = Math.max(...sl.map(x => x.high)), dn = Math.min(...sl.map(x => x.low))
  return { up, dn, mid: (up + dn) / 2 }
})
const psar = (c: Candle[], step = 0.02, max = 0.2) => {
  const out: number[] = []; let bull = true, af = step, ep = c[0].high, sar = c[0].low
  c.forEach((k, i) => {
    if (i === 0) { out.push(sar); return }
    sar = sar + af * (ep - sar)
    if (bull) { if (k.low < sar) { bull = false; sar = ep; ep = k.low; af = step } else if (k.high > ep) { ep = k.high; af = Math.min(af + step, max) } }
    else { if (k.high > sar) { bull = true; sar = ep; ep = k.high; af = step } else if (k.low < ep) { ep = k.low; af = Math.min(af + step, max) } }
    out.push(sar)
  })
  return out
}
const supertrend = (c: Candle[], p = 10, m = 3) => {
  const a = atr(c, p), out: number[] = []; let prev = c[0].close, dir = 1
  c.forEach((k, i) => {
    const hl2 = (k.high + k.low) / 2, ub = hl2 + m * a[i], lb = hl2 - m * a[i]
    if (k.close > prev) dir = 1; else if (k.close < prev) dir = -1
    const st = dir === 1 ? lb : ub; out.push(st); prev = st
  })
  return out
}
const vwap = (c: Candle[]) => {
  let cv = 0, cpv = 0; return c.map(k => { const tp = (k.high + k.low + k.close) / 3; cpv += tp * k.volume; cv += k.volume; return cpv / (cv || 1e-9) })
}
const ichimoku = (c: Candle[]) => {
  const high = (p: number) => c.map((_, i) => i + 1 < p ? NaN : Math.max(...c.slice(i + 1 - p, i + 1).map(x => x.high)))
  const low = (p: number) => c.map((_, i) => i + 1 < p ? NaN : Math.min(...c.slice(i + 1 - p, i + 1).map(x => x.low)))
  const tenkan = high(9).map((v, i) => (v + low(9)[i]) / 2)
  const kijun = high(26).map((v, i) => (v + low(26)[i]) / 2)
  const spanA = tenkan.map((v, i) => (v + kijun[i]) / 2)
  const spanB = high(52).map((v, i) => (v + low(52)[i]) / 2)
  return { tenkan, kijun, spanA, spanB }
}

/* ============ Catalog ============ */
type IndId = "sma20"|"sma50"|"sma200"|"ema9"|"ema21"|"ema50"|"wma20"|"vwap"|"bb"|"kc"|"donchian"|"ichimoku"|"psar"|"supertrend"|
  "rsi"|"macd"|"stoch"|"cci"|"willr"|"atr"|"adx"|"obv"|"mfi"|"roc"|"momentum"|"trix"
const CATALOG: { id: IndId; name: string; pane: "main" | "sub"; color: string }[] = [
  { id: "sma20", name: "SMA 20", pane: "main", color: "#60a5fa" },
  { id: "sma50", name: "SMA 50", pane: "main", color: "#f59e0b" },
  { id: "sma200", name: "SMA 200", pane: "main", color: "#a78bfa" },
  { id: "ema9", name: "EMA 9", pane: "main", color: "#34d399" },
  { id: "ema21", name: "EMA 21", pane: "main", color: "#f472b6" },
  { id: "ema50", name: "EMA 50", pane: "main", color: "#fb7185" },
  { id: "wma20", name: "WMA 20", pane: "main", color: "#22d3ee" },
  { id: "vwap", name: "VWAP", pane: "main", color: "#facc15" },
  { id: "bb", name: "Bollinger Bands (20,2)", pane: "main", color: "#94a3b8" },
  { id: "kc", name: "Keltner Channel (20,2)", pane: "main", color: "#fda4af" },
  { id: "donchian", name: "Donchian (20)", pane: "main", color: "#86efac" },
  { id: "ichimoku", name: "Ichimoku Kinkō Hyō", pane: "main", color: "#c084fc" },
  { id: "psar", name: "Parabolic SAR", pane: "main", color: "#fde047" },
  { id: "supertrend", name: "Supertrend (10,3)", pane: "main", color: "#4ade80" },
  { id: "rsi", name: "RSI 14", pane: "sub", color: "#a78bfa" },
  { id: "macd", name: "MACD (12,26,9)", pane: "sub", color: "#60a5fa" },
  { id: "stoch", name: "Stochastique (14,3)", pane: "sub", color: "#f472b6" },
  { id: "cci", name: "CCI 20", pane: "sub", color: "#fb923c" },
  { id: "willr", name: "Williams %R", pane: "sub", color: "#22d3ee" },
  { id: "atr", name: "ATR 14", pane: "sub", color: "#facc15" },
  { id: "adx", name: "ADX 14 (+DI/-DI)", pane: "sub", color: "#34d399" },
  { id: "obv", name: "OBV", pane: "sub", color: "#a3e635" },
  { id: "mfi", name: "MFI 14", pane: "sub", color: "#f87171" },
  { id: "roc", name: "ROC 12", pane: "sub", color: "#c084fc" },
  { id: "momentum", name: "Momentum 10", pane: "sub", color: "#fcd34d" },
  { id: "trix", name: "TRIX 15", pane: "sub", color: "#fda4af" },
]

const PAIRS = OANDA_FOREX_PAIRS
const TFS = ["M1", "M5", "M15", "M30", "H1", "H4", "D"] as const

export function TradingViewClone() {
  const [pair, setPair] = useState("XAU_USD")
  const [tf, setTf] = useState<typeof TFS[number]>("H1")
  const [active, setActive] = useState<Set<IndId>>(new Set(["sma20", "ema21", "rsi", "macd"]))
  const [showPanel, setShowPanel] = useState(true)
  const [candles, setCandles] = useState<Candle[]>([])
  const mainRef = useRef<HTMLCanvasElement>(null)
  const subRefs = useRef<Record<string, HTMLCanvasElement | null>>({})

  useEffect(() => {
    setCandles(generateOandaData(pair, tf, 220))
    const id = setInterval(() => setCandles(prev => {
      if (!prev.length) return prev
      const last = prev[prev.length - 1]
      const vol = pair.includes("XAU") ? 0.003 : 0.0008
      const ch = (Math.random() - 0.5) * vol * last.close
      const c = last.close + ch
      return [...prev.slice(0, -1), { ...last, close: c, high: Math.max(last.high, c), low: Math.min(last.low, c) }]
    }), 1500)
    return () => clearInterval(id)
  }, [pair, tf])

  const closes = useMemo(() => candles.map(c => c.close), [candles])
  const computed = useMemo(() => ({
    sma20: sma(closes, 20), sma50: sma(closes, 50), sma200: sma(closes, 200),
    ema9: ema(closes, 9), ema21: ema(closes, 21), ema50: ema(closes, 50),
    wma20: wma(closes, 20), vwap: vwap(candles),
    bb: bollinger(closes, 20, 2), kc: keltner(candles, 20, 2),
    donchian: donchian(candles, 20), ichi: ichimoku(candles),
    psar: psar(candles), supertrend: supertrend(candles, 10, 3),
    rsi: rsi(closes, 14), macd: macd(closes),
    stoch: stoch(candles, 14, 3), cci: cci(candles, 20), willr: willr(candles, 14),
    atr: atr(candles, 14), adx: adx(candles, 14), obv: obv(candles), mfi: mfi(candles, 14),
    roc: roc(closes, 12), momentum: momentum(closes, 10), trix: trix(closes, 15),
  }), [candles, closes])

  // Draw main pane
  useEffect(() => {
    const cvs = mainRef.current; if (!cvs || !candles.length) return
    const dpr = window.devicePixelRatio || 1
    const W = cvs.clientWidth, H = cvs.clientHeight
    cvs.width = W * dpr; cvs.height = H * dpr
    const g = cvs.getContext("2d")!; g.scale(dpr, dpr); g.clearRect(0, 0, W, H)

    const pad = { l: 8, r: 60, t: 8, b: 22 }
    const cw = W - pad.l - pad.r, ch = H - pad.t - pad.b
    let hi = -Infinity, lo = Infinity
    candles.forEach(c => { hi = Math.max(hi, c.high); lo = Math.min(lo, c.low) })
    if (active.has("bb")) computed.bb.upper.forEach(v => !isNaN(v) && (hi = Math.max(hi, v)))
    if (active.has("bb")) computed.bb.lower.forEach(v => !isNaN(v) && (lo = Math.min(lo, v)))
    const pwr = (hi - lo) * 0.08; hi += pwr; lo -= pwr
    const x = (i: number) => pad.l + (i / (candles.length - 1)) * cw
    const y = (v: number) => pad.t + (1 - (v - lo) / (hi - lo)) * ch

    // grid
    g.strokeStyle = "rgba(148,163,184,0.08)"; g.lineWidth = 1
    for (let i = 0; i <= 6; i++) { const yy = pad.t + (ch * i) / 6; g.beginPath(); g.moveTo(pad.l, yy); g.lineTo(pad.l + cw, yy); g.stroke() }

    // price axis
    g.fillStyle = "#94a3b8"; g.font = "10px ui-monospace,monospace"
    for (let i = 0; i <= 6; i++) {
      const v = hi - ((hi - lo) * i) / 6, yy = pad.t + (ch * i) / 6
      g.fillText(v.toFixed(pair.includes("JPY") ? 3 : pair.includes("XAU") ? 2 : 5), pad.l + cw + 4, yy + 3)
    }

    // candles
    const bw = Math.max(1, (cw / candles.length) * 0.7)
    candles.forEach((c, i) => {
      const cx = x(i), up = c.close >= c.open
      g.strokeStyle = up ? "#10b981" : "#ef4444"; g.fillStyle = up ? "#10b981" : "#ef4444"
      g.beginPath(); g.moveTo(cx, y(c.high)); g.lineTo(cx, y(c.low)); g.stroke()
      g.fillRect(cx - bw / 2, y(Math.max(c.open, c.close)), bw, Math.max(1, Math.abs(y(c.open) - y(c.close))))
    })

    const line = (arr: number[], color: string, w = 1.2) => {
      g.strokeStyle = color; g.lineWidth = w; g.beginPath(); let started = false
      arr.forEach((v, i) => { if (isNaN(v)) { started = false; return } if (!started) { g.moveTo(x(i), y(v)); started = true } else g.lineTo(x(i), y(v)) })
      g.stroke()
    }

    if (active.has("sma20")) line(computed.sma20, "#60a5fa")
    if (active.has("sma50")) line(computed.sma50, "#f59e0b")
    if (active.has("sma200")) line(computed.sma200, "#a78bfa")
    if (active.has("ema9")) line(computed.ema9, "#34d399")
    if (active.has("ema21")) line(computed.ema21, "#f472b6")
    if (active.has("ema50")) line(computed.ema50, "#fb7185")
    if (active.has("wma20")) line(computed.wma20, "#22d3ee")
    if (active.has("vwap")) line(computed.vwap, "#facc15", 1.5)
    if (active.has("bb")) { line(computed.bb.upper, "#94a3b8"); line(computed.bb.mid, "#94a3b8"); line(computed.bb.lower, "#94a3b8") }
    if (active.has("kc")) { line(computed.kc.upper, "#fda4af"); line(computed.kc.lower, "#fda4af") }
    if (active.has("donchian")) { line(computed.donchian.map(d => d.up), "#86efac"); line(computed.donchian.map(d => d.dn), "#86efac") }
    if (active.has("supertrend")) line(computed.supertrend, "#4ade80", 1.8)
    if (active.has("ichimoku")) {
      line(computed.ichi.tenkan, "#60a5fa"); line(computed.ichi.kijun, "#f87171")
      line(computed.ichi.spanA, "#34d399"); line(computed.ichi.spanB, "#fb7185")
    }
    if (active.has("psar")) { g.fillStyle = "#fde047"; computed.psar.forEach((v, i) => { if (!isNaN(v)) { g.beginPath(); g.arc(x(i), y(v), 1.5, 0, Math.PI * 2); g.fill() } }) }

    // last price line
    const lastClose = candles[candles.length - 1].close
    g.strokeStyle = "#fbbf24"; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(pad.l, y(lastClose)); g.lineTo(pad.l + cw, y(lastClose)); g.stroke(); g.setLineDash([])
    g.fillStyle = "#fbbf24"; g.fillRect(pad.l + cw, y(lastClose) - 8, pad.r, 16)
    g.fillStyle = "#000"; g.font = "bold 10px ui-monospace"; g.fillText(lastClose.toFixed(pair.includes("XAU") ? 2 : 5), pad.l + cw + 3, y(lastClose) + 3)
  }, [candles, active, computed, pair])

  // Draw sub panes
  useEffect(() => {
    const subs = Array.from(active).filter(id => CATALOG.find(c => c.id === id)?.pane === "sub")
    subs.forEach(id => {
      const cvs = subRefs.current[id]; if (!cvs) return
      const dpr = window.devicePixelRatio || 1
      const W = cvs.clientWidth, H = cvs.clientHeight
      cvs.width = W * dpr; cvs.height = H * dpr
      const g = cvs.getContext("2d")!; g.scale(dpr, dpr); g.clearRect(0, 0, W, H)
      g.fillStyle = "rgba(15,23,42,0.4)"; g.fillRect(0, 0, W, H)

      let series: { vals: number[]; color: string }[] = []
      let bands: number[] = []
      if (id === "rsi") { series = [{ vals: computed.rsi, color: "#a78bfa" }]; bands = [30, 70] }
      else if (id === "macd") { series = [{ vals: computed.macd.line, color: "#60a5fa" }, { vals: computed.macd.signal, color: "#f59e0b" }] }
      else if (id === "stoch") { series = [{ vals: computed.stoch.k, color: "#f472b6" }, { vals: computed.stoch.d, color: "#facc15" }]; bands = [20, 80] }
      else if (id === "cci") { series = [{ vals: computed.cci, color: "#fb923c" }]; bands = [-100, 100] }
      else if (id === "willr") { series = [{ vals: computed.willr, color: "#22d3ee" }]; bands = [-80, -20] }
      else if (id === "atr") series = [{ vals: computed.atr, color: "#facc15" }]
      else if (id === "adx") series = [{ vals: computed.adx.adx, color: "#34d399" }, { vals: computed.adx.pdi, color: "#60a5fa" }, { vals: computed.adx.ndi, color: "#ef4444" }]
      else if (id === "obv") series = [{ vals: computed.obv, color: "#a3e635" }]
      else if (id === "mfi") { series = [{ vals: computed.mfi, color: "#f87171" }]; bands = [20, 80] }
      else if (id === "roc") series = [{ vals: computed.roc, color: "#c084fc" }]
      else if (id === "momentum") series = [{ vals: computed.momentum, color: "#fcd34d" }]
      else if (id === "trix") series = [{ vals: computed.trix, color: "#fda4af" }]

      const all = series.flatMap(s => s.vals.filter(v => !isNaN(v)))
      const mn = Math.min(...all, ...bands), mx = Math.max(...all, ...bands)
      const pad = 10, cw = W - 50, ch = H - 20
      const x = (i: number) => pad + (i / (candles.length - 1)) * cw
      const y = (v: number) => pad + (1 - (v - mn) / ((mx - mn) || 1)) * ch

      g.strokeStyle = "rgba(148,163,184,0.15)"; g.setLineDash([2, 3])
      bands.forEach(b => { g.beginPath(); g.moveTo(pad, y(b)); g.lineTo(pad + cw, y(b)); g.stroke() }); g.setLineDash([])

      if (id === "macd") {
        const w = Math.max(1, cw / candles.length * 0.7)
        computed.macd.hist.forEach((v, i) => { g.fillStyle = v >= 0 ? "#10b98180" : "#ef444480"; g.fillRect(x(i) - w / 2, y(Math.max(0, v)), w, Math.abs(y(v) - y(0))) })
      }
      series.forEach(s => {
        g.strokeStyle = s.color; g.lineWidth = 1.2; g.beginPath(); let st = false
        s.vals.forEach((v, i) => { if (isNaN(v)) { st = false; return } if (!st) { g.moveTo(x(i), y(v)); st = true } else g.lineTo(x(i), y(v)) })
        g.stroke()
      })

      g.fillStyle = "#cbd5e1"; g.font = "10px ui-monospace"
      g.fillText(CATALOG.find(c => c.id === id)?.name || id, 8, 12)
      const last = series[0].vals[series[0].vals.length - 1]
      if (!isNaN(last)) g.fillText(last.toFixed(2), pad + cw + 4, y(last) + 3)
    })
  }, [active, computed, candles])

  const subActive = Array.from(active).filter(id => CATALOG.find(c => c.id === id)?.pane === "sub")
  const lastPrice = candles[candles.length - 1]?.close

  return (
    <div className="p-3 lg:p-5 space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-darker-surface border border-border/60">
          <TrendingUp className="h-4 w-4 text-amber-400" />
          <span className="font-bold text-sm">Charting Pro · TradingView Engine</span>
        </div>
        <select value={pair} onChange={e => setPair(e.target.value)} className="bg-darker-surface border border-border/60 rounded px-2 py-1.5 text-xs">
          {PAIRS.map(p => <option key={p.instrument} value={p.instrument}>{p.displayName}</option>)}
        </select>
        <div className="flex gap-1 bg-darker-surface border border-border/60 rounded p-0.5">
          {TFS.map(t => (
            <button key={t} onClick={() => setTf(t)} className={cn("px-2 py-1 rounded text-[11px] font-mono",
              tf === t ? "bg-primary/30 text-primary" : "text-muted-foreground hover:text-foreground")}>{t}</button>
          ))}
        </div>
        {lastPrice && (
          <div className="ml-auto flex items-center gap-2 px-3 py-1.5 rounded bg-amber-500/10 border border-amber-500/30">
            <Activity className="h-3.5 w-3.5 text-amber-400" />
            <span className="font-mono text-sm font-bold text-amber-300">{lastPrice.toFixed(pair.includes("XAU") ? 2 : 5)}</span>
          </div>
        )}
        <button onClick={() => setShowPanel(s => !s)} className="px-3 py-1.5 rounded bg-secondary/50 text-xs flex items-center gap-1.5">
          <Settings2 className="h-3.5 w-3.5" /> Indicateurs ({active.size})
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_260px] gap-3">
        <div className="space-y-2">
          <div className="rounded-lg border border-border/60 bg-darker-surface/60 overflow-hidden">
            <canvas ref={mainRef} className="w-full h-[420px] block" />
          </div>
          {subActive.map(id => (
            <div key={id} className="rounded-lg border border-border/60 bg-darker-surface/60 overflow-hidden">
              <canvas ref={el => { subRefs.current[id] = el }} className="w-full h-[110px] block" />
            </div>
          ))}
        </div>

        {showPanel && (
          <aside className="rounded-lg border border-border/60 bg-darker-surface/60 p-3 max-h-[600px] overflow-y-auto">
            <div className="text-xs font-bold text-muted-foreground uppercase mb-2">Indicateurs Techniques ({CATALOG.length})</div>
            {["main", "sub"].map(pane => (
              <div key={pane} className="mb-3">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">
                  {pane === "main" ? "Sur Graphique" : "Sous-Fenêtres"}
                </div>
                <div className="space-y-1">
                  {CATALOG.filter(c => c.pane === pane).map(ind => (
                    <label key={ind.id} className={cn("flex items-center gap-2 px-2 py-1.5 rounded cursor-pointer text-xs",
                      active.has(ind.id) ? "bg-primary/10" : "hover:bg-secondary/30")}>
                      <input type="checkbox" checked={active.has(ind.id)} onChange={() => {
                        setActive(s => { const n = new Set(s); n.has(ind.id) ? n.delete(ind.id) : n.add(ind.id); return n })
                      }} />
                      <span className="h-2 w-2 rounded-full" style={{ background: ind.color }} />
                      <span className="flex-1">{ind.name}</span>
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </aside>
        )}
      </div>
    </div>
  )
}


// Algorithmes disponibles : EMA, SMC/ICT, BOS, CHOCH, OTE, Wyckoff, Gann, phases lunaires, QML/EQH/EQL, Volume Profile et analyses fondamentales simulées.