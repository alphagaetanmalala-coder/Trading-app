"use client"

import { useEffect, useState } from "react"
import { Target, Activity, Sparkles, Brain, Newspaper } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

export function ExtraMiniGames() {
  return (
    <div className="grid md:grid-cols-2 gap-4 p-4 lg:p-6">
      <PatternHunter />
      <LiquiditySweep />
      <GannAngle />
      <SiderealMemory />
      <NewsReaction />
    </div>
  )
}

/* 1. Pattern Hunter */
function PatternHunter() {
  const patterns = ["Marteau", "Étoile filante", "Doji", "Englobante"]
  const [current, setCurrent] = useState(0)
  const [score, setScore] = useState(0)
  const target = patterns[current]
  const choose = (p: string) => {
    if (p === target) setScore((s) => s + 1)
    setCurrent(Math.floor(Math.random() * patterns.length))
  }
  return (
    <Game title="Pattern Hunter" icon={Target} score={score}>
      <p className="text-sm text-muted-foreground">
        Identifiez rapidement le pattern affiché en sélectionnant son nom.
      </p>
      <div className="text-2xl font-bold text-center py-4 text-foreground">{target}</div>
      <div className="grid grid-cols-2 gap-2">
        {patterns.map((p) => (
          <button key={p} onClick={() => choose(p)}
            className="px-3 py-2 text-sm rounded bg-secondary/50 text-foreground hover:bg-primary/20">
            {p}
          </button>
        ))}
      </div>
    </Game>
  )
}

/* 2. Liquidity Sweep Reflex */
function LiquiditySweep() {
  const [armed, setArmed] = useState(false)
  const [waiting, setWaiting] = useState(false)
  const [time, setTime] = useState<number | null>(null)
  const [best, setBest] = useState<number | null>(null)
  const [start, setStart] = useState(0)

  useEffect(() => {
    if (!waiting) return
    const d = 1500 + Math.random() * 2500
    const id = setTimeout(() => { setArmed(true); setStart(Date.now()) }, d)
    return () => clearTimeout(id)
  }, [waiting])

  const click = () => {
    if (armed) {
      const t = Date.now() - start
      setTime(t)
      if (best === null || t < best) setBest(t)
      setArmed(false); setWaiting(false)
    } else if (!waiting) setWaiting(true)
  }
  return (
    <Game title="Liquidity Sweep — Réflexe" icon={Activity} score={best ? `${best} ms` : "—"}>
      <p className="text-sm text-muted-foreground">
        Cliquez dès que le sweep haussier apparaît. Mesurez votre temps de réaction.
      </p>
      <button
        onClick={click}
        className={cn(
          "w-full h-32 rounded-lg font-bold text-lg transition-all",
          armed ? "bg-neon-green text-black animate-pulse"
                : waiting ? "bg-neon-red/30 text-foreground"
                : "bg-secondary/60 text-foreground hover:bg-secondary/80",
        )}
      >
        {armed ? "SWEEP ! CLIQUEZ" : waiting ? "Attendez..." : "Démarrer"}
      </button>
      {time !== null && (
        <p className="text-xs text-center text-muted-foreground">Dernier : {time} ms</p>
      )}
    </Game>
  )
}

/* 3. Gann Angle Match */
function GannAngle() {
  const angles = [{ name: "1×1", deg: 45 }, { name: "2×1", deg: 63.75 }, { name: "1×2", deg: 26.25 }, { name: "1×4", deg: 15 }]
  const [target, setTarget] = useState(angles[0])
  const [score, setScore] = useState(0)
  const pick = (a: typeof angles[0]) => {
    if (a.name === target.name) setScore((s) => s + 1)
    setTarget(angles[Math.floor(Math.random() * angles.length)])
  }
  return (
    <Game title="Gann Angle Match" icon={Brain} score={score}>
      <p className="text-sm text-muted-foreground">Quel angle correspond à {target.deg}° ?</p>
      <div className="flex items-center justify-center h-24">
        <svg width="80" height="80">
          <line x1="10" y1="70" x2={10 + 60 * Math.cos((target.deg * Math.PI) / 180)}
            y2={70 - 60 * Math.sin((target.deg * Math.PI) / 180)}
            stroke="hsl(var(--accent))" strokeWidth="3" />
          <line x1="10" y1="70" x2="70" y2="70" stroke="hsl(var(--muted-foreground))" strokeWidth="1" />
        </svg>
      </div>
      <div className="grid grid-cols-4 gap-2">
        {angles.map((a) => (
          <button key={a.name} onClick={() => pick(a)}
            className="px-2 py-2 text-sm rounded bg-secondary/50 hover:bg-accent/20 text-foreground">
            {a.name}
          </button>
        ))}
      </div>
    </Game>
  )
}

/* 4. Sidereal Memory */
function SiderealMemory() {
  const planets = ["☉ Soleil", "☽ Lune", "☿ Mercure", "♀ Vénus", "♂ Mars", "♃ Jupiter"]
  const [seq, setSeq] = useState<number[]>([])
  const [show, setShow] = useState(true)
  const [input, setInput] = useState<number[]>([])
  const [level, setLevel] = useState(3)
  const [msg, setMsg] = useState("")

  const start = () => {
    const s = Array.from({ length: level }, () => Math.floor(Math.random() * planets.length))
    setSeq(s); setInput([]); setShow(true); setMsg("")
    setTimeout(() => setShow(false), 1500 + level * 500)
  }
  useEffect(() => { start() /* eslint-disable-next-line */ }, [])
  const tap = (i: number) => {
    if (show) return
    const next = [...input, i]
    setInput(next)
    if (seq[next.length - 1] !== i) { setMsg("❌ Raté — niveau réinitialisé"); setLevel(3); setTimeout(start, 800); return }
    if (next.length === seq.length) { setMsg("✅ Bravo !"); setLevel((l) => l + 1); setTimeout(start, 800) }
  }
  return (
    <Game title="Sidereal Memory" icon={Sparkles} score={`Niveau ${level}`}>
      <p className="text-sm text-muted-foreground">Mémorisez l'ordre des planètes affichées.</p>
      <div className="min-h-[40px] text-center text-foreground">
        {show ? seq.map((i) => planets[i]).join("  ›  ") : "Reproduisez la séquence"}
      </div>
      <div className="grid grid-cols-3 gap-2">
        {planets.map((p, i) => (
          <button key={p} onClick={() => tap(i)}
            className="px-2 py-2 text-xs rounded bg-secondary/50 hover:bg-accent/20 text-foreground">
            {p}
          </button>
        ))}
      </div>
      {msg && <p className="text-xs text-center text-muted-foreground">{msg}</p>}
    </Game>
  )
}

/* 5. News Reaction Drill */
function NewsReaction() {
  const news = [
    { headline: "🟢 NFP > prévisions, USD en forte hausse", correct: "Achat USD" },
    { headline: "🔴 BCE coupe les taux de 50bps surprise", correct: "Vente EUR" },
    { headline: "🟢 BOJ maintient politique ultra-accommodante", correct: "Vente JPY" },
    { headline: "🔴 CPI US en ralentissement net", correct: "Vente USD" },
  ]
  const [i, setI] = useState(0)
  const [score, setScore] = useState(0)
  const actions = ["Achat USD", "Vente USD", "Vente EUR", "Vente JPY"]
  const pick = (a: string) => {
    if (a === news[i].correct) setScore((s) => s + 1)
    setI((x) => (x + 1) % news.length)
  }
  return (
    <Game title="News Reaction Drill" icon={Newspaper} score={score}>
      <p className="text-sm text-foreground font-medium">{news[i].headline}</p>
      <p className="text-xs text-muted-foreground">Quelle est la réaction logique ?</p>
      <div className="grid grid-cols-2 gap-2">
        {actions.map((a) => (
          <button key={a} onClick={() => pick(a)}
            className="px-2 py-2 text-xs rounded bg-secondary/50 hover:bg-primary/20 text-foreground">
            {a}
          </button>
        ))}
      </div>
    </Game>
  )
}

function Game({
  title, icon: Icon, score, children,
}: { title: string; icon: React.ElementType; score: React.ReactNode; children: React.ReactNode }) {
  return (
    <Card className="bg-card/50 border-border/50 backdrop-blur">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between text-foreground text-base">
          <span className="flex items-center gap-2"><Icon className="h-4 w-4 text-primary" />{title}</span>
          <span className="text-xs px-2 py-0.5 rounded bg-accent/20 text-accent">{score}</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">{children}</CardContent>
    </Card>
  )
}
