"use client"

import { useState } from "react"
import { GraduationCap, CheckCircle2, XCircle, Eye } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface Question {
  id: string
  level: "Débutant" | "Intermédiaire" | "Avancé" | "Institutionnel"
  question: string
  options: string[]
  correct: number
  explanation: string
}

const QUESTIONS: Question[] = [
  {
    id: "q1", level: "Débutant",
    question: "Que signifie un PIP sur EUR/USD ?",
    options: ["1.0", "0.01", "0.0001", "0.1"],
    correct: 2,
    explanation: "Un PIP standard sur EUR/USD = 0.0001 (4e décimale). C'est l'unité de variation minimale.",
  },
  {
    id: "q2", level: "Débutant",
    question: "Quel ordre limite votre perte maximale ?",
    options: ["Take Profit", "Stop Loss", "Limit", "Trailing"],
    correct: 1,
    explanation: "Le Stop Loss ferme automatiquement la position à perte fixée, protégeant le capital.",
  },
  {
    id: "q3", level: "Intermédiaire",
    question: "En analyse Dow, une tendance haussière est confirmée par :",
    options: [
      "Des sommets décroissants",
      "Des sommets et creux croissants",
      "Un volume en baisse",
      "Des bougies dojis successives",
    ],
    correct: 1,
    explanation: "Théorie de Dow : higher highs + higher lows = tendance haussière confirmée.",
  },
  {
    id: "q4", level: "Intermédiaire",
    question: "Qu'est-ce qu'un FVG (Fair Value Gap) en ICT ?",
    options: [
      "Un écart de prix non comblé entre 3 bougies",
      "Un retracement Fibonacci 50%",
      "Un niveau de support institutionnel",
      "Un indicateur de volume",
    ],
    correct: 0,
    explanation: "Un FVG est un déséquilibre laissé par 3 bougies consécutives, agissant comme aimant à prix.",
  },
  {
    id: "q5", level: "Avancé",
    question: "Dans la méthode Gann, l'angle 1×1 représente :",
    options: [
      "1 unité de prix pour 1 unité de temps",
      "1 dollar par minute",
      "1% par jour",
      "1 pip par seconde",
    ],
    correct: 0,
    explanation: "L'angle 1×1 (45°) est la diagonale parfaite prix/temps, équilibre de Gann.",
  },
  {
    id: "q6", level: "Avancé",
    question: "Une phase Wyckoff 'Spring' indique :",
    options: [
      "Distribution finale haussière",
      "Test sous le support avant rallye",
      "Cassure baissière confirmée",
      "Marché en sur-achat",
    ],
    correct: 1,
    explanation: "Spring = test sous le support en phase d'accumulation, souvent un piège baissier inversé.",
  },
  {
    id: "q7", level: "Institutionnel",
    question: "Le concept SMC de 'Liquidity Sweep' désigne :",
    options: [
      "Une accumulation lente",
      "La prise rapide des stops au-delà d'un sommet/creux clé",
      "Un retracement Fibonacci 78.6%",
      "Un changement de session",
    ],
    correct: 1,
    explanation: "Les institutionnels balayent la liquidité (stops) avant de pousser le prix dans la vraie direction.",
  },
  {
    id: "q8", level: "Institutionnel",
    question: "QML (Quasimodo Level) se forme typiquement après :",
    options: [
      "Un triangle symétrique",
      "Un higher high suivi d'un lower low cassant la structure",
      "Une bougie en marteau isolée",
      "Une moyenne mobile croisée",
    ],
    correct: 1,
    explanation: "QML : HH + LL cassant la structure précédente — zone à très haute probabilité de retournement.",
  },
  {
    id: "q9", level: "Institutionnel",
    question: "Lors d'une news NFP haute impact, la stratégie prudente est :",
    options: [
      "Augmenter la taille de position",
      "Ne pas trader 15 min avant et après",
      "Acheter systématiquement",
      "Ignorer la news",
    ],
    correct: 1,
    explanation: "La volatilité extrême et les slippages rendent la fenêtre NFP ±15min dangereuse hors stratégie dédiée.",
  },
  {
    id: "q10", level: "Avancé",
    question: "L'astrologie sidérale de Dorsan corrèle les marchés à :",
    options: [
      "Les phases lunaires uniquement",
      "Les aspects sidéraux entre planètes (carré, trigone, opposition)",
      "Les cycles solaires de 11 ans",
      "Les marées océaniques",
    ],
    correct: 1,
    explanation: "Dorsan synthétise les angles planétaires sidéraux pour anticiper retournements et accélérations.",
  },
]

export function InteractiveAcademy() {
  return (
    <div className="p-4 lg:p-6 space-y-4">
      <Card className="bg-card/50 border-border/50 backdrop-blur">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <GraduationCap className="h-5 w-5 text-primary" />
            Académie Interactive — du Débutant à l'Institutionnel
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            {QUESTIONS.map((q) => <QcmCard key={q.id} q={q} />)}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function QcmCard({ q }: { q: Question }) {
  const [picked, setPicked] = useState<number | null>(null)
  const [revealed, setRevealed] = useState(false)

  return (
    <div className="p-4 rounded-lg border border-border/40 bg-secondary/30 space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded bg-primary/15 text-primary">
          {q.level}
        </span>
      </div>
      <p className="text-sm font-medium text-foreground">{q.question}</p>
      <div className="space-y-2">
        {q.options.map((opt, i) => {
          const isPicked = picked === i
          const isCorrect = revealed && i === q.correct
          const isWrong = revealed && isPicked && i !== q.correct
          return (
            <button
              key={i}
              onClick={() => !revealed && setPicked(i)}
              disabled={revealed}
              className={cn(
                "w-full text-left text-sm px-3 py-2 rounded border transition-all",
                isCorrect && "bg-neon-green/15 border-neon-green text-foreground",
                isWrong && "bg-neon-red/15 border-neon-red text-foreground",
                !revealed && isPicked && "border-primary bg-primary/10 text-foreground",
                !revealed && !isPicked && "border-border/40 text-muted-foreground hover:bg-secondary/50",
              )}
            >
              <span className="inline-flex items-center gap-2">
                {isCorrect && <CheckCircle2 className="h-4 w-4 text-neon-green" />}
                {isWrong && <XCircle className="h-4 w-4 text-neon-red" />}
                {opt}
              </span>
            </button>
          )
        })}
      </div>
      <div className="flex items-center justify-between">
        <button
          onClick={() => setRevealed(true)}
          disabled={revealed}
          className="text-xs px-3 py-1.5 rounded bg-accent/20 text-accent hover:bg-accent/30 disabled:opacity-50 inline-flex items-center gap-1"
        >
          <Eye className="h-3 w-3" /> Révéler la réponse
        </button>
        {revealed && (
          <button onClick={() => { setPicked(null); setRevealed(false) }}
            className="text-xs text-muted-foreground hover:text-foreground">Recommencer</button>
        )}
      </div>
      {revealed && (
        <p className="text-xs text-muted-foreground leading-relaxed border-t border-border/30 pt-2">
          <strong className="text-foreground">Explication :</strong> {q.explanation}
        </p>
      )}
    </div>
  )
}
