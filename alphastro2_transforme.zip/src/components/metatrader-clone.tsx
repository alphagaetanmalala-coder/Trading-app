"use client"

import { useEffect, useState } from "react"
import { generateOandaData, OANDA_FOREX_PAIRS } from "@/lib/oanda-api"
import { cn } from "@/lib/utils"
import { Bot, Activity, BarChart3, History, MessageSquare, FileText } from "lucide-react"

type Tab = "trade" | "exposure" | "history" | "news" | "alerts" | "experts" | "journal"
type Position = { ticket: number; symbol: string; type: "buy" | "sell"; volume: number; entry: number; sl: number; tp: number; current: number; profit: number; time: number }

export function MetalphaTrader() {
  const [tab, setTab] = useState<Tab>("trade")
  const [prices, setPrices] = useState<Record<string, number>>({})
  const [selected, setSelected] = useState("XAU_USD")
  const [positions, setPositions] = useState<Position[]>([
    { ticket: 102845731, symbol: "XAU/USD", type: "buy", volume: 0.50, entry: 4485.20, sl: 4470.00, tp: 4525.00, current: 4501.85, profit: 832.50, time: Date.now() - 3600000 * 4 },
    { ticket: 102845892, symbol: "EUR/USD", type: "sell", volume: 1.00, entry: 1.0875, sl: 1.0910, tp: 1.0820, current: 1.0852, profit: 230.00, time: Date.now() - 3600000 * 2 },
    { ticket: 102845998, symbol: "GBP/JPY", type: "buy", volume: 0.25, entry: 189.45, sl: 188.80, tp: 190.50, current: 189.78, profit: 54.20, time: Date.now() - 3600000 },
  ])

  useEffect(() => {
    const tick = () => {
      const next: Record<string, number> = {}
      OANDA_FOREX_PAIRS.forEach(p => { next[p.instrument] = generateOandaData(p.instrument, "M1", 1)[0].close })
      setPrices(next)
    }
    tick(); const i = setInterval(tick, 1500); return () => clearInterval(i)
  }, [])

  const equity = 50000 + positions.reduce((s, p) => s + p.profit, 0)

  return (
    <div className="p-2 lg:p-3 space-y-2">
      {/* MT5 Top toolbar */}
      <div className="rounded border border-border/60 bg-gradient-to-r from-slate-800 to-slate-900 px-3 py-2 flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <div className="h-9 w-9 rounded bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center font-black text-white text-sm shadow-lg">MT5</div>
          <div>
            <div className="text-sm font-bold">MetaTrader 5 · Alpha Gaetan Terminal</div>
            <div className="text-[10px] text-muted-foreground">Compte: 58291473 · Serveur: ICMarkets-Live22 · Levier 1:500</div>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-3 text-xs">
          <div className="text-right"><div className="text-[10px] text-muted-foreground">Solde</div><div className="font-mono font-bold">$50 000.00</div></div>
          <div className="text-right"><div className="text-[10px] text-muted-foreground">Équité</div><div className={cn("font-mono font-bold", equity >= 50000 ? "text-emerald-400" : "text-red-400")}>${equity.toFixed(2)}</div></div>
          <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-emerald-500/15 border border-emerald-500/30">
            <div className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[10px] text-emerald-300">Connecté · 12ms</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[240px_1fr_280px] gap-2">
        {/* Market Watch */}
        <div className="rounded border border-border/60 bg-darker-surface/80">
          <div className="px-2 py-1.5 text-[10px] font-bold uppercase border-b border-border/60 bg-secondary/30">Market Watch</div>
          <div className="max-h-[520px] overflow-y-auto">
            <table className="w-full text-[11px] font-mono">
              <thead className="text-[9px] text-muted-foreground uppercase sticky top-0 bg-darker-surface">
                <tr><th className="px-2 py-1 text-left">Symbol</th><th className="text-right">Bid</th><th className="text-right pr-2">Ask</th></tr>
              </thead>
              <tbody>
                {OANDA_FOREX_PAIRS.map(p => {
                  const px = prices[p.instrument] ?? 0
                  const sp = p.instrument.includes("XAU") ? 0.35 : p.instrument.includes("JPY") ? 0.015 : 0.00012
                  const dec = p.instrument.includes("XAU") ? 2 : p.instrument.includes("JPY") ? 3 : 5
                  return (
                    <tr key={p.instrument} onClick={() => setSelected(p.instrument)}
                      className={cn("border-t border-border/30 hover:bg-secondary/30 cursor-pointer",
                        selected === p.instrument && "bg-primary/10")}>
                      <td className="px-2 py-1">{p.displayName}</td>
                      <td className="text-right text-red-400">{px.toFixed(dec)}</td>
                      <td className="text-right text-emerald-400 pr-2">{(px + sp).toFixed(dec)}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Chart placeholder */}
        <div className="rounded border border-border/60 bg-darker-surface/80 flex flex-col">
          <div className="px-2 py-1.5 text-[10px] font-bold uppercase border-b border-border/60 bg-secondary/30 flex items-center gap-2">
            {selected.replace("_", "/")} · H1
            <div className="ml-auto flex gap-0.5">
              {["M1", "M5", "M15", "M30", "H1", "H4", "D1", "W1"].map(t => (
                <button key={t} className="px-1.5 py-0.5 text-[10px] rounded hover:bg-primary/20 text-muted-foreground">{t}</button>
              ))}
            </div>
          </div>
          <MiniChart symbol={selected} />
        </div>

        {/* Navigator */}
        <div className="rounded border border-border/60 bg-darker-surface/80">
          <div className="px-2 py-1.5 text-[10px] font-bold uppercase border-b border-border/60 bg-secondary/30">Navigator</div>
          <div className="p-2 text-xs space-y-2">
            <NavGroup label="Comptes" items={["58291473 - Real USD", "12047829 - Démo"]} />
            <NavGroup label="Indicators" items={["Moving Average", "MACD", "RSI", "Bollinger Bands", "Ichimoku", "Parabolic SAR", "ATR", "ADX"]} />
            <NavGroup label="Expert Advisors" items={["AlphaGaetan_Scalper v2.4", "GoldGrid_EA", "FractalHunter", "NewsBlaster_Pro"]} />
            <NavGroup label="Scripts" items={["CloseAll", "BreakEven", "PartialClose 50%"]} />
          </div>
        </div>
      </div>

      {/* Terminal tabs */}
      <div className="rounded border border-border/60 bg-darker-surface/80">
        <div className="flex border-b border-border/60 bg-secondary/30 text-[11px]">
          {([["trade", "Trade", Activity], ["exposure", "Exposition", BarChart3], ["history", "Historique", History],
            ["news", "News", FileText], ["alerts", "Alertes", MessageSquare], ["experts", "Experts", Bot],
            ["journal", "Journal", FileText]] as const).map(([id, label, Icon]) => (
            <button key={id} onClick={() => setTab(id)}
              className={cn("flex items-center gap-1.5 px-3 py-1.5 border-r border-border/40",
                tab === id ? "bg-darker-surface text-primary border-t-2 border-t-primary" : "text-muted-foreground hover:text-foreground")}>
              <Icon className="h-3 w-3" />{label}
            </button>
          ))}
        </div>

        <div className="p-2 min-h-[200px]">
          {tab === "trade" && (
            <table className="w-full text-[11px] font-mono">
              <thead className="text-[9px] uppercase text-muted-foreground">
                <tr><th className="text-left px-2 py-1">Ticket</th><th>Heure</th><th>Symbole</th><th>Type</th><th>Volume</th><th>Prix</th><th>S/L</th><th>T/P</th><th>Prix Actuel</th><th className="text-right pr-2">Profit</th></tr>
              </thead>
              <tbody>
                {positions.map(p => (
                  <tr key={p.ticket} className="border-t border-border/30 hover:bg-secondary/20">
                    <td className="px-2 py-1">{p.ticket}</td>
                    <td className="text-center">{new Date(p.time).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}</td>
                    <td className="text-center">{p.symbol}</td>
                    <td className={cn("text-center font-bold", p.type === "buy" ? "text-emerald-400" : "text-red-400")}>{p.type}</td>
                    <td className="text-center">{p.volume.toFixed(2)}</td>
                    <td className="text-center">{p.entry.toFixed(p.symbol.includes("XAU") ? 2 : p.symbol.includes("JPY") ? 3 : 5)}</td>
                    <td className="text-center text-red-400/70">{p.sl.toFixed(p.symbol.includes("XAU") ? 2 : 5)}</td>
                    <td className="text-center text-emerald-400/70">{p.tp.toFixed(p.symbol.includes("XAU") ? 2 : 5)}</td>
                    <td className="text-center">{p.current.toFixed(p.symbol.includes("XAU") ? 2 : 5)}</td>
                    <td className={cn("text-right pr-2 font-bold", p.profit >= 0 ? "text-emerald-400" : "text-red-400")}>{p.profit >= 0 ? "+" : ""}{p.profit.toFixed(2)}</td>
                  </tr>
                ))}
                <tr className="border-t-2 border-border/60 bg-secondary/20 font-bold">
                  <td colSpan={9} className="px-2 py-1.5 text-right">Profit Total :</td>
                  <td className={cn("text-right pr-2", positions.reduce((s, p) => s + p.profit, 0) >= 0 ? "text-emerald-400" : "text-red-400")}>
                    ${positions.reduce((s, p) => s + p.profit, 0).toFixed(2)}
                  </td>
                </tr>
              </tbody>
            </table>
          )}
          {tab === "exposure" && (
            <div className="space-y-1 text-xs font-mono">
              {[["USD", 50500, 1.00], ["EUR", -108750, -0.95], ["GBP", 47445, 0.41], ["JPY", -28391500, -0.24], ["XAU (oz)", 50, 0.06]].map(([c, v, n]) => (
                <div key={c as string} className="flex gap-4 px-2 py-1 border-b border-border/30">
                  <span className="w-20 font-bold">{c}</span>
                  <span className={cn("flex-1 text-right", (v as number) >= 0 ? "text-emerald-400" : "text-red-400")}>{(v as number).toLocaleString("fr-FR")}</span>
                  <span className="w-20 text-right text-muted-foreground">{((n as number) * 100).toFixed(2)}%</span>
                </div>
              ))}
            </div>
          )}
          {tab === "history" && (
            <div className="text-xs font-mono space-y-1">
              {Array.from({ length: 6 }).map((_, i) => {
                const p = (Math.random() - 0.3) * 500
                return <div key={i} className="flex gap-3 px-2 py-1 border-b border-border/30">
                  <span className="text-muted-foreground">2026.05.{18 - i} {String(8 + i).padStart(2, "0")}:32</span>
                  <span className="w-20">{["XAU/USD","EUR/USD","GBP/JPY","USD/JPY"][i%4]}</span>
                  <span className={cn("w-10", i%2 ? "text-red-400" : "text-emerald-400")}>{i%2?"sell":"buy"}</span>
                  <span className="ml-auto" /><span className={cn(p >= 0 ? "text-emerald-400" : "text-red-400")}>{p >= 0 ? "+" : ""}{p.toFixed(2)}</span>
                </div>
              })}
            </div>
          )}
          {tab === "news" && (
            <div className="text-xs space-y-1.5">
              {["[USD] FOMC Minutes — 20:00 GMT — High impact",
                "[EUR] ECB President Lagarde Speech — 14:30",
                "[GBP] UK CPI y/y — Forecast 2.1% vs 2.3% prev.",
                "[JPY] BOJ Monetary Policy Statement — Tonight 03:00"].map((n, i) => (
                <div key={i} className="px-2 py-1.5 border-l-2 border-amber-500 bg-amber-500/5">{n}</div>
              ))}
            </div>
          )}
          {tab === "alerts" && <div className="text-xs text-muted-foreground p-3">3 alertes actives · XAU/USD &gt; 4520 · EUR/USD &lt; 1.08 · BTC/USD &gt; 70000</div>}
          {tab === "experts" && (
            <div className="text-xs font-mono space-y-1">
              {["AlphaGaetan_Scalper v2.4 attached on XAU/USD,M5 (Live)",
                "GoldGrid_EA initialized. AccountInfo: leverage=500, margin_free=$48 932.10",
                "FractalHunter: 3 valid fractals detected. Awaiting confirmation.",
                "NewsBlaster_Pro: Filter active. Next event in 02:14:35 (NFP)."].map((l, i) => (
                <div key={i} className="px-2 py-1 border-b border-border/30 text-emerald-300/80">{new Date().toISOString().slice(11,19)} | {l}</div>
              ))}
            </div>
          )}
          {tab === "journal" && (
            <div className="text-[10px] font-mono space-y-0.5 text-muted-foreground">
              {["Network: connected to ICMarkets-Live22","Login: 58291473 authorized","Symbols: 168 loaded","History: XAU/USD H1 — 100k bars synced","Trade: position #102845731 opened buy 0.50 XAU/USD at 4485.20 sl 4470.00 tp 4525.00"].map((l, i) => (
                <div key={i}>{new Date().toISOString().slice(11,23)} {l}</div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function NavGroup({ label, items }: { label: string; items: string[] }) {
  return <div>
    <div className="font-bold text-muted-foreground text-[10px] uppercase mb-1">{label}</div>
    <div className="space-y-0.5">
      {items.map(i => <div key={i} className="px-2 py-0.5 rounded hover:bg-primary/10 cursor-pointer text-[11px]">{i}</div>)}
    </div>
  </div>
}

function MiniChart({ symbol }: { symbol: string }) {
  const [data, setData] = useState(() => generateOandaData(symbol, "H1", 100))
  useEffect(() => { setData(generateOandaData(symbol, "H1", 100)) }, [symbol])
  useEffect(() => {
    const cvs = document.getElementById("mt5-mini-chart") as HTMLCanvasElement
    if (!cvs) return
    const dpr = window.devicePixelRatio || 1, W = cvs.clientWidth, H = cvs.clientHeight
    cvs.width = W * dpr; cvs.height = H * dpr
    const g = cvs.getContext("2d")!; g.scale(dpr, dpr); g.clearRect(0,0,W,H)
    g.fillStyle = "#0a0e1a"; g.fillRect(0,0,W,H)
    g.strokeStyle = "rgba(148,163,184,0.08)"
    for (let i = 0; i <= 8; i++) { g.beginPath(); g.moveTo(0, H * i / 8); g.lineTo(W, H * i / 8); g.stroke() }
    let hi = -Infinity, lo = Infinity; data.forEach(c => { hi = Math.max(hi, c.high); lo = Math.min(lo, c.low) })
    const y = (v: number) => 10 + (1 - (v - lo) / (hi - lo)) * (H - 20)
    const x = (i: number) => (i / (data.length - 1)) * (W - 40)
    const bw = Math.max(2, (W - 40) / data.length * 0.7)
    data.forEach((c, i) => {
      const up = c.close >= c.open
      g.strokeStyle = up ? "#26a69a" : "#ef5350"; g.fillStyle = up ? "#26a69a" : "#ef5350"
      g.beginPath(); g.moveTo(x(i), y(c.high)); g.lineTo(x(i), y(c.low)); g.stroke()
      g.fillRect(x(i) - bw/2, y(Math.max(c.open,c.close)), bw, Math.max(1, Math.abs(y(c.open)-y(c.close))))
    })
    g.fillStyle = "#cbd5e1"; g.font = "10px ui-monospace"
    for (let i = 0; i <= 6; i++) { const v = hi - (hi-lo)*i/6; g.fillText(v.toFixed(symbol.includes("XAU")?2:5), W-38, 10 + i*(H-20)/6) }
  }, [data, symbol])
  return <canvas id="mt5-mini-chart" className="w-full h-[420px] block" />
}
