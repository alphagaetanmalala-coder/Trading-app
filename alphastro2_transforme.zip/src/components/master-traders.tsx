"use client"

import { useState } from "react"
import { Users, X } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface Trader {
  id: string
  name: string
  years: string
  image: string
  bio: string
  history: string
  method: string
  edge: string
  tips: string[]
}

const TRADERS: Trader[] = [
  {
    id: "livermore", name: "Jesse Livermore", years: "1877 – 1940",
    image: "https://upload.wikimedia.org/wikipedia/commons/3/3a/Jesse_Lauriston_Livermore.jpg",
    bio: "Spéculateur américain légendaire, surnommé 'Boy Plunger'. A gagné et perdu plusieurs fortunes.",
    history: "A anticipé le krach de 1907 et celui de 1929, amassant plus de 100M$ d'époque.",
    method: "Trading de tendance pure, pyramidage sur les gagnants, coupe immédiate des perdants.",
    edge: "Patience extrême + lecture du tape. 'L'argent se gagne en s'asseyant, pas en tradant'.",
    tips: [
      "Ne jamais moyenner à la baisse",
      "Suivre la ligne de moindre résistance",
      "Acheter haut, vendre plus haut",
    ],
  },
  {
    id: "soros", name: "George Soros", years: "1930 – présent",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/George_Soros_-_Festival_Economia_2012_02.JPG/640px-George_Soros_-_Festival_Economia_2012_02.JPG",
    bio: "Le 'briseur de la Banque d'Angleterre' — 1Md$ en une journée sur la Livre en 1992.",
    history: "Quantum Fund : 30%+ de rendement annuel composé pendant plus de 30 ans.",
    method: "Théorie de la réflexivité — les biais des participants modifient les fondamentaux.",
    edge: "Capacité unique à prendre des positions massives quand la conviction est totale.",
    tips: [
      "Quand vous avez raison, allez gros",
      "Reconnaître l'erreur vaut plus que d'avoir raison",
      "Les marchés sont influencés par les perceptions",
    ],
  },
  {
    id: "druckenmiller", name: "Stanley Druckenmiller", years: "1953 – présent",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=600&q=70",
    bio: "Bras droit de Soros sur le trade GBP. Duquesne Capital : 30% annuels sans année négative.",
    history: "Aucune perte annuelle sur 30 ans de gestion. Performance quasi-mythologique.",
    method: "Macro top-down + technique micro. Concentration extrême sur les meilleures idées.",
    edge: "Conviction binaire : full size ou rien. Refus du diktat de la diversification.",
    tips: [
      "Préservez le capital d'abord",
      "Mettez tous vos œufs dans le même panier et surveillez-le",
      "Les meilleurs traders ratent rarement la grande vague",
    ],
  },
  {
    id: "dalio", name: "Ray Dalio", years: "1949 – présent",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=70",
    bio: "Fondateur de Bridgewater Associates, plus grand hedge fund au monde.",
    history: "A théorisé la 'Machine économique' et le cycle de dette long terme.",
    method: "All Weather Portfolio + Pure Alpha. Diversification par drivers de retour.",
    edge: "Radical transparency + culture d'erreur. Principes systématisés.",
    tips: [
      "Le chemin vers le succès passe par les erreurs comprises",
      "Diversifier 15 sources de retour non corrélées",
      "Comprendre les cycles de dette long",
    ],
  },
  {
    id: "simons", name: "Jim Simons", years: "1938 – 2024",
    image: "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=600&q=70",
    bio: "Mathématicien et fondateur de Renaissance Technologies, Medallion Fund.",
    history: "66% bruts annuels pendant 30+ ans. Le track-record le plus extraordinaire de l'histoire.",
    method: "Trading 100% quantitatif, signaux statistiques sur des milliers de patterns.",
    edge: "Recrute uniquement PhD en maths/physique. Aucune intuition humaine.",
    tips: [
      "Les patterns existent, il faut les outils pour les voir",
      "Petite anomalie × énorme volume = fortune",
      "Discipline mathématique > émotion",
    ],
  },
  {
    id: "tudor", name: "Paul Tudor Jones", years: "1954 – présent",
    image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=600&q=70",
    bio: "Tudor Investment Corp. A prévu le Black Monday de 1987 avec une précision chirurgicale.",
    history: "+200% en octobre 1987. Maître du timing macro.",
    method: "Analyse technique + macro + Elliott Wave. Stops serrés, R:R 5:1 minimum.",
    edge: "Discipline du risque : 'Je suis paranoïaque chaque seconde de chaque journée'.",
    tips: [
      "Ne jamais risquer plus de 1% par trade",
      "Toujours imaginer le pire scénario d'abord",
      "Les meilleurs trades sont confortables car évidents",
    ],
  },
  {
    id: "buffett", name: "Warren Buffett", years: "1930 – présent",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Warren_Buffett_KU_Visit.jpg/640px-Warren_Buffett_KU_Visit.jpg",
    bio: "Oracle d'Omaha. Berkshire Hathaway : 20%+ annuels composés depuis 1965.",
    history: "L'investisseur le plus admiré du XXe siècle. Disciple de Benjamin Graham.",
    method: "Value investing — acheter d'excellentes entreprises à prix raisonnable, garder à vie.",
    edge: "Temporalité longue + cercle de compétence strict.",
    tips: [
      "Soyez avare quand les autres sont avides",
      "Le risque vient de ne pas savoir ce que vous faites",
      "Notre horizon de détention favori : pour toujours",
    ],
  },
  {
    id: "lynch", name: "Peter Lynch", years: "1944 – présent",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=600&q=70",
    bio: "Manager du Fidelity Magellan Fund : 29% annuels sur 13 ans (1977-1990).",
    history: "A popularisé l'idée d'investir dans ce qu'on connaît.",
    method: "Bottom-up, GARP (Growth At Reasonable Price). Recherche terrain intensive.",
    edge: "Curiosité du quotidien : observer les produits, magasins, habitudes des consommateurs.",
    tips: [
      "Investissez dans ce que vous comprenez",
      "Le PER doit être inférieur au taux de croissance",
      "Vingt baggers existent, cherchez-les",
    ],
  },
  {
    id: "dorsan", name: "Jacques Dorsan", years: "Référence sidérale moderne",
    image: "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=600&q=70",
    bio: "Pionnier français de l'astrologie financière sidérale appliquée aux marchés.",
    history: "A théorisé la corrélation entre aspects planétaires sidéraux et retournements majeurs.",
    method: "Carte natale d'un actif (date d'introduction) + transits planétaires sidéraux.",
    edge: "Anticipation des cycles que la pure technique ne peut voir.",
    tips: [
      "Tout actif possède un thème natal sidéral",
      "Les carrés et oppositions = volatilité",
      "Trigones et sextiles = tendances fluides",
    ],
  },
  {
    id: "gann", name: "W. D. Gann", years: "1878 – 1955",
    image: "https://upload.wikimedia.org/wikipedia/commons/0/0c/William_Delbert_Gann.jpg",
    bio: "Trader américain mystique, inventeur des angles de Gann et de la 'Square of Nine'.",
    history: "Performances mythiques + livres ésotériques (Tunnel Through the Air).",
    method: "Géométrie sacrée prix×temps, cycles, vibrations numériques.",
    edge: "Synthèse unique entre mathématiques, astronomie et trading.",
    tips: [
      "Le temps est plus important que le prix",
      "Tout marché a son angle naturel",
      "Le marché est mathématique avant tout",
    ],
  },
]

export function MasterTraders() {
  const [open, setOpen] = useState<string | null>(null)
  const active = TRADERS.find((t) => t.id === open)

  return (
    <div className="p-4 lg:p-6 space-y-4">
      <Card className="bg-card/50 border-border/50 backdrop-blur">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Users className="h-5 w-5 text-primary" />
            Profils des Maîtres Traders
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {TRADERS.map((t) => (
              <button
                key={t.id}
                onClick={() => setOpen(t.id)}
                className="text-left rounded-lg overflow-hidden border border-border/40 bg-secondary/30 hover:border-primary/60 transition-all"
              >
                <div className="aspect-square overflow-hidden">
                  <img src={t.image} alt={t.name} className="w-full h-full object-cover" />
                </div>
                <div className="p-3">
                  <div className="font-semibold text-foreground text-sm">{t.name}</div>
                  <div className="text-[10px] text-muted-foreground">{t.years}</div>
                </div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {active && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur flex items-center justify-center p-4"
          onClick={() => setOpen(null)}
        >
          <div
            className="max-w-2xl w-full max-h-[90vh] overflow-y-auto bg-card border border-border/60 rounded-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative">
              <img src={active.image} alt={active.name} className="w-full h-56 object-cover" />
              <button
                onClick={() => setOpen(null)}
                className="absolute top-2 right-2 p-2 rounded-full bg-black/60 text-white hover:bg-black/80"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="p-5 space-y-3">
              <div>
                <h3 className="text-xl font-bold text-foreground">{active.name}</h3>
                <p className="text-xs text-muted-foreground">{active.years}</p>
              </div>
              <Block label="Biographie" content={active.bio} />
              <Block label="Histoire" content={active.history} />
              <Block label="Méthodologie de trading" content={active.method} />
              <Block label="Edge psychologique" content={active.edge} />
              <div>
                <div className="text-xs font-semibold text-accent mb-1">Conseils clés</div>
                <ul className="text-sm text-foreground space-y-1 list-disc pl-5">
                  {active.tips.map((tip, i) => <li key={i}>{tip}</li>)}
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function Block({ label, content }: { label: string; content: string }) {
  return (
    <div>
      <div className="text-xs font-semibold text-accent mb-1">{label}</div>
      <p className="text-sm text-foreground leading-relaxed">{content}</p>
    </div>
  )
}
