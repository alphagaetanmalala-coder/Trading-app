"use client"

import { useEffect, useState } from "react"
import { Scroll } from "lucide-react"

const VERSES = [
  { r: "Proverbes 13:11", t: "Une fortune mal acquise diminue, mais celui qui amasse peu à peu l'augmente." },
  { r: "Ecclésiaste 11:2", t: "Donnes-en une part à sept, et même à huit, car tu ne sais pas quel malheur peut arriver sur la terre." },
  { r: "Proverbes 22:7", t: "Le riche domine sur les pauvres, et celui qui emprunte est l'esclave de celui qui prête." },
  { r: "1 Hénoch 94:8 (Apocryphe)", t: "Malheur à ceux qui placent leur cœur dans les richesses au jour de leur opulence." },
  { r: "Tobie 4:14", t: "Ne garde pas chez toi le salaire du mercenaire ; paie-le immédiatement." },
  { r: "Siracide 27:1", t: "Beaucoup ont péché pour le gain, et celui qui cherche à s'enrichir détourne les yeux." },
  { r: "Sagesse 7:11", t: "Tous les biens me sont venus avec elle, et par ses mains une richesse incalculable." },
  { r: "Proverbes 16:3", t: "Recommande à l'Éternel tes œuvres, et tes projets réussiront." },
]

export function BiblicalVerses() {
  const [idx, setIdx] = useState(0)
  useEffect(() => {
    const t = setInterval(() => setIdx((i) => (i + 1) % VERSES.length), 12_000)
    return () => clearInterval(t)
  }, [])
  const v = VERSES[idx]
  return (
    <div className="rounded-lg border border-accent/30 bg-accent/5 px-4 py-3 flex items-start gap-3">
      <Scroll className="h-4 w-4 text-accent mt-0.5 flex-shrink-0" />
      <div>
        <div className="text-[10px] uppercase tracking-wider text-accent mb-0.5">Verset du moment</div>
        <p className="text-sm text-foreground italic">« {v.t} »</p>
        <p className="text-xs text-muted-foreground mt-1">— {v.r}</p>
      </div>
    </div>
  )
}
