"use client"

import { useState, useEffect, useRef } from "react"
import { 
  TrendingUp, 
  TrendingDown, 
  Settings,
  Maximize2,
  ZoomIn,
  ZoomOut,
  Clock,
  Layers
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { 
  useCandleData,
  usePlanetaryData,
  detectCHOCH,
  detectBOS,
  detectFVG,
  detectOrderBlock,
  detectWyckoffPhase,
  type Candle,
  type TechnicalIndicator,
  type WyckoffPhase
} from "@/lib/trading-engine"

const ASSETS = [
  { symbol: "EUR/USD", name: "Euro / Dollar US" },
  { symbol: "GBP/USD", name: "Livre / Dollar US" },
  { symbol: "USD/JPY", name: "Dollar US / Yen" },
  { symbol: "BTC/USD", name: "Bitcoin / Dollar US" },
  { symbol: "ETH/USD", name: "Ethereum / Dollar US" },
  { symbol: "XAU/USD", name: "Or / Dollar US" },
]

const TIMEFRAMES = ["M1", "M5", "M15", "H1", "H4", "D1"]

export function DualChartModule() {
  const [selectedAsset, setSelectedAsset] = useState(ASSETS[0].symbol)
  const [selectedTimeframe, setSelectedTimeframe] = useState("H1")
  const [showIndicators, setShowIndicators] = useState(true)

  const { candles, loading } = useCandleData(selectedAsset, selectedTimeframe)
  const { positions, aspects } = usePlanetaryData()

  // Technical analysis
  const choch = candles.length > 0 ? detectCHOCH(candles) : null
  const bos = candles.length > 0 ? detectBOS(candles) : null
  const fvg = candles.length > 0 ? detectFVG(candles) : null
  const ob = candles.length > 0 ? detectOrderBlock(candles) : null
  const wyckoff = candles.length > 0 ? detectWyckoffPhase(candles) : { phase: "Accumulation" as const, confidence: 0, description: "" }

  const indicators = [choch, bos, fvg, ob].filter(Boolean) as TechnicalIndicator[]

  return (
    <div className="space-y-4 p-4 lg:p-6">
      {/* Controls */}
      <div className="flex flex-wrap items-center gap-4">
        {/* Asset Selector */}
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Actif:</span>
          <select
            value={selectedAsset}
            onChange={(e) => setSelectedAsset(e.target.value)}
            className="bg-secondary/50 border border-border/50 rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            {ASSETS.map((asset) => (
              <option key={asset.symbol} value={asset.symbol}>
                {asset.symbol}
              </option>
            ))}
          </select>
        </div>

        {/* Timeframe Selector */}
        <div className="flex items-center gap-1 bg-secondary/30 rounded-lg p-1">
          {TIMEFRAMES.map((tf) => (
            <button
              key={tf}
              onClick={() => setSelectedTimeframe(tf)}
              className={cn(
                "px-3 py-1.5 text-xs font-medium rounded-md transition-all",
                selectedTimeframe === tf
                  ? "bg-primary text-primary-foreground glow-blue"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
              )}
            >
              {tf}
            </button>
          ))}
        </div>

        {/* Toggle Indicators */}
        <button
          onClick={() => setShowIndicators(!showIndicators)}
          className={cn(
            "flex items-center gap-2 px-3 py-2 text-sm rounded-lg transition-all",
            showIndicators
              ? "bg-primary/20 text-primary"
              : "bg-secondary/50 text-muted-foreground"
          )}
        >
          <Layers className="h-4 w-4" />
          Indicateurs ICT/SMC
        </button>
      </div>

      {/* Dual Chart Grid */}
      <div className="grid lg:grid-cols-2 gap-4">
        {/* Chart 1: Financial Chart */}
        <Card className="bg-card/50 border-border/50 backdrop-blur">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-foreground">
                <TrendingUp className="h-5 w-5 text-primary" />
                Graphique Financier - {selectedAsset}
              </CardTitle>
              <div className="flex items-center gap-2">
                <button className="p-1.5 rounded-lg hover:bg-secondary/50 text-muted-foreground">
                  <ZoomIn className="h-4 w-4" />
                </button>
                <button className="p-1.5 rounded-lg hover:bg-secondary/50 text-muted-foreground">
                  <ZoomOut className="h-4 w-4" />
                </button>
                <button className="p-1.5 rounded-lg hover:bg-secondary/50 text-muted-foreground">
                  <Maximize2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <CandlestickChart 
              candles={candles} 
              indicators={showIndicators ? indicators : []}
              loading={loading}
            />
            
            {/* Wyckoff Phase */}
            <div className="mt-4 p-3 rounded-lg bg-secondary/30">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">Phase Wyckoff</span>
                <span className={cn(
                  "text-xs px-2 py-1 rounded-full",
                  wyckoff.phase === "Accumulation" || wyckoff.phase === "Spring"
                    ? "bg-neon-green/20 text-neon-green"
                    : wyckoff.phase === "Expansion"
                      ? "bg-primary/20 text-primary"
                      : "bg-neon-red/20 text-neon-red"
                )}>
                  {wyckoff.phase}
                </span>
              </div>
              <p className="text-xs text-muted-foreground">{wyckoff.description}</p>
              <div className="mt-2 h-1.5 bg-secondary rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary transition-all"
                  style={{ width: `${wyckoff.confidence * 100}%` }}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Chart 2: Astrological Astro-Curve */}
        <Card className="bg-card/50 border-border/50 backdrop-blur">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-foreground">
                <Clock className="h-5 w-5 text-accent" />
                Astro-Courbe Sidérale (Dorsan)
              </CardTitle>
              <Settings className="h-4 w-4 text-muted-foreground" />
            </div>
          </CardHeader>
          <CardContent>
            <AstroCurveChart 
              positions={positions}
              aspects={aspects}
            />

            {/* Active Aspects */}
            <div className="mt-4 space-y-2">
              <span className="text-sm font-medium text-foreground">Aspects Actifs</span>
              <div className="grid grid-cols-2 gap-2">
                {aspects.slice(0, 4).map((aspect, i) => (
                  <div 
                    key={i}
                    className={cn(
                      "p-2 rounded-lg text-xs",
                      aspect.type === "trigone" || aspect.type === "sextile"
                        ? "bg-neon-green/10 border border-neon-green/30"
                        : aspect.type === "carré" || aspect.type === "opposition"
                          ? "bg-neon-red/10 border border-neon-red/30"
                          : "bg-primary/10 border border-primary/30"
                    )}
                  >
                    <div className="font-medium text-foreground">
                      {aspect.planet1} {getAspectSymbol(aspect.type)} {aspect.planet2}
                    </div>
                    <div className="text-muted-foreground">
                      Orbe: {aspect.orb.toFixed(1)}°
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detected Indicators Panel */}
      {showIndicators && indicators.length > 0 && (
        <Card className="bg-card/50 border-border/50 backdrop-blur">
          <CardHeader className="pb-2">
            <CardTitle className="text-foreground">Structures ICT/SMC Détectées</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {indicators.map((ind, i) => (
                <div 
                  key={i}
                  className={cn(
                    "p-3 rounded-lg",
                    ind.direction === "haussier"
                      ? "bg-neon-green/10 border border-neon-green/30"
                      : "bg-neon-red/10 border border-neon-red/30"
                  )}
                >
                  <div className="flex items-center gap-2 mb-1">
                    {ind.direction === "haussier" ? (
                      <TrendingUp className="h-4 w-4 text-neon-green" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-neon-red" />
                    )}
                    <span className="font-semibold text-foreground">{ind.type}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Prix: {ind.price.toFixed(5)}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Force: {(ind.strength * 100).toFixed(0)}%
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function CandlestickChart({ 
  candles, 
  indicators,
  loading 
}: { 
  candles: Candle[]
  indicators: TechnicalIndicator[]
  loading: boolean
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current || candles.length === 0) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const dpr = window.devicePixelRatio || 1
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    ctx.scale(dpr, dpr)

    const width = rect.width
    const height = rect.height
    const padding = { top: 20, right: 60, bottom: 30, left: 10 }

    // Clear canvas
    ctx.fillStyle = "rgba(15, 17, 25, 0.8)"
    ctx.fillRect(0, 0, width, height)

    // Calculate price range
    const prices = candles.flatMap(c => [c.high, c.low])
    const minPrice = Math.min(...prices)
    const maxPrice = Math.max(...prices)
    const priceRange = maxPrice - minPrice
    const paddedMin = minPrice - priceRange * 0.05
    const paddedMax = maxPrice + priceRange * 0.05
    const paddedRange = paddedMax - paddedMin

    // Price scale
    const priceToY = (price: number) => 
      padding.top + ((paddedMax - price) / paddedRange) * (height - padding.top - padding.bottom)

    // Draw grid
    ctx.strokeStyle = "rgba(100, 116, 139, 0.1)"
    ctx.lineWidth = 1
    for (let i = 0; i <= 5; i++) {
      const y = padding.top + (i / 5) * (height - padding.top - padding.bottom)
      ctx.beginPath()
      ctx.moveTo(padding.left, y)
      ctx.lineTo(width - padding.right, y)
      ctx.stroke()

      // Price labels
      const price = paddedMax - (i / 5) * paddedRange
      ctx.fillStyle = "rgba(148, 163, 184, 0.7)"
      ctx.font = "10px monospace"
      ctx.textAlign = "left"
      ctx.fillText(price.toFixed(5), width - padding.right + 5, y + 3)
    }

    // Draw candles
    const candleCount = Math.min(candles.length, 60)
    const displayCandles = candles.slice(-candleCount)
    const candleWidth = (width - padding.left - padding.right) / candleCount
    const bodyWidth = candleWidth * 0.7

    displayCandles.forEach((candle, i) => {
      const x = padding.left + i * candleWidth + candleWidth / 2
      const isGreen = candle.close >= candle.open
      
      // Wick
      ctx.strokeStyle = isGreen ? "rgb(34, 197, 94)" : "rgb(239, 68, 68)"
      ctx.lineWidth = 1
      ctx.beginPath()
      ctx.moveTo(x, priceToY(candle.high))
      ctx.lineTo(x, priceToY(candle.low))
      ctx.stroke()

      // Body
      const bodyTop = priceToY(Math.max(candle.open, candle.close))
      const bodyBottom = priceToY(Math.min(candle.open, candle.close))
      const bodyHeight = Math.max(bodyBottom - bodyTop, 1)

      ctx.fillStyle = isGreen ? "rgb(34, 197, 94)" : "rgb(239, 68, 68)"
      ctx.fillRect(x - bodyWidth / 2, bodyTop, bodyWidth, bodyHeight)
    })

    // Draw indicators
    indicators.forEach(ind => {
      const y = priceToY(ind.price)
      ctx.strokeStyle = ind.direction === "haussier" 
        ? "rgba(34, 197, 94, 0.8)" 
        : "rgba(239, 68, 68, 0.8)"
      ctx.lineWidth = 2
      ctx.setLineDash([5, 3])
      ctx.beginPath()
      ctx.moveTo(padding.left, y)
      ctx.lineTo(width - padding.right, y)
      ctx.stroke()
      ctx.setLineDash([])

      // Label
      ctx.fillStyle = ind.direction === "haussier" 
        ? "rgb(34, 197, 94)" 
        : "rgb(239, 68, 68)"
      ctx.font = "bold 10px sans-serif"
      ctx.fillText(ind.type, padding.left + 5, y - 5)
    })

  }, [candles, indicators])

  if (loading) {
    return (
      <div className="h-[300px] flex items-center justify-center bg-secondary/20 rounded-lg">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <canvas 
      ref={canvasRef}
      className="w-full h-[300px] rounded-lg"
      style={{ imageRendering: "crisp-edges" }}
    />
  )
}

function AstroCurveChart({ 
  positions, 
  aspects 
}: { 
  positions: any[]
  aspects: any[]
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const dpr = window.devicePixelRatio || 1
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    ctx.scale(dpr, dpr)

    const width = rect.width
    const height = rect.height
    const centerX = width / 2
    const centerY = height / 2
    const radius = Math.min(width, height) / 2 - 40

    // Clear canvas
    ctx.fillStyle = "rgba(15, 17, 25, 0.8)"
    ctx.fillRect(0, 0, width, height)

    // Draw zodiac wheel
    for (let i = 0; i < 12; i++) {
      const startAngle = (i * 30 - 90) * (Math.PI / 180)
      const endAngle = ((i + 1) * 30 - 90) * (Math.PI / 180)
      
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius, startAngle, endAngle)
      ctx.strokeStyle = "rgba(100, 180, 255, 0.3)"
      ctx.lineWidth = 2
      ctx.stroke()

      // Sign labels
      const signs = ["♈", "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐", "♑", "♒", "♓"]
      const labelAngle = (i * 30 + 15 - 90) * (Math.PI / 180)
      const labelX = centerX + Math.cos(labelAngle) * (radius + 20)
      const labelY = centerY + Math.sin(labelAngle) * (radius + 20)
      
      ctx.fillStyle = "rgba(100, 180, 255, 0.6)"
      ctx.font = "14px serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(signs[i], labelX, labelY)
    }

    // Draw inner circles
    [0.8, 0.6, 0.4].forEach(scale => {
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius * scale, 0, Math.PI * 2)
      ctx.strokeStyle = "rgba(100, 180, 255, 0.1)"
      ctx.lineWidth = 1
      ctx.stroke()
    })

    // Draw planets
    const planetColors: Record<string, string> = {
      "Soleil": "#FFD700",
      "Lune": "#C0C0C0",
      "Mercure": "#87CEEB",
      "Vénus": "#FFC0CB",
      "Mars": "#FF6347",
      "Jupiter": "#DEB887",
      "Saturne": "#F0E68C"
    }

    positions.forEach((pos, i) => {
      const angle = (pos.longitude - 90) * (Math.PI / 180)
      const planetRadius = radius * (0.5 + i * 0.06)
      const x = centerX + Math.cos(angle) * planetRadius
      const y = centerY + Math.sin(angle) * planetRadius

      // Planet glow
      const gradient = ctx.createRadialGradient(x, y, 0, x, y, 15)
      gradient.addColorStop(0, planetColors[pos.planet] || "#FFFFFF")
      gradient.addColorStop(1, "transparent")
      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.arc(x, y, 15, 0, Math.PI * 2)
      ctx.fill()

      // Planet dot
      ctx.fillStyle = planetColors[pos.planet] || "#FFFFFF"
      ctx.beginPath()
      ctx.arc(x, y, 6, 0, Math.PI * 2)
      ctx.fill()

      // Retrograde indicator
      if (pos.retrograde) {
        ctx.strokeStyle = "#FF6347"
        ctx.lineWidth = 2
        ctx.beginPath()
        ctx.arc(x, y, 10, 0, Math.PI * 2)
        ctx.stroke()
      }
    })

    // Draw aspect lines
    aspects.forEach(aspect => {
      const pos1 = positions.find(p => p.planet === aspect.planet1)
      const pos2 = positions.find(p => p.planet === aspect.planet2)
      if (!pos1 || !pos2) return

      const angle1 = (pos1.longitude - 90) * (Math.PI / 180)
      const angle2 = (pos2.longitude - 90) * (Math.PI / 180)
      
      const idx1 = positions.indexOf(pos1)
      const idx2 = positions.indexOf(pos2)
      
      const r1 = radius * (0.5 + idx1 * 0.06)
      const r2 = radius * (0.5 + idx2 * 0.06)

      const x1 = centerX + Math.cos(angle1) * r1
      const y1 = centerY + Math.sin(angle1) * r1
      const x2 = centerX + Math.cos(angle2) * r2
      const y2 = centerY + Math.sin(angle2) * r2

      ctx.beginPath()
      ctx.moveTo(x1, y1)
      ctx.lineTo(x2, y2)
      
      if (aspect.type === "trigone" || aspect.type === "sextile") {
        ctx.strokeStyle = "rgba(34, 197, 94, 0.5)"
      } else if (aspect.type === "carré" || aspect.type === "opposition") {
        ctx.strokeStyle = "rgba(239, 68, 68, 0.5)"
      } else {
        ctx.strokeStyle = "rgba(100, 180, 255, 0.5)"
      }
      
      ctx.lineWidth = aspect.exact ? 2 : 1
      ctx.stroke()
    })

  }, [positions, aspects])

  return (
    <canvas 
      ref={canvasRef}
      className="w-full h-[300px] rounded-lg"
    />
  )
}

function getAspectSymbol(type: string): string {
  const symbols: Record<string, string> = {
    "conjonction": "☌",
    "opposition": "☍",
    "carré": "□",
    "trigone": "△",
    "sextile": "⚹"
  }
  return symbols[type] || "•"
}
