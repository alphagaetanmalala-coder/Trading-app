"use client"

import { useEffect, useRef, useState } from "react"
import { Send, Copy, CheckCircle2, ShieldCheck, Radio } from "lucide-react"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { pushNotification } from "@/lib/notification-store"

type Direction = "BUY" | "SELL"
type RawSignal = {
  id: string
  trader: string
  handle: string
  avatarColor: string
  verified: boolean
  pair: string
  direction: Direction
  entry: number
  sl: number
  tp1: number
  tp2: number
  tp3: number
  ts: number
  raw: string
}

const TRADERS = [
  { name: "Gold Hunter Pro", handle: "@goldhunter_official", color: "from-amber-400 to-yellow-600" },
  { name: "ICT Killzone FR", handle: "@ict_killzone_fr", color: "from-sky-400 to-blue-600" },
  { name: "Belkhayate Légende", handle: "@belkhayate_signals", color: "from-violet-400 to-purple-600" },
  { name: "Madagascar Forex", handle: "@mada_fx_alpha", color: "from-emerald-400 to-green-600" },
  { name: "Smart Money FX", handle: "@smartmoney_fx", color: "from-pink-400 to-rose-600" },
  { name: "Astro Trader EAT", handle: "@astro_trader_eat", color: "from-indigo-400 to-fuchsia-600" },
]

const PAIRS = ["XAU/USD", "EUR/USD", "GBP/USD", "USD/JPY", "BTC/USD", "USOIL", "GBP/JPY", "AUD/USD"]

const PAIR_PRICES: Record<string, number> = {
  "XAU/USD": 4502, "EUR/USD": 1.085, "GBP/USD": 1.275, "USD/JPY": 156.4,
  "BTC/USD": 67400, "USOIL": 78.5, "GBP/JPY": 199.5, "AUD/USD": 0.665,
}

function randomSignal(): RawSignal {
  const t = TRADERS[Math.floor(Math.random() * TRADERS.length)]
  const pair = PAIRS[Math.floor(Math.random() * PAIRS.length)]
  const direction: Direction = Math.random() > 0.5 ? "BUY" : "SELL"
  const base = PAIR_PRICES[pair]
  const vol = base * 0.004
  const entry = +(base + (Math.random() - 0.5) * vol).toFixed(pair.includes("JPY") || pair === "BTC/USD" || pair === "USOIL" || pair === "XAU/USD" ? 2 : 5)
  const sign = direction === "BUY" ? 1 : -1
  const decimals = pair.includes("JPY") || pair === "BTC/USD" || pair === "USOIL" || pair === "XAU/USD" ? 2 : 5
  const r = (n: number) => +n.toFixed(decimals)
  const sl = r(entry - sign * vol * 0.6)
  const tp1 = r(entry + sign * vol * 0.5)
  const tp2 = r(entry + sign * vol * 1.0)
  const tp3 = r(entry + sign * vol * 1.8)
  const raw = `🔥 SIGNAL ${direction} ${pair} 🔥
📊 Entry: ${entry}
🛑 SL: ${sl}
🎯 TP1: ${tp1}
🎯 TP2: ${tp2}
🎯 TP3: ${tp3}
⚡ Setup ICT + confluence Belkhayate
💎 Money management strict: 1% risque max`
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    trader: t.name,
    handle: t.handle,
    avatarColor: t.color,
    verified: Math.random() > 0.3,
    pair, direction, entry, sl, tp1, tp2, tp3,
    ts: Date.now(),
    raw,
  }
}

export function TelegramAggregator() {
  const [signals, setSignals] = useState<RawSignal[]>([])
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const seeded = useRef(false)

  // Seed initial feed
  useEffect(() => {
    if (seeded.current) return
    seeded.current = true
    const initial = Array.from({ length: 6 }, () => {
      const s = randomSignal()
      // backdate
      s.ts = Date.now() - Math.floor(Math.random() * 1000 * 60 * 30)
      return s
    }).sort((a, b) => b.ts - a.ts)
    setSignals(initial)
  }, [])

  // Live aggregator: new signal every 18–35s
  useEffect(() => {
    let cancelled = false
    function schedule() {
      const delay = 18000 + Math.random() * 17000
      const t = setTimeout(() => {
        if (cancelled) return
        const s = randomSignal()
        setSignals(prev => [s, ...prev].slice(0, 50))
        pushNotification({
          kind: "telegram",
          source: `Telegram · ${s.trader}`,
          title: `${s.direction} ${s.pair} · ${s.trader}`,
          body: s.raw,
          payload: { ...s },
        })
        schedule()
      }, delay)
      return t
    }
    const handle = schedule()
    return () => { cancelled = true; clearTimeout(handle) }
  }, [])

  function copy(s: RawSignal) {
    try {
      navigator.clipboard?.writeText(s.raw)
      setCopiedId(s.id)
      setTimeout(() => setCopiedId(null), 1500)
    } catch {}
  }

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-3">
        <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-sky-400 to-blue-600 flex items-center justify-center shadow-[0_0_30px_rgba(56,189,248,0.45)]">
          <Send className="h-6 w-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            Agrégateur Telegram Alpha · Signaux Bruts
          </h1>
          <p className="text-sm text-muted-foreground flex items-center gap-2">
            <span className="inline-flex items-center gap-1">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              Flux temps réel
            </span>
            · Clone des canaux Telegram & Facebook de traders vérifiés
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {signals.map((s, idx) => (
          <Card
            key={s.id}
            className={cn(
              "p-4 bg-darker-surface/70 backdrop-blur-xl border-border/60",
              "transition-all hover:border-primary/40",
              idx === 0 && "ring-1 ring-primary/40 shadow-[0_0_25px_rgba(56,189,248,0.15)]",
            )}
          >
            {/* Trader header */}
            <div className="flex items-start justify-between gap-3 mb-3">
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className={cn(
                    "h-12 w-12 rounded-full bg-gradient-to-br flex items-center justify-center flex-shrink-0 text-white font-bold text-lg",
                    s.avatarColor,
                  )}
                >
                  {s.trader.split(" ").map(w => w[0]).slice(0, 2).join("")}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-foreground truncate text-base">
                      {s.trader}
                    </span>
                    {s.verified && (
                      <ShieldCheck className="h-4 w-4 text-sky-400 flex-shrink-0" />
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground truncate">
                    {s.handle} · {new Date(s.ts).toLocaleTimeString("fr-FR")}
                  </div>
                </div>
              </div>

              <span
                className={cn(
                  "px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 flex-shrink-0",
                  s.direction === "BUY"
                    ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40"
                    : "bg-red-500/20 text-red-400 border border-red-500/40",
                )}
              >
                <Radio className="h-3 w-3" />
                {s.direction} {s.pair}
              </span>
            </div>

            {/* Raw message */}
            <pre className="text-sm whitespace-pre-wrap font-mono bg-background/40 p-3 rounded-lg border border-border/40 text-foreground/90 leading-relaxed">
              {s.raw}
            </pre>

            {/* Parsed parameters grid */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mt-3">
              {[
                { label: "Entrée", value: s.entry, color: "text-foreground" },
                { label: "SL", value: s.sl, color: "text-red-400" },
                { label: "TP1", value: s.tp1, color: "text-emerald-400" },
                { label: "TP2", value: s.tp2, color: "text-emerald-400" },
                { label: "TP3", value: s.tp3, color: "text-emerald-400" },
              ].map(b => (
                <div key={b.label} className="px-2 py-1.5 rounded bg-secondary/40 text-center">
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider">{b.label}</div>
                  <div className={cn("font-mono text-sm font-semibold", b.color)}>{b.value}</div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-end mt-3">
              <button
                onClick={() => copy(s)}
                className="text-xs flex items-center gap-1.5 px-3 py-1.5 rounded-md hover:bg-secondary/60 text-muted-foreground"
              >
                {copiedId === s.id ? (
                  <><CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" /> Copié</>
                ) : (
                  <><Copy className="h-3.5 w-3.5" /> Copier le message brut</>
                )}
              </button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
