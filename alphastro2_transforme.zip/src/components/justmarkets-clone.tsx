"use client"

import { useEffect, useState } from "react"
import { generateOandaData, OANDA_FOREX_PAIRS } from "@/lib/oanda-api"
import { cn } from "@/lib/utils"
import { ArrowUpRight, ArrowDownRight, Wallet, Shield, Trophy, Zap, TrendingUp, TrendingDown } from "lucide-react"

type Order = {
  id: string; pair: string; side: "BUY" | "SELL"; lot: number
  entry: number; sl: number; tp: number; opened: number; current: number
}

export function JustMarketsClone() {
  const [balance] = useState(50000)
  const [pair, setPair] = useState("XAU_USD")
  const [lot, setLot] = useState(0.10)
  const [sl, setSl] = useState(50)
  const [tp, setTp] = useState(100)
  const [prices, setPrices] = useState<Record<string, { bid: number; ask: number; spread: number }>>({})
  const [orders, setOrders] = useState<Order[]>([])

  useEffect(() => {
    const tick = () => {
      const next: typeof prices = {}
      OANDA_FOREX_PAIRS.forEach(p => {
        const c = generateOandaData(p.instrument, "M1", 1)[0]
        const sp = p.instrument.includes("XAU") ? 0.35 : p.instrument.includes("JPY") ? 0.015 : 0.00012
        next[p.instrument] = { bid: c.close, ask: c.close + sp, spread: sp }
      })
      setPrices(next)
      setOrders(os => os.map(o => ({ ...o, current: next[o.pair.replace("/", "_")]?.bid ?? o.current })))
    }
    tick(); const i = setInterval(tick, 1500); return () => clearInterval(i)
  }, [])

  const cur = prices[pair]
  const pipVal = pair.includes("XAU") ? 0.1 : pair.includes("JPY") ? 0.01 : 0.0001

  const place = (side: "BUY" | "SELL") => {
    if (!cur) return
    const entry = side === "BUY" ? cur.ask : cur.bid
    const o: Order = {
      id: Math.random().toString(36).slice(2, 8).toUpperCase(),
      pair: pair.replace("_", "/"), side, lot,
      entry, sl: side === "BUY" ? entry - sl * pipVal : entry + sl * pipVal,
      tp: side === "BUY" ? entry + tp * pipVal : entry - tp * pipVal,
      opened: Date.now(), current: entry,
    }
    setOrders(os => [o, ...os])
  }

  const close = (id: string) => setOrders(os => os.filter(o => o.id !== id))

  const pnl = (o: Order) => {
    const diff = (o.side === "BUY" ? o.current - o.entry : o.entry - o.current) / pipVal
    const contractSize = o.pair.includes("XAU") ? 100 : 100000
    return diff * pipVal * contractSize * o.lot
  }
  const equity = balance + orders.reduce((s, o) => s + pnl(o), 0)
  const margin = orders.reduce((s, o) => s + (o.lot * (o.pair.includes("XAU") ? 100 : 100000) * o.entry) / 500, 0)
  const free = equity - margin

  return (
    <div className="p-3 lg:p-5 space-y-4">
      {/* Brand header */}
      <div className="rounded-xl border border-border/60 bg-gradient-to-r from-orange-500/15 via-darker-surface to-darker-surface p-5 flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4">
          <div className="h-14 w-14 rounded-xl bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center shadow-[0_0_25px_rgba(249,115,22,0.5)]">
            <span className="text-2xl font-black text-white">JM</span>
          </div>
          <div>
            <h2 className="text-2xl font-black tracking-tight">JustMarkets</h2>
            <p className="text-xs text-muted-foreground">Broker STP/ECN · Compte ICN-58291 · Levier 1:500 · Type Pro</p>
          </div>
        </div>
        <div className="flex gap-3 text-xs">
          <Badge icon={Shield} label="Régulé FSCA" />
          <Badge icon={Trophy} label="Award 2024" />
          <Badge icon={Zap} label="Exécution <30ms" />
        </div>
      </div>

      {/* Account stats */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <Stat label="Solde" value={`$${balance.toLocaleString("fr-FR", { minimumFractionDigits: 2 })}`} />
        <Stat label="Équité" value={`$${equity.toLocaleString("fr-FR", { minimumFractionDigits: 2 })}`} color={equity >= balance ? "text-emerald-400" : "text-red-400"} />
        <Stat label="Marge utilisée" value={`$${margin.toFixed(2)}`} />
        <Stat label="Marge libre" value={`$${free.toFixed(2)}`} />
        <Stat label="Niveau marge" value={margin > 0 ? `${((equity / margin) * 100).toFixed(0)}%` : "∞"} color="text-amber-400" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr_320px] gap-3">
        {/* Market Watch */}
        <div className="rounded-lg border border-border/60 bg-darker-surface/60 max-h-[560px] overflow-y-auto">
          <div className="px-3 py-2 text-xs font-bold uppercase border-b border-border/60 text-muted-foreground sticky top-0 bg-darker-surface">Surveillance Marché</div>
          {OANDA_FOREX_PAIRS.map(p => {
            const px = prices[p.instrument]
            return (
              <button key={p.instrument} onClick={() => setPair(p.instrument)}
                className={cn("w-full flex items-center justify-between px-3 py-2 text-xs border-b border-border/30 hover:bg-secondary/30",
                  pair === p.instrument && "bg-primary/10")}>
                <span className="font-semibold">{p.displayName}</span>
                <div className="flex gap-3 font-mono">
                  <span className="text-red-400">{px?.bid.toFixed(p.instrument.includes("XAU") ? 2 : p.instrument.includes("JPY") ? 3 : 5) ?? "—"}</span>
                  <span className="text-emerald-400">{px?.ask.toFixed(p.instrument.includes("XAU") ? 2 : p.instrument.includes("JPY") ? 3 : 5) ?? "—"}</span>
                </div>
              </button>
            )
          })}
        </div>

        {/* Trade panel + open positions */}
        <div className="space-y-3">
          <div className="rounded-lg border border-border/60 bg-darker-surface/60 p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="text-xs text-muted-foreground">Instrument</div>
                <div className="text-xl font-bold">{pair.replace("_", "/")}</div>
              </div>
              {cur && (
                <div className="flex gap-4">
                  <div className="text-center">
                    <div className="text-[10px] text-muted-foreground">BID (Vente)</div>
                    <div className="text-2xl font-bold font-mono text-red-400">{cur.bid.toFixed(pair.includes("XAU") ? 2 : 5)}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-[10px] text-muted-foreground">SPREAD</div>
                    <div className="text-2xl font-mono text-muted-foreground">{(cur.spread / pipVal).toFixed(1)}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-[10px] text-muted-foreground">ASK (Achat)</div>
                    <div className="text-2xl font-bold font-mono text-emerald-400">{cur.ask.toFixed(pair.includes("XAU") ? 2 : 5)}</div>
                  </div>
                </div>
              )}
            </div>
            <div className="grid grid-cols-3 gap-3 mb-3">
              <Field label="Volume (lots)" value={lot} onChange={setLot} step={0.01} min={0.01} />
              <Field label="Stop Loss (pips)" value={sl} onChange={setSl} step={5} min={0} />
              <Field label="Take Profit (pips)" value={tp} onChange={setTp} step={5} min={0} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button onClick={() => place("SELL")} className="py-3 rounded-lg bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 font-bold flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(239,68,68,0.3)]">
                <ArrowDownRight className="h-4 w-4" /> SELL · {cur?.bid.toFixed(pair.includes("XAU") ? 2 : 5)}
              </button>
              <button onClick={() => place("BUY")} className="py-3 rounded-lg bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 font-bold flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(16,185,129,0.3)]">
                <ArrowUpRight className="h-4 w-4" /> BUY · {cur?.ask.toFixed(pair.includes("XAU") ? 2 : 5)}
              </button>
            </div>
          </div>

          <div className="rounded-lg border border-border/60 bg-darker-surface/60">
            <div className="px-3 py-2 text-xs font-bold uppercase border-b border-border/60 text-muted-foreground">
              Positions Ouvertes ({orders.length})
            </div>
            {orders.length === 0 ? (
              <div className="p-6 text-center text-xs text-muted-foreground">Aucune position ouverte</div>
            ) : (
              <table className="w-full text-xs">
                <thead className="text-[10px] uppercase text-muted-foreground">
                  <tr><th className="px-2 py-1.5 text-left">Ticket</th><th className="text-left">Paire</th><th>Sens</th><th>Lot</th><th>Entrée</th><th>SL</th><th>TP</th><th>Prix</th><th>P&L</th><th /></tr>
                </thead>
                <tbody>
                  {orders.map(o => {
                    const p = pnl(o)
                    return (
                      <tr key={o.id} className="border-t border-border/30 font-mono">
                        <td className="px-2 py-1.5">{o.id}</td><td>{o.pair}</td>
                        <td className={cn("text-center font-bold", o.side === "BUY" ? "text-emerald-400" : "text-red-400")}>{o.side}</td>
                        <td className="text-center">{o.lot.toFixed(2)}</td>
                        <td className="text-center">{o.entry.toFixed(o.pair.includes("XAU") ? 2 : 5)}</td>
                        <td className="text-center text-red-400/70">{o.sl.toFixed(o.pair.includes("XAU") ? 2 : 5)}</td>
                        <td className="text-center text-emerald-400/70">{o.tp.toFixed(o.pair.includes("XAU") ? 2 : 5)}</td>
                        <td className="text-center">{o.current.toFixed(o.pair.includes("XAU") ? 2 : 5)}</td>
                        <td className={cn("text-center font-bold", p >= 0 ? "text-emerald-400" : "text-red-400")}>${p.toFixed(2)}</td>
                        <td><button onClick={() => close(o.id)} className="text-[10px] px-2 py-0.5 rounded bg-red-500/20 text-red-300 hover:bg-red-500/40">Fermer</button></td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Account details */}
        <div className="space-y-3">
          <div className="rounded-lg border border-border/60 bg-darker-surface/60 p-4">
            <div className="flex items-center gap-2 mb-3"><Wallet className="h-4 w-4 text-orange-400" /><span className="font-bold text-sm">Détails du compte</span></div>
            <div className="space-y-2 text-xs">
              <Row k="Type" v="Pro ECN" />
              <Row k="Devise" v="USD" />
              <Row k="Levier" v="1:500" />
              <Row k="Stop-out" v="20%" />
              <Row k="Commission" v="$3.50 / lot" />
              <Row k="Swap (long)" v="-2.10" />
              <Row k="Swap (short)" v="+0.85" />
              <Row k="Serveur" v="JustMarkets-Live06" />
            </div>
          </div>
          <div className="rounded-lg border border-border/60 bg-darker-surface/60 p-4">
            <div className="font-bold text-sm mb-2">Dépôt / Retrait</div>
            <div className="grid grid-cols-2 gap-2">
              <button className="py-2 rounded bg-emerald-600 hover:bg-emerald-500 text-xs font-bold">Déposer</button>
              <button className="py-2 rounded bg-secondary/60 text-xs font-bold">Retirer</button>
            </div>
            <div className="mt-3 text-[10px] text-muted-foreground">Méthodes : Skrill, Neteller, Carte, Crypto (BTC/USDT TRC-20)</div>
          </div>
        </div>
      </div>
    </div>
  )
}

function Badge({ icon: I, label }: { icon: any; label: string }) {
  return <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-secondary/40 border border-border/40"><I className="h-3 w-3 text-orange-400" /><span>{label}</span></div>
}
function Stat({ label, value, color }: { label: string; value: string; color?: string }) {
  return <div className="rounded-lg border border-border/60 bg-darker-surface/60 p-3">
    <div className="text-[10px] uppercase text-muted-foreground">{label}</div>
    <div className={cn("text-lg font-bold font-mono", color)}>{value}</div>
  </div>
}
function Field({ label, value, onChange, step, min }: { label: string; value: number; onChange: (n: number) => void; step: number; min: number }) {
  return <div>
    <div className="text-[10px] uppercase text-muted-foreground mb-1">{label}</div>
    <input type="number" step={step} min={min} value={value} onChange={e => onChange(parseFloat(e.target.value) || 0)}
      className="w-full bg-background border border-border/60 rounded px-2 py-1.5 text-sm font-mono" />
  </div>
}
function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex justify-between"><span className="text-muted-foreground">{k}</span><span className="font-mono">{v}</span></div>
}
