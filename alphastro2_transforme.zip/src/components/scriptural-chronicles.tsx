"use client"

import { useState } from "react"
import { BookOpen, ScrollText, Sparkles } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

const bibleChapter = {
 title: "Proverbes 3 — Chapitre complet",
 content: `Mon fils, n'oublie pas mes enseignements... Heureux l'homme qui a trouvé la sagesse... Honore l'Éternel avec tes biens et avec les prémices de tout ton revenu... Ne sois pas sage à tes propres yeux ; crains l'Éternel et détourne-toi du mal.` ,
 lesson: "La discipline, la patience et la sagesse doivent gouverner chaque décision financière et spirituelle."
}

const apocryphaChapter = {
 title: "Siracide 31 — Richesse et vigilance",
 content: `Les veilles de l'homme riche consument sa chair... Heureux le riche qui a été trouvé sans tache et qui n'a pas couru après l'or... Qui est-il ? Nous le dirons heureux car il a fait des merveilles parmi son peuple.` ,
 lesson: "La richesse devient utile lorsqu'elle reste soumise à l'éthique, à la justice et à la maîtrise de soi."
}

export function ScripturalChronicles() {
 const [tab,setTab]=useState<"bible"|"apocrypha">('bible')
 const current = tab==='bible'?bibleChapter:apocryphaChapter
 return <div className="p-4 lg:p-6">
 <Card className="bg-card/50 border-border/50 backdrop-blur">
 <CardHeader>
 <CardTitle className="flex items-center gap-2 text-foreground">
 <BookOpen className="h-5 w-5 text-accent" />
 Chapitres Scripturaires Complets
 </CardTitle>
 </CardHeader>
 <CardContent className="space-y-4">
 <div className="flex gap-2">
 <button onClick={()=>setTab('bible')} className={cn("px-4 py-2 rounded-lg border",tab==='bible'?"bg-accent/10 border-accent":"border-border/40")}>Bible complète</button>
 <button onClick={()=>setTab('apocrypha')} className={cn("px-4 py-2 rounded-lg border",tab==='apocrypha'?"bg-accent/10 border-accent":"border-border/40")}>Apocryphes</button>
 </div>
 <div className="rounded-xl border border-border/40 p-5 bg-secondary/20 space-y-4">
 <div className="flex items-center gap-2 text-accent font-semibold"><ScrollText className="h-4 w-4" />{current.title}</div>
 <p className="leading-relaxed text-sm text-foreground">{current.content}</p>
 <div className="rounded-lg border border-primary/30 bg-primary/10 p-4">
 <div className="flex items-center gap-2 font-semibold text-primary"><Sparkles className="h-4 w-4" />Life Lesson</div>
 <p className="text-sm mt-2">{current.lesson}</p>
 </div>
 </div>
 </CardContent>
 </Card>
 </div>
}
