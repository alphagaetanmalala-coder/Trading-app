"use client"

import { useEffect, useRef, useState } from "react"
import { Bell, Check, Trash2, Radio, Send, AlertTriangle, Sparkles } from "lucide-react"
import { cn } from "@/lib/utils"
import {
  useNotifications,
  markAllRead,
  clearAll,
  type AlphaNotification,
} from "@/lib/notification-store"

function iconFor(k: AlphaNotification["kind"]) {
  switch (k) {
    case "signal": return Sparkles
    case "telegram": return Send
    case "alert": return AlertTriangle
    default: return Radio
  }
}

function timeAgo(ts: number) {
  const d = Math.max(1, Math.floor((Date.now() - ts) / 1000))
  if (d < 60) return `${d}s`
  if (d < 3600) return `${Math.floor(d / 60)}min`
  if (d < 86400) return `${Math.floor(d / 3600)}h`
  return `${Math.floor(d / 86400)}j`
}

export function NotificationBell() {
  const { notifications, unread } = useNotifications()
  const [open, setOpen] = useState(false)
  const [bump, setBump] = useState(false)
  const ref = useRef<HTMLDivElement | null>(null)
  const prevUnread = useRef(unread)

  useEffect(() => {
    if (unread > prevUnread.current) {
      setBump(true)
      const t = setTimeout(() => setBump(false), 700)
      prevUnread.current = unread
      return () => clearTimeout(t)
    }
    prevUnread.current = unread
  }, [unread])

  useEffect(() => {
    if (!open) return
    const close = (e: MouseEvent) => {
      if (!ref.current?.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener("mousedown", close)
    return () => document.removeEventListener("mousedown", close)
  }, [open])

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen(o => !o)}
        className={cn(
          "relative p-2 rounded-full hover:bg-secondary/60 transition-all",
          bump && "animate-bounce",
        )}
        title="Notifications"
        aria-label="Notifications"
      >
        <Bell className="h-5 w-5 text-foreground" />
        {unread > 0 && (
          <span
            className={cn(
              "absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1",
              "rounded-full bg-red-500 text-white text-[10px] font-bold",
              "flex items-center justify-center border-2 border-darker-surface",
              "shadow-[0_0_10px_rgba(239,68,68,0.7)]",
            )}
          >
            {unread > 99 ? "99+" : unread}
          </span>
        )}
      </button>

      {open && (
        <div
          className={cn(
            "absolute right-0 mt-2 w-[360px] max-h-[70vh] overflow-hidden",
            "rounded-xl border border-border/60 bg-darker-surface/95 backdrop-blur-2xl",
            "shadow-2xl z-[60] flex flex-col",
          )}
        >
          <div className="flex items-center justify-between px-4 py-3 border-b border-border/50">
            <div className="font-semibold text-foreground">Notifications</div>
            <div className="flex items-center gap-1">
              <button
                onClick={markAllRead}
                className="text-[11px] px-2 py-1 rounded hover:bg-secondary/60 text-muted-foreground flex items-center gap-1"
                title="Tout marquer comme lu"
              >
                <Check className="h-3 w-3" /> Tout lu
              </button>
              <button
                onClick={clearAll}
                className="text-[11px] px-2 py-1 rounded hover:bg-secondary/60 text-muted-foreground flex items-center gap-1"
                title="Vider"
              >
                <Trash2 className="h-3 w-3" /> Vider
              </button>
            </div>
          </div>
          <div className="overflow-y-auto">
            {notifications.length === 0 && (
              <div className="px-4 py-10 text-center text-sm text-muted-foreground">
                Aucune notification pour l'instant.
              </div>
            )}
            {notifications.map(n => {
              const Icon = iconFor(n.kind)
              return (
                <div
                  key={n.id}
                  className={cn(
                    "px-4 py-3 border-b border-border/30 hover:bg-secondary/30 transition-colors",
                    !n.read && "bg-primary/5",
                  )}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={cn(
                        "h-9 w-9 rounded-full flex items-center justify-center flex-shrink-0",
                        n.kind === "telegram" && "bg-sky-500/20 text-sky-400",
                        n.kind === "signal" && "bg-amber-500/20 text-amber-400",
                        n.kind === "alert" && "bg-red-500/20 text-red-400",
                        n.kind === "system" && "bg-primary/20 text-primary",
                      )}
                    >
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <div className="text-sm font-semibold text-foreground truncate">
                          {n.title}
                        </div>
                        <div className="text-[10px] text-muted-foreground flex-shrink-0">
                          {timeAgo(n.ts)}
                        </div>
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5 whitespace-pre-wrap break-words line-clamp-4">
                        {n.body}
                      </div>
                      <div className="text-[10px] text-muted-foreground/70 mt-1">
                        via {n.source}
                      </div>
                    </div>
                    {!n.read && (
                      <span className="h-2 w-2 rounded-full bg-red-500 mt-1.5 flex-shrink-0" />
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
